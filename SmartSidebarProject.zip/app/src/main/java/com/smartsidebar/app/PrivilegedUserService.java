package com.smartsidebar.app;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PrivilegedUserService extends IPrivilegedService.Stub {
    public PrivilegedUserService() {}

    @Override
    public String exec(String command) {
        StringBuilder out = new StringBuilder();
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"/system/bin/sh", "-c", command});
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) out.append(line).append('\n');
            }
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getErrorStream()))) {
                String line;
                while ((line = br.readLine()) != null) out.append("ERR: ").append(line).append('\n');
            }
            int code = p.waitFor();
            out.append("EXIT=").append(code);
        } catch (Throwable t) {
            out.append("EXCEPTION: ").append(t.getClass().getSimpleName()).append(": ").append(t.getMessage());
        }
        return out.toString();
    }
}
