package com.smartsidebar.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

public class StrongModeActivity extends Activity {
    private static final int REQ = 8801;
    private TextView status, log;
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (code, result) -> {
        if (code == REQ) {
            Toast.makeText(this, result == PackageManager.PERMISSION_GRANTED ? "تم منح صلاحية Shizuku ✓" : "لم تُمنح الصلاحية", Toast.LENGTH_LONG).show();
            refresh();
        }
    };
    private final Shizuku.OnBinderReceivedListener binderListener = this::refresh;
    private final Shizuku.OnBinderDeadListener deadListener = this::refresh;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = Ui.page(this, "V8 Strong — Shizuku / Freeform");
        status = Ui.text(this, "", 15, Color.WHITE, true);
        root.addView(status, Ui.match());

        TextView intro = Ui.text(this,
                "هذه أقوى نسخة بدون Root. تستخدم Shizuku بصلاحية ADB مرة واحدة لتفعيل Freeform ومحاولة فتح التطبيقات في Windowing Mode 5. بعد الإعداد استخدم الوضع Auto Strong.",
                14, Color.LTGRAY, false);
        intro.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 10));
        root.addView(intro, Ui.match());

        Button open = Ui.button(this, "1) فتح Shizuku / تثبيته");
        open.setAllCaps(false);
        open.setOnClickListener(v -> openShizuku());
        root.addView(open, Ui.buttonParams(this));

        Button perm = Ui.button(this, "2) طلب صلاحية Smart Sidebar داخل Shizuku");
        perm.setAllCaps(false);
        perm.setOnClickListener(v -> {
            ShizukuBridge br = ShizukuBridge.get(this);
            if (!br.binderAlive()) Toast.makeText(this, "شغّل Shizuku أولاً", Toast.LENGTH_LONG).show();
            else if (br.hasPermission()) Toast.makeText(this, "الصلاحية ممنوحة بالفعل ✓", Toast.LENGTH_SHORT).show();
            else br.requestPermission(REQ);
        });
        root.addView(perm, Ui.buttonParams(this));

        Button enable = Ui.button(this, "3) تفعيل Freeform القوي");
        enable.setAllCaps(false);
        enable.setOnClickListener(v -> {
            setLog("جارٍ التفعيل...");
            ShizukuBridge.get(this).enableStrongFreeform((ok, msg) -> runOnUiThread(() -> {
                setLog(msg + "\n\n" + (ok ? "تم إرسال الإعدادات. أعد تشغيل الهاتف مرة واحدة ثم جرّب الشريط." : "فشل التنفيذ. تأكد من تشغيل Shizuku ومنح الصلاحية."));
                refresh();
            }));
        });
        root.addView(enable, Ui.buttonParams(this));

        Button check = Ui.button(this, "فحص حالة Freeform / Shizuku");
        check.setAllCaps(false);
        check.setOnClickListener(v -> {
            setLog("جارٍ الفحص...");
            ShizukuBridge.get(this).readStrongSettings((ok, msg) -> runOnUiThread(() -> setLog(msg)));
        });
        root.addView(check, Ui.buttonParams(this));

        log = Ui.text(this, "", 13, Color.rgb(170,220,255), false);
        log.setPadding(0, Ui.dp(this,10), 0, 0);
        root.addView(log, Ui.match());

        TextView note = Ui.text(this,
                "مهم: على OPPO/ColorOS قد يظل النظام يرفض Freeform حتى مع صلاحية shell. V8 تجمع أقوى الطرق العملية في نسخة واحدة: Shizuku + تفعيل Freeform + force-resizable + Windowing Mode 5 + محاولات Android العامة. إذا بقي التطبيق Full Screen بعد هذه الخطوات وإعادة تشغيل الهاتف، فالمنع من ColorOS نفسه ولن نكرر نسخًا بنفس الفكرة.",
                13, Color.YELLOW, false);
        note.setPadding(0, Ui.dp(this,14), 0, 0);
        root.addView(note, Ui.match());

        setContentView(Ui.scrollPage(this, root));
        Shizuku.addRequestPermissionResultListener(permissionListener);
        Shizuku.addBinderReceivedListenerSticky(binderListener);
        Shizuku.addBinderDeadListener(deadListener);
        refresh();
    }

    private void refresh() {
        if (status == null) return;
        runOnUiThread(() -> {
            boolean alive = ShizukuBridge.get(this).binderAlive();
            boolean granted = ShizukuBridge.get(this).hasPermission();
            status.setText("Shizuku: " + (alive ? "يعمل ✓" : "غير مشغّل ✕") + "\nصلاحية Smart Sidebar: " + (granted ? "ممنوحة ✓" : "غير ممنوحة"));
            status.setTextColor(granted ? Color.rgb(80,220,125) : Color.YELLOW);
        });
    }

    private void setLog(String s) { log.setText(s == null ? "" : s); }

    private void openShizuku() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (launch != null) { startActivity(launch); return; }
        } catch (Throwable ignored) {}
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api")));
        } catch (Throwable t) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/guide/setup/")));
        }
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        Shizuku.removeBinderReceivedListener(binderListener);
        Shizuku.removeBinderDeadListener(deadListener);
        super.onDestroy();
    }
}
