package com.smartsidebar.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;

public class AboutActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"حول Smart Sidebar");
        String version="?";
        try{version=getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception ignored){}
        root.addView(Ui.text(this,"Version "+version,16,Ui.ACCENT,true),Ui.match());
        root.addView(Ui.text(this,
                "\nV8 Strong تجمع أقوى المحاولات في نسخة واحدة: Shizuku/ADB shell + تفعيل Freeform + Force Resizable + Windowing Mode 5 + Android public APIs + OPPO Enhanced + Full Screen fallback.\n\n"+
                "لا Root ولا Accessibility. Shizuku يحتاج تشغيله ومنح Smart Sidebar الصلاحية.\n\n"+
                "الخصوصية: لا حساب ولا خادم ولا Analytics ولا إعلانات.\n\n"+
                "ملاحظة: بعض إصدارات ColorOS قد تمنع Freeform لتطبيقات الطرف الثالث حتى مع shell؛ عندها لا يوجد حل APK عام مضمون دون Root/تعديل النظام.",
                14,Color.LTGRAY,false),Ui.match());
        setContentView(Ui.scrollPage(this,root));
    }
}
