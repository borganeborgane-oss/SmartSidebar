package com.smartsidebar.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;

public class AboutActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"حول Smart Sidebar");

        String version="?";
        try{version=getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception ignored){}

        root.addView(Ui.text(this,"Version "+version,16,Ui.ACCENT,true),Ui.match());
        root.addView(Ui.text(this,
                "\nV7 OPPO تضيف وضع ColorOS Enhanced واختبار توافق لكل تطبيق.\n\n"+
                "الخصوصية: لا حساب، لا خادم، لا Analytics، لا إعلانات، ولا يتم إرسال قائمة تطبيقاتك إلى الإنترنت.\n\n"+
                "الأمان: لا Accessibility، لا Root، لا Shizuku، ولا Private APIs.\n\n"+
                "النافذة المصغرة: Android لا يوفر API عامة تجبر كل تطبيق خارجي على Floating Window. V7 تحاول الواجهات العامة فقط وتحفظ نتائج الاختبار على جهازك.\n\n"+
                "التوقيع: Development Keystore ثابت لتحديث APK التجريبي؛ لا يستخدم للنشر النهائي.",
                14,Color.LTGRAY,false),Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }
}
