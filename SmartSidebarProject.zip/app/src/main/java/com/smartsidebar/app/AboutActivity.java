package com.smartsidebar.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;

public class AboutActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"حول Smart Sidebar");

        String version="?";
        try{version=getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception ignored){}

        root.addView(Ui.text(this,"Version "+version,16,Ui.ACCENT,true),Ui.match());
        root.addView(Ui.text(this,
                "\nSmart Sidebar هو مشغّل تطبيقات محلي يظهر فوق التطبيقات بعد منح صلاحية Overlay.\n\n"+
                "الخصوصية: لا حساب، لا خادم، لا Analytics، لا إعلانات، ولا يتم إرسال قائمة تطبيقاتك إلى الإنترنت.\n\n"+
                "النافذة المصغرة: Android لا يوفر طريقة عامة تجبر كل تطبيق خارجي على وضع Freeform. Smart Sidebar يحاول APIs الرسمية فقط، ويستخدم Full Screen كبديل إذا كان ذلك مفعّلًا.\n\n"+
                "التوقيع: هذه النسخة تستخدم Development Keystore ثابتًا داخل المشروع لتسهيل تحديث APK التجريبي. لا تستخدم هذا المفتاح للنشر النهائي على متجر Play.",
                14,Color.LTGRAY,false),Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }
}
