package com.smartsidebar.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        android.content.SharedPreferences p = Prefs.sp(context);
        if (!p.getBoolean(Prefs.START_BOOT,false)) return;
        if (!p.getBoolean(Prefs.HANDLE_ENABLED,true)) return;
        if (!Settings.canDrawOverlays(context)) return;

        try {
            Intent s=new Intent(context,FloatingSidebarService.class);
            if(Build.VERSION.SDK_INT>=26) context.startForegroundService(s);
            else context.startService(s);
        } catch(Exception ignored) {}
    }
}
