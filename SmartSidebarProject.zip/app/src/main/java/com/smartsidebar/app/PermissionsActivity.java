package com.smartsidebar.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

public class PermissionsActivity extends Activity {
    private TextView overlayStatus, notificationStatus;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"الصلاحيات");

        Ui.section(this,root,"Display over other apps");
        overlayStatus=Ui.text(this,"",15,Color.WHITE,true);
        root.addView(overlayStatus,Ui.match());
        Button overlay=Ui.button(this,"منح / تعديل صلاحية الظهور فوق التطبيقات");
        overlay.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:"+getPackageName()))));
        root.addView(overlay,Ui.buttonParams(this));

        Ui.section(this,root,"الإشعارات");
        notificationStatus=Ui.text(this,"",15,Color.WHITE,true);
        root.addView(notificationStatus,Ui.match());
        if(Build.VERSION.SDK_INT>=33){
            Button notification=Ui.button(this,"طلب إذن الإشعارات");
            notification.setOnClickListener(v->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},77));
            root.addView(notification,Ui.buttonParams(this));
        }

        Ui.section(this,root,"البطارية");
        Button battery=Ui.button(this,"فتح إعدادات تحسين البطارية");
        battery.setOnClickListener(v->{
            try{startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}
            catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}
        });
        root.addView(battery,Ui.buttonParams(this));

        TextView note=Ui.text(this,
                "Smart Sidebar يحتاج Overlay حتى يظهر فوق التطبيقات. لا يتم جمع أو إرسال أي بيانات.",
                13,Color.LTGRAY,false);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
        refresh();
    }

    @Override protected void onResume(){super.onResume();refresh();}

    private void refresh(){
        if(overlayStatus!=null){
            boolean ok=Settings.canDrawOverlays(this);
            overlayStatus.setText(ok?"Granted ✓":"Not granted ✕");
            overlayStatus.setTextColor(ok?Color.rgb(80,220,125):Color.rgb(235,90,90));
        }
        if(notificationStatus!=null){
            boolean ok=Build.VERSION.SDK_INT<33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
            notificationStatus.setText(ok?"Granted ✓":"Not granted ✕");
            notificationStatus.setTextColor(ok?Color.rgb(80,220,125):Color.YELLOW);
        }
    }
}
