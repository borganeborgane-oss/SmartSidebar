package com.smartsidebar.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

public final class Ui {
    public static final int BG = Color.rgb(18,19,22);
    public static final int CARD = Color.rgb(31,33,38);
    public static final int ACCENT = Color.rgb(77,163,255);

    private Ui() {}

    public static LinearLayout page(Activity a, String title) {
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(a,18), dp(a,28), dp(a,18), dp(a,24));
        root.setBackgroundColor(BG);

        TextView t = text(a, title, 25, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p = match();
        p.bottomMargin = dp(a,14);
        root.addView(t, p);
        return root;
    }

    public static ScrollView scrollPage(Activity a, LinearLayout root) {
        ScrollView s = new ScrollView(a);
        s.addView(root);
        return s;
    }

    public static TextView text(Activity a, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static Button button(Activity a, String s) {
        Button b = new Button(a);
        b.setText(s);
        b.setTextSize(15);
        return b;
    }

    public static Switch toggle(Activity a, String s, boolean checked) {
        Switch sw = new Switch(a);
        sw.setText(s);
        sw.setTextColor(Color.WHITE);
        sw.setTextSize(15);
        sw.setChecked(checked);
        sw.setPadding(0, dp(a,6), 0, dp(a,6));
        return sw;
    }

    public static void section(Activity a, LinearLayout root, String name) {
        TextView t = text(a, name, 17, ACCENT, true);
        LinearLayout.LayoutParams p = match();
        p.topMargin = dp(a,18);
        p.bottomMargin = dp(a,7);
        root.addView(t, p);
    }

    public static LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    public static LinearLayout.LayoutParams buttonParams(Activity a) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(a,52));
        p.topMargin = dp(a,8);
        return p;
    }

    public static SeekBar seek(Activity a, LinearLayout root, int max, int progress) {
        SeekBar s = new SeekBar(a);
        s.setMax(max);
        s.setProgress(Math.max(0, Math.min(max, progress)));
        LinearLayout.LayoutParams p = match();
        p.bottomMargin = dp(a,7);
        root.addView(s, p);
        return s;
    }

    public static TextView value(Activity a, LinearLayout root, String text) {
        TextView t = Ui.text(a, text, 14, Color.WHITE, false);
        root.addView(t, match());
        return t;
    }

    public static void spinner(Activity a, LinearLayout root, String label, String[] values, int selected,
                               android.widget.AdapterView.OnItemSelectedListener listener) {
        root.addView(text(a, label, 14, Color.WHITE, false), match());
        Spinner s = new Spinner(a);
        ArrayAdapter<String> ad = new ArrayAdapter<>(a, android.R.layout.simple_spinner_dropdown_item, values);
        s.setAdapter(ad);
        s.setSelection(Math.max(0, Math.min(values.length - 1, selected)));
        s.setOnItemSelectedListener(listener);
        LinearLayout.LayoutParams p = match();
        p.bottomMargin = dp(a,8);
        root.addView(s, p);
    }

    public static int dp(Activity a, int v) {
        return (int)(v * a.getResources().getDisplayMetrics().density);
    }

    public static int dp(android.content.Context c, int v) {
        return (int)(v * c.getResources().getDisplayMetrics().density);
    }
}
