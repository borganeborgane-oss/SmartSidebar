package com.smartsidebar.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

public class BehaviorSettingsActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        SharedPreferences p=Prefs.sp(this);
        LinearLayout root=Ui.page(this,"السلوك");

        add(root,p,"إغلاق القائمة بعد فتح التطبيق",Prefs.AUTO_CLOSE,true);
        add(root,p,"إغلاق القائمة عند الضغط خارجها",Prefs.CLOSE_OUTSIDE,true);
        add(root,p,"اهتزاز خفيف",Prefs.HAPTIC,true);
        add(root,p,"صوت خفيف",Prefs.SOUND,false);
        add(root,p,"التشغيل بعد إعادة تشغيل الهاتف",Prefs.START_BOOT,false);

        TextView note=Ui.text(this,
                "التشغيل بعد إعادة التشغيل قد يتأثر بقيود البطارية الخاصة بالشركة المصنّعة. يمكنك فتح إعدادات البطارية من صفحة «الصلاحيات».",
                13,android.graphics.Color.LTGRAY,false);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }

    private void add(LinearLayout root,SharedPreferences p,String text,String key,boolean def){
        Switch s=Ui.toggle(this,text,p.getBoolean(key,def));
        s.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(key,c).apply());
        root.addView(s,Ui.match());
    }
}
