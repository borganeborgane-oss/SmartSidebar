package com.smartsidebar.app;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

public class DeviceCompatibilityActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"توافق الجهاز");

        add(root,"Manufacturer",Build.MANUFACTURER);
        add(root,"Model",Build.MODEL);
        add(root,"Android",Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")");

        boolean overlay=Settings.canDrawOverlays(this);
        add(root,"Overlay support",Build.VERSION.SDK_INT>=23?"Supported":"Not available");
        add(root,"Overlay permission",overlay?"Granted ✓":"Not granted ✕");

        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        boolean pip=getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);

        add(root,"Freeform window feature",freeform?"Supported ✓":
                (Build.VERSION.SDK_INT>=24?"Not advertised / OEM-specific":"Not available"));
        add(root,"Picture-in-Picture",pip?"Supported ✓":"Not detected");
        add(root,"Accessibility helper","Removed in V6.1 Safe ✓");

        String floating=freeform?"Supported — Official Freeform":"OEM-specific — Full Screen fallback";
        add(root,"Floating App Window Support",floating);
        add(root,"V6.1 recommendation",freeform?"Recommended mode: Auto":"Recommended mode: Auto / Full Screen");

        TextView note=Ui.text(this,
                "V6.1 Safe لا تستخدم Accessibility للتحكم في واجهة الهاتف. هذا يقلل الصلاحيات الحساسة عند تثبيت APK خارج Google Play. فتح تطبيقات خارجية كنافذة عائمة يبقى ممكنًا فقط عندما يتيحه Android/OEM لتطبيقات الطرف الثالث عبر واجهات رسمية.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,14),0,0);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }

    private void add(LinearLayout root,String key,String value){
        TextView t=Ui.text(this,key+":\n"+value,15,Color.WHITE,false);
        t.setPadding(0,Ui.dp(this,7),0,Ui.dp(this,7));
        root.addView(t,Ui.match());
    }
}
