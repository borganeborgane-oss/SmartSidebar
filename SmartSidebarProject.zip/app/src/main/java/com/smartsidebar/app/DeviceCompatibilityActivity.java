package com.smartsidebar.app;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

public class DeviceCompatibilityActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"توافق الجهاز");

        add(root,"Manufacturer",Build.MANUFACTURER);
        add(root,"Model",Build.MODEL);
        add(root,"Android",Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")");

        boolean overlay=Settings.canDrawOverlays(this);
        add(root,"Overlay support",Build.VERSION.SDK_INT>=23?"Supported":"Not available");
        add(root,"Overlay permission",overlay?"Granted ✓":"Not granted ✕");

        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        boolean pip=getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);
        boolean assist=OemFloatingAccessibilityService.isEnabled(this);

        add(root,"Freeform window feature",freeform?"Supported ✓":
                (Build.VERSION.SDK_INT>=24?"Not advertised / OEM-specific":"Not available"));
        add(root,"Picture-in-Picture",pip?"Supported ✓":"Not detected");
        add(root,"OEM Assist accessibility",assist?"Enabled ✓":"Not enabled");

        String floating;
        if(freeform) floating="Supported — Official Freeform";
        else if(assist) floating="Experimental — OEM Assist available";
        else floating=Build.VERSION.SDK_INT>=24?"Experimental — enable OEM Assist":"Not detected";
        add(root,"Floating App Window Support",floating);

        String recommendation;
        if(freeform) recommendation="Recommended mode: Auto / Official Freeform";
        else if(assist) recommendation="Recommended mode: Auto / OEM Assist";
        else recommendation="Recommended mode: فعّل OEM Assist من صفحة النافذة المصغرة";
        add(root,"V6 recommendation",recommendation);

        TextView note=Ui.text(this,
                "V6 تضيف طبقة OEM Assist اختيارية لهواتف مثل OPPO/realme/Samsung/Xiaomi/vivo عندما لا يعلن النظام Freeform رسميًا. الخدمة تحاول استخدام أمر Floating Window الظاهر في واجهة Recent Apps. لأنها تعتمد على واجهة الشركة، تظل تجريبية وقد تحتاج تحديثًا عند تغيّر ColorOS/One UI/HyperOS.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,14),0,0);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }

    private void add(LinearLayout root,String key,String value){
        TextView t=Ui.text(this,key+":\n"+value,15,Color.WHITE,false);
        t.setPadding(0,Ui.dp(this,7),0,Ui.dp(this,7));
        root.addView(t,Ui.match());
    }
}
