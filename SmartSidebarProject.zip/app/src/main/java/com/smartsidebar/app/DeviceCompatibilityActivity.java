package com.smartsidebar.app;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DeviceCompatibilityActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"توافق الجهاز — V8 Strong");
        add(root,"Manufacturer",Build.MANUFACTURER);
        add(root,"Brand",Build.BRAND);
        add(root,"Model",Build.MODEL);
        add(root,"Android",Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")");
        add(root,"Overlay permission",Settings.canDrawOverlays(this)?"Granted ✓":"Not granted ✕");
        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        add(root,"Official Freeform feature",freeform?"Supported ✓":"Not advertised / OEM-specific");
        add(root,"OPPO / ColorOS",Prefs.isOppoFamily()?"Detected ✓":"No");
        add(root,"Shizuku service",ShizukuBridge.get(this).binderAlive()?"Running ✓":"Not running");
        add(root,"Shizuku permission",ShizukuBridge.get(this).hasPermission()?"Granted ✓":"Not granted");
        add(root,"V8 strongest engine",ShizukuBridge.get(this).hasPermission()?"Available — Windowing Mode 5":"Needs Shizuku setup");
        TextView note=Ui.text(this,
                "V8 تضيف طبقة shell عبر Shizuku لتفعيل enable_freeform_support وforce_resizable_activities ثم تشغيل التطبيقات بـ windowingMode=5. هذا أقوى من V7 بدون Root، لكنه يظل خاضعًا لما يسمح به ColorOS.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,14),0,0);
        root.addView(note,Ui.match());
        setContentView(Ui.scrollPage(this,root));
    }
    private void add(LinearLayout root,String key,String value){
        TextView t=Ui.text(this,key+":\n"+value,15,Color.WHITE,false);
        t.setPadding(0,Ui.dp(this,7),0,Ui.dp(this,7));
        root.addView(t,Ui.match());
    }
}
