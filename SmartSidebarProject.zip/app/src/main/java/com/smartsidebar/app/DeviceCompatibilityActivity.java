package com.smartsidebar.app;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

public class DeviceCompatibilityActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"توافق الجهاز — V7");

        add(root,"Manufacturer",Build.MANUFACTURER);
        add(root,"Brand",Build.BRAND);
        add(root,"Model",Build.MODEL);
        add(root,"Android",Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")");

        boolean overlay=Settings.canDrawOverlays(this);
        add(root,"Overlay support",Build.VERSION.SDK_INT>=23?"Supported":"Not available");
        add(root,"Overlay permission",overlay?"Granted ✓":"Not granted ✕");

        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        boolean pip=getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);
        boolean oppo=Prefs.isOppoFamily();

        add(root,"Freeform window feature",freeform?"Supported ✓":
                (Build.VERSION.SDK_INT>=24?"Not advertised / OEM-specific":"Not available"));
        add(root,"Picture-in-Picture",pip?"Supported ✓":"Not detected");
        add(root,"OPPO / ColorOS family",oppo?"Detected ✓":"No");
        add(root,"Accessibility helper","Not used ✓");

        String floating=freeform?"Official Freeform available":(oppo?"OPPO Enhanced public-API test available":"Full Screen fallback");
        add(root,"Floating App Window Support",floating);
        add(root,"V7 recommendation",freeform?"Auto / Official Freeform":(oppo?"Auto + اختبار التطبيقات":"Auto / Full Screen"));

        TextView note=Ui.text(this,
                "V7 الخاصة بـ OPPO تحاول Android APIs العامة مع ColorOS وتسمح لك باختبار كل تطبيق وحفظ النتيجة. لا تستخدم Accessibility أو Root أو Shizuku أو Private APIs. إذا تجاهل ColorOS طلب حجم النافذة، لا يمكن للتطبيق إجباره على Floating Window تلقائيًا.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,14),0,0);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }

    private void add(LinearLayout root,String key,String value){
        TextView t=Ui.text(this,key+":\n"+value,15,Color.WHITE,false);
        t.setPadding(0,Ui.dp(this,7),0,Ui.dp(this,7));
        root.addView(t,Ui.match());
    }
}
