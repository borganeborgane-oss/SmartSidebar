package com.smartsidebar.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;

public class AdvancedActivity extends Activity {
    private SharedPreferences p;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        p=Prefs.sp(this);
        LinearLayout root=Ui.page(this,"متقدم");

        Button resetPos=Ui.button(this,"إعادة موضع المقبض للوسط");
        resetPos.setOnClickListener(v->{p.edit().putInt(Prefs.HANDLE_Y,0).apply();refresh();toast("تم");});
        root.addView(resetPos,Ui.buttonParams(this));

        Button clearApps=Ui.button(this,"مسح التطبيقات المختارة");
        clearApps.setOnClickListener(v->{
            p.edit().putString(Prefs.APP_ORDER,"[]").putBoolean(Prefs.APPS_INITIALIZED,true).apply();
            refresh();toast("تم مسح التطبيقات");
        });
        root.addView(clearApps,Ui.buttonParams(this));

        Button export=Ui.button(this,"تصدير الإعدادات");
        export.setOnClickListener(v->{
            Intent i=new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT,"Smart Sidebar settings");
            i.putExtra(Intent.EXTRA_TEXT,Prefs.exportJson(this));
            startActivity(Intent.createChooser(i,"تصدير الإعدادات"));
        });
        root.addView(export,Ui.buttonParams(this));

        Button importBtn=Ui.button(this,"استيراد الإعدادات من JSON");
        importBtn.setOnClickListener(v->showImport());
        root.addView(importBtn,Ui.buttonParams(this));

        Button reset=Ui.button(this,"إعادة كل الإعدادات الافتراضية");
        reset.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("إعادة الضبط")
                .setMessage("سيتم حذف كل الإعدادات والتطبيقات المختارة.")
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("إعادة", (d,w)->{
                    boolean running=p.getBoolean(Prefs.RUNNING,false);
                    p.edit().clear().putBoolean(Prefs.RUNNING,running).apply();
                    Prefs.sp(this); refresh(); toast("تمت إعادة الضبط");
                }).show());
        root.addView(reset,Ui.buttonParams(this));

        TextView debug=Ui.text(this,
                "Debug info:\nPackage: "+getPackageName()+"\nSelected apps: "+Prefs.getAppOrder(this).size(),
                13,Color.LTGRAY,false);
        debug.setPadding(0,Ui.dp(this,16),0,0);
        root.addView(debug,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }

    private void showImport(){
        EditText input=new EditText(this);
        input.setHint("{...}");
        input.setMinLines(6);
        new AlertDialog.Builder(this)
                .setTitle("الصق JSON")
                .setView(input)
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("استيراد",(d,w)->{
                    boolean ok=Prefs.importJson(this,input.getText().toString());
                    toast(ok?"تم الاستيراد":"JSON غير صالح");
                    if(ok) refresh();
                }).show();
    }

    private void refresh(){
        if(!p.getBoolean(Prefs.RUNNING,false))return;
        Intent i=new Intent(this,FloatingSidebarService.class);i.setAction(FloatingSidebarService.ACTION_REFRESH);
        if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
