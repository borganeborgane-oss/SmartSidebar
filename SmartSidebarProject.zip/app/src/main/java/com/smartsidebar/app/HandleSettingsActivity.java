package com.smartsidebar.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import android.view.*;

public class HandleSettingsActivity extends Activity {
    private SharedPreferences p;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Prefs.sp(this);
        LinearLayout root = Ui.page(this, "المقبض العائم");

        Switch enabled = Ui.toggle(this, "إظهار المقبض العائم", p.getBoolean(Prefs.HANDLE_ENABLED,true));
        enabled.setOnCheckedChangeListener((v,c)->{p.edit().putBoolean(Prefs.HANDLE_ENABLED,c).apply(); refreshService();});
        root.addView(enabled, Ui.match());

        spinner(root, "الجهة", new String[]{"يمين","يسار"},
                p.getString(Prefs.SIDE,"right").equals("right")?0:1,
                pos->{p.edit().putString(Prefs.SIDE,pos==0?"right":"left").apply(); refreshService();});

        spinner(root, "شكل المقبض", new String[]{"كبسولة","دائرة","خط نحيف","مستطيل دائري"},
                p.getInt(Prefs.HANDLE_STYLE,0),
                pos->{p.edit().putInt(Prefs.HANDLE_STYLE,pos).apply(); refreshService();});

        spinner(root, "لون المقبض", new String[]{"رمادي داكن","أزرق","أخضر","بنفسجي","أحمر","أبيض"},
                p.getInt(Prefs.HANDLE_COLOR,0),
                pos->{p.edit().putInt(Prefs.HANDLE_COLOR,pos).apply(); refreshService();});

        spinner(root, "رمز المقبض", new String[]{"سهم","نقاط","خطوط","بدون رمز"},
                p.getInt(Prefs.HANDLE_ICON,0),
                pos->{p.edit().putInt(Prefs.HANDLE_ICON,pos).apply(); refreshService();});

        slider(root, "الشفافية", 30, 100, p.getInt(Prefs.HANDLE_OPACITY,82),
                v->{p.edit().putInt(Prefs.HANDLE_OPACITY,v).apply(); refreshService();});

        slider(root, "العرض", 8, 60, p.getInt(Prefs.HANDLE_WIDTH,28),
                v->{p.edit().putInt(Prefs.HANDLE_WIDTH,v).apply(); refreshService();});

        slider(root, "الارتفاع", 36, 150, p.getInt(Prefs.HANDLE_HEIGHT,82),
                v->{p.edit().putInt(Prefs.HANDLE_HEIGHT,v).apply(); refreshService();});

        Switch remember = Ui.toggle(this, "حفظ مكان المقبض", p.getBoolean(Prefs.REMEMBER_POSITION,true));
        remember.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(Prefs.REMEMBER_POSITION,c).apply());
        root.addView(remember, Ui.match());

        Switch auto = Ui.toggle(this, "إخفاء بصري تلقائي بعد عدم الاستخدام", p.getBoolean(Prefs.AUTO_HIDE,true));
        auto.setOnCheckedChangeListener((v,c)->{p.edit().putBoolean(Prefs.AUTO_HIDE,c).apply(); refreshService();});
        root.addView(auto, Ui.match());

        spinner(root, "مهلة الإخفاء", new String[]{"1 ثانية","2 ثانية","3 ثوان","5 ثوان"},
                delayIndex(p.getInt(Prefs.AUTO_HIDE_DELAY,2)),
                pos->{int[] d={1,2,3,5};p.edit().putInt(Prefs.AUTO_HIDE_DELAY,d[pos]).apply();refreshService();});

        Button reset = Ui.button(this, "إعادة موضع المقبض للوسط");
        reset.setOnClickListener(v->{p.edit().putInt(Prefs.HANDLE_Y,0).apply();refreshService();Toast.makeText(this,"تم",Toast.LENGTH_SHORT).show();});
        root.addView(reset, Ui.buttonParams(this));

        setContentView(Ui.scrollPage(this,root));
    }

    private int delayIndex(int d){ if(d<=1)return 0;if(d==2)return 1;if(d==3)return 2;return 3; }

    private interface Pos { void set(int p); }
    private void spinner(LinearLayout root,String label,String[] vals,int selected,Pos cb){
        Ui.spinner(this,root,label,vals,selected,new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> a, View v,int pos,long id){cb.set(pos);}
            public void onNothingSelected(AdapterView<?> a){}
        });
    }

    private interface Val { void set(int v); }
    private void slider(LinearLayout root,String label,int min,int max,int current,Val cb){
        TextView value=Ui.value(this,root,label+": "+current);
        SeekBar s=Ui.seek(this,root,max-min,current-min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int x,boolean f){int v=x+min;value.setText(label+": "+v);cb.set(v);}
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){}
        });
    }

    private void refreshService(){
        if(!p.getBoolean(Prefs.RUNNING,false)) return;
        android.content.Intent i=new android.content.Intent(this,FloatingSidebarService.class);
        i.setAction(FloatingSidebarService.ACTION_REFRESH);
        if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
    }
}
