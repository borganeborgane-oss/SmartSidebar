package com.smartsidebar.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class FloatingWindowSettingsActivity extends Activity {
    private SharedPreferences p;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        p=Prefs.sp(this);
        LinearLayout root=Ui.page(this,"النافذة المصغرة — V8 Strong");

        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        boolean shizuku=ShizukuBridge.get(this).hasPermission();
        String status=shizuku?"Shizuku Strong جاهز ✓":(freeform?"Official Freeform supported ✓":"OPPO/OEM — يحتاج Strong Mode");
        TextView s=Ui.text(this,"حالة النظام: "+status,15,shizuku||freeform?Color.rgb(80,220,125):Color.YELLOW,true);
        root.addView(s,Ui.match());

        Ui.section(this,root,"طريقة الفتح");
        String[] modes={
                "Auto Strong — Shizuku ثم أفضل بديل",
                "Shizuku Strong — Windowing Mode 5",
                "Official Freeform — Android API",
                "OPPO / ColorOS Enhanced — محاولة عامة",
                "Full Screen — فتح عادي"
        };
        Spinner mode=new Spinner(this);
        mode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,modes));
        int saved=p.getInt(Prefs.FLOATING_MODE,0);
        if(saved<0 || saved>4) saved=0;
        mode.setSelection(saved);
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view,int position,long id){
                p.edit().putInt(Prefs.FLOATING_MODE,position).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        root.addView(mode,Ui.match());

        Switch fallback=Ui.toggle(this,"العودة إلى Full Screen إذا فشلت كل المحاولات",p.getBoolean(Prefs.FALLBACK_FULLSCREEN,true));
        fallback.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(Prefs.FALLBACK_FULLSCREEN,c).apply());
        root.addView(fallback,Ui.match());

        Ui.section(this,root,"V8 Strong");
        Button strong=Ui.button(this,"إعداد Shizuku + تفعيل Freeform القوي");
        strong.setAllCaps(false);
        strong.setOnClickListener(v->startActivity(new Intent(this,StrongModeActivity.class)));
        root.addView(strong,Ui.buttonParams(this));

        Ui.section(this,root,"اختبار التطبيقات");
        Button test=Ui.button(this,"اختبر التطبيقات المختارة");
        test.setAllCaps(false);
        test.setOnClickListener(v->startActivity(new Intent(this,OppoAppTestActivity.class)));
        root.addView(test,Ui.buttonParams(this));

        TextView note=Ui.text(this,
                "ابدأ بـ Auto Strong. إذا منحت Shizuku الصلاحية وفعلت Freeform، سيحاول V8 تشغيل التطبيق كـ Freeform عبر shell/ADB أولاً. بعدها فقط ينتقل إلى الطرق العامة أو Full Screen.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,12),0,0);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }
}
