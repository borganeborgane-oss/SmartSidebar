package com.smartsidebar.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class FloatingWindowSettingsActivity extends Activity {
    private SharedPreferences p;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        p=Prefs.sp(this);
        LinearLayout root=Ui.page(this,"النافذة المصغرة — V7 OPPO");

        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        boolean oppo=Prefs.isOppoFamily();
        String status=freeform?"Official Freeform supported ✓":(oppo?"ColorOS / OPPO detected — experimental":"OEM-specific / not exposed");
        TextView s=Ui.text(this,"حالة النظام: "+status,15,freeform?Color.rgb(80,220,125):Color.YELLOW,true);
        root.addView(s,Ui.match());

        Ui.section(this,root,"طريقة الفتح");
        String[] modes={
                "Auto — اختر أفضل محاولة تلقائيًا",
                "Official Freeform — Android API فقط",
                "OPPO / ColorOS Enhanced — محاولة عامة آمنة",
                "Full Screen — فتح عادي دائمًا"
        };
        Spinner mode=new Spinner(this);
        mode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,modes));
        int saved=p.getInt(Prefs.FLOATING_MODE,0);
        if(saved<0 || saved>3) saved=0;
        mode.setSelection(saved);
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view,int position,long id){
                p.edit().putInt(Prefs.FLOATING_MODE,position).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        root.addView(mode,Ui.match());

        Switch fallback=Ui.toggle(this,"العودة إلى Full Screen إذا تعذر طلب النافذة المصغرة",p.getBoolean(Prefs.FALLBACK_FULLSCREEN,true));
        fallback.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(Prefs.FALLBACK_FULLSCREEN,c).apply());
        root.addView(fallback,Ui.match());

        Ui.section(this,root,"اختبار تطبيقات OPPO");
        Button test=Ui.button(this,"اختبر التطبيقات المختارة وسجّل التوافق");
        test.setAllCaps(false);
        test.setOnClickListener(v->startActivity(new Intent(this,OppoAppTestActivity.class)));
        root.addView(test,Ui.buttonParams(this));

        TextView note=Ui.text(this,
                "V7 لا تستخدم Accessibility ولا Root ولا Shizuku ولا Private APIs. وضع OPPO Enhanced يضيف Flags وحدود نافذة عبر Android APIs العامة فقط، ثم يحفظ نتيجة اختبار كل تطبيق يدويًا.\n\n"+
                "إذا كان ColorOS يمنع تطبيقات الطرف الثالث من فتح نافذة عائمة، لا يستطيع Smart Sidebar إجبار النظام على ذلك تلقائيًا. عندها سيبقى Full Screen هو البديل الآمن.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,12),0,0);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }
}
