package com.smartsidebar.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class FloatingWindowSettingsActivity extends Activity {
    private SharedPreferences p;
    private TextView assistStatus;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        p=Prefs.sp(this);
        LinearLayout root=Ui.page(this,"النافذة المصغرة");

        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        String status=freeform?"Supported ✓":(Build.VERSION.SDK_INT>=24?"Experimental / OEM dependent":"Not available");
        TextView s=Ui.text(this,"حالة النظام: "+status,15,freeform?Color.rgb(80,220,125):Color.YELLOW,true);
        root.addView(s,Ui.match());

        Ui.section(this,root,"طريقة الفتح");
        String[] modes={
                "Auto — اختر أفضل طريقة تلقائيًا",
                "Official Freeform — Android API فقط",
                "OEM Assist — استخدام قائمة النوافذ الخاصة بالشركة",
                "Full Screen — فتح عادي دائمًا"
        };
        Spinner mode=new Spinner(this);
        ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,modes);
        mode.setAdapter(ad);
        mode.setSelection(Math.max(0,Math.min(3,p.getInt(Prefs.FLOATING_MODE,0))));
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view,int position,long id){
                p.edit().putInt(Prefs.FLOATING_MODE,position).putBoolean(Prefs.FLOATING_TOAST_SHOWN,false).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        root.addView(mode,Ui.match());

        Switch oem=Ui.toggle(this,"تفعيل OEM Floating Window Assist",p.getBoolean(Prefs.OEM_ASSIST,false));
        oem.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(Prefs.OEM_ASSIST,c).apply());
        root.addView(oem,Ui.match());

        assistStatus=Ui.text(this,"",14,Color.WHITE,true);
        root.addView(assistStatus,Ui.match());

        Button accessibility=Ui.button(this,"فتح إعدادات إمكانية الوصول لتفعيل OEM Assist");
        accessibility.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility,Ui.buttonParams(this));

        Switch fallback=Ui.toggle(this,"العودة إلى Full Screen إذا لم تنجح النافذة المصغرة",p.getBoolean(Prefs.FALLBACK_FULLSCREEN,true));
        fallback.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(Prefs.FALLBACK_FULLSCREEN,c).apply());
        root.addView(fallback,Ui.match());

        Ui.section(this,root,"كيف تعمل V6؟");
        TextView note=Ui.text(this,
                "Auto: إذا كان الهاتف يعلن Freeform رسميًا، يستخدم Android API. وإذا لم يعلن ذلك وكان OEM Assist مفعّلًا، يفتح التطبيق ثم يحاول استخدام أمر Floating Window / Pop-up View الظاهر في واجهة Recent Apps.\n\n"+
                "OEM Assist اختياري ويتطلب موافقتك الصريحة على خدمة إمكانية الوصول. لا يقرأ كلمات المرور أو الرسائل ولا يرسل بيانات للإنترنت. لكنه تجريبي لأن أسماء وقوائم OPPO/realme/Samsung/Xiaomi/vivo قد تتغير مع تحديثات النظام.\n\n"+
                "إذا لم يجد الأمر، يرجع للتطبيق ويتركه مفتوحًا بشكل عادي بدل التعطل.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,10),0,0);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
        refreshStatus();
    }

    @Override protected void onResume(){
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus(){
        if(assistStatus==null)return;
        boolean enabled=OemFloatingAccessibilityService.isEnabled(this);
        assistStatus.setText(enabled?"OEM Assist accessibility: Enabled ✓":"OEM Assist accessibility: Not enabled ✕");
        assistStatus.setTextColor(enabled?Color.rgb(80,220,125):Color.YELLOW);
    }
}
