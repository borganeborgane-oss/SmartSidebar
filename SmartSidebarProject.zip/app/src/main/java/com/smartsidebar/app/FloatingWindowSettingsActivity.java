package com.smartsidebar.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class FloatingWindowSettingsActivity extends Activity {
    private SharedPreferences p;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        p=Prefs.sp(this);
        LinearLayout root=Ui.page(this,"النافذة المصغرة");

        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        String status=freeform?"Supported ✓":(Build.VERSION.SDK_INT>=24?"OEM-specific / not exposed to normal apps":"Not available");
        TextView s=Ui.text(this,"حالة النظام: "+status,15,freeform?Color.rgb(80,220,125):Color.YELLOW,true);
        root.addView(s,Ui.match());

        Ui.section(this,root,"طريقة الفتح");
        String[] modes={
                "Auto — اختر أفضل طريقة آمنة تلقائيًا",
                "Official Freeform — Android API فقط",
                "Full Screen — فتح عادي دائمًا"
        };
        Spinner mode=new Spinner(this);
        ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,modes);
        mode.setAdapter(ad);
        int saved=p.getInt(Prefs.FLOATING_MODE,0);
        int selection=saved==1?1:(saved==3?2:0);
        mode.setSelection(selection);
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view,int position,long id){
                int internal=position==1?1:(position==2?3:0);
                p.edit().putInt(Prefs.FLOATING_MODE,internal).putBoolean(Prefs.OEM_ASSIST,false).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        root.addView(mode,Ui.match());

        Switch fallback=Ui.toggle(this,"العودة إلى Full Screen إذا لم تنجح النافذة المصغرة",p.getBoolean(Prefs.FALLBACK_FULLSCREEN,true));
        fallback.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(Prefs.FALLBACK_FULLSCREEN,c).apply());
        root.addView(fallback,Ui.match());

        Ui.section(this,root,"V6.1 Safe");
        TextView note=Ui.text(this,
                "أزلنا خدمة Accessibility من هذه النسخة حتى لا يطلب التطبيق صلاحية حساسة يمكن أن تؤدي إلى حظر التثبيت بواسطة Play Protect عند تثبيت APK خارج Google Play.\n\n"+
                "Auto يستخدم Official Freeform فقط عندما يعلن Android دعمه. على OPPO/ColorOS الذي لا يعلن Freeform لتطبيقات الطرف الثالث، سيفتح التطبيق Full Screen. هذا قيد من النظام وليس عطلًا في Smart Sidebar.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,10),0,0);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }
}
