package com.smartsidebar.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.*;

public class FloatingWindowSettingsActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        SharedPreferences p=Prefs.sp(this);
        LinearLayout root=Ui.page(this,"النافذة المصغرة");

        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);
        String status=freeform?"Supported ✓":
                (Build.VERSION.SDK_INT>=24?"Experimental / OEM dependent":"Not available");

        TextView s=Ui.text(this,"حالة النظام: "+status,15,freeform?Color.rgb(80,220,125):Color.YELLOW,true);
        root.addView(s,Ui.match());

        Switch attempt=Ui.toggle(this,"Open apps in floating window when supported",p.getBoolean(Prefs.TRY_FLOATING,false));
        attempt.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(Prefs.TRY_FLOATING,c).putBoolean(Prefs.FLOATING_TOAST_SHOWN,false).apply());
        root.addView(attempt,Ui.match());

        Switch fallback=Ui.toggle(this,"العودة إلى Full Screen إذا لم تنجح النافذة المصغرة",p.getBoolean(Prefs.FALLBACK_FULLSCREEN,true));
        fallback.setOnCheckedChangeListener((v,c)->p.edit().putBoolean(Prefs.FALLBACK_FULLSCREEN,c).apply());
        root.addView(fallback,Ui.match());

        TextView note=Ui.text(this,
                "هذه الميزة تستخدم ActivityOptions.setLaunchBounds() و FLAG_ACTIVITY_LAUNCH_ADJACENT فقط. بعض هواتف OPPO/realme/Samsung/Xiaomi وغيرها قد تسمح بذلك، وبعضها يتجاهله. التطبيق لا يستخدم Root أو Accessibility أو Private APIs.",
                13,Color.LTGRAY,false);
        note.setPadding(0,Ui.dp(this,12),0,0);
        root.addView(note,Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }
}
