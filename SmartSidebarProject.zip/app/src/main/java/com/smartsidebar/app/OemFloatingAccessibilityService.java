package com.smartsidebar.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Optional OEM helper. It never runs unless the user explicitly enables the
 * accessibility service and chooses OEM Assist (or Auto on a device without
 * advertised Freeform support).
 *
 * It uses only public AccessibilityService APIs. OEM recent-app menus are not
 * standardized, so this remains best-effort and can stop working after an OEM
 * update. On failure it returns to the launched app instead of leaving the user
 * stuck in Recents.
 */
public class OemFloatingAccessibilityService extends AccessibilityService {

    private static volatile OemFloatingAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String pendingPackage;
    private String pendingLabel;
    private boolean inAttempt;

    private static final List<String> GENERIC_FLOATING_WORDS = Arrays.asList(
            "floating window", "floating windows", "float window",
            "mini window", "small window", "flexible window", "flexible windows",
            "pop-up view", "popup view", "pop up view", "pop-up window", "popup window",
            "open in pop-up view", "open in popup view",
            "fenêtre flottante", "fenetres flottantes", "fenêtre flexible", "fenetre flexible",
            "fenêtre pop-up", "fenetre pop-up", "fenêtre contextuelle",
            "نافذة عائمة", "النوافذ العائمة", "نافذة مصغرة", "نافذة صغيرة", "نافذة مرنة", "نوافذ مرنة",
            "عرض منبثق", "نافذة منبثقة"
    );

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
            if (Build.VERSION.SDK_INT >= 21) {
                info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            }
            setServiceInfo(info);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // The sequence is driven by delayed checks; events simply help us retry
        // when an OEM menu appears a little later than expected.
        if (!inAttempt || event == null) return;
        int type = event.getEventType();
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            handler.removeCallbacks(retryKeywordRunnable);
            handler.postDelayed(retryKeywordRunnable, 220);
        }
    }

    @Override
    public void onInterrupt() { }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        if (instance == this) instance = null;
        inAttempt = false;
        handler.removeCallbacksAndMessages(null);
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        inAttempt = false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    public static boolean isEnabled(Context context) {
        String enabled = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName me = new ComponentName(context, OemFloatingAccessibilityService.class);
        for (String item : enabled.split(":")) {
            ComponentName c = ComponentName.unflattenFromString(item);
            if (me.equals(c)) return true;
        }
        return false;
    }

    public static boolean requestFloatingWindow(Context context, String packageName) {
        OemFloatingAccessibilityService s = instance;
        if (s == null || TextUtils.isEmpty(packageName)) return false;
        s.beginAttempt(packageName);
        return true;
    }

    private void beginAttempt(String packageName) {
        pendingPackage = packageName;
        pendingLabel = loadLabel(packageName);
        inAttempt = true;
        handler.removeCallbacksAndMessages(null);

        // Let the launched app become foreground first, then ask Android for Recents.
        handler.postDelayed(() -> {
            if (!inAttempt) return;
            performGlobalAction(GLOBAL_ACTION_RECENTS);
        }, 720);

        // First try: some OEMs expose the floating-window action directly in Recents.
        handler.postDelayed(() -> {
            if (!inAttempt) return;
            if (clickFloatingAction()) {
                finishSuccess();
                return;
            }
            // Second try: tap the target app header/icon/label to open its task menu.
            if (clickTargetAppHeader()) {
                handler.postDelayed(() -> {
                    if (!inAttempt) return;
                    if (clickFloatingAction()) finishSuccess();
                }, 520);
            }
        }, 1380);

        // Final check/fallback: never leave the user stranded in Recents.
        handler.postDelayed(() -> {
            if (!inAttempt) return;
            if (clickFloatingAction()) {
                finishSuccess();
                return;
            }
            failAndReturn();
        }, 2750);
    }

    private final Runnable retryKeywordRunnable = () -> {
        if (!inAttempt) return;
        if (clickFloatingAction()) finishSuccess();
    };

    private boolean clickFloatingAction() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;

        List<String> words = new ArrayList<>(GENERIC_FLOATING_WORDS);
        String m = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase(Locale.ROOT);
        if (m.contains("samsung")) {
            words.add("open in pop-up view");
            words.add("pop-up view");
        } else if (m.contains("oppo") || m.contains("realme") || m.contains("oneplus")) {
            words.add("floating window");
            words.add("flexible window");
            words.add("mini window");
        } else if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")) {
            words.add("floating windows");
            words.add("floating window");
        } else if (m.contains("vivo") || m.contains("iqoo")) {
            words.add("small window");
            words.add("floating window");
        }

        AccessibilityNodeInfo node = findByAnyText(root, words);
        if (node == null) return false;
        return clickNodeOrParent(node);
    }

    private boolean clickTargetAppHeader() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || TextUtils.isEmpty(pendingLabel)) return false;
        AccessibilityNodeInfo node = findByAnyText(root, Arrays.asList(
                pendingLabel,
                pendingLabel.toLowerCase(Locale.ROOT)
        ));
        if (node == null) return false;

        // Prefer a normal click. On many Recents UIs the app icon/label opens a task menu.
        if (clickNodeOrParent(node)) return true;

        // Best-effort fallback to long click if the OEM exposes the action that way.
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 4 && n != null; i++, n = n.getParent()) {
            if ((n.getActions() & AccessibilityNodeInfo.ACTION_LONG_CLICK) != 0 &&
                    n.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) {
                return true;
            }
        }
        return false;
    }

    private AccessibilityNodeInfo findByAnyText(AccessibilityNodeInfo node, List<String> needles) {
        if (node == null) return null;
        String text = normalize(node.getText());
        String desc = normalize(node.getContentDescription());

        for (String n : needles) {
            String needle = normalize(n);
            if (!needle.isEmpty() && (text.contains(needle) || desc.contains(needle))) {
                return node;
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findByAnyText(node.getChild(i), needles);
            if (found != null) return found;
        }
        return null;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 6 && n != null; i++, n = n.getParent()) {
            if (n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            if ((n.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0 &&
                    n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        return false;
    }

    private String normalize(CharSequence s) {
        return s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
    }

    private String loadLabel(String packageName) {
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(packageName, 0);
            CharSequence label = getPackageManager().getApplicationLabel(ai);
            return label == null ? packageName : label.toString();
        } catch (Exception e) {
            return packageName;
        }
    }

    private void finishSuccess() {
        inAttempt = false;
        handler.removeCallbacksAndMessages(null);
    }

    private void failAndReturn() {
        inAttempt = false;
        handler.removeCallbacksAndMessages(null);
        // Close any task menu/Recents and return to the launched app.
        performGlobalAction(GLOBAL_ACTION_BACK);
        handler.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_BACK), 180);
        handler.postDelayed(() -> Toast.makeText(
                this,
                "لم يتم العثور على أمر النافذة العائمة في واجهة هذا الهاتف. تم فتح التطبيق بشكل عادي.",
                Toast.LENGTH_LONG).show(), 350);
    }
}
