package com.smartsidebar.app;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;

import java.util.*;

public class OppoAppTestActivity extends Activity {
    private String pendingPackage;
    private String pendingLabel;
    private LinearLayout list;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"اختبار OPPO / ColorOS");

        TextView intro=Ui.text(this,
                "اختبر كل تطبيق. بعد الرجوع إلى Smart Sidebar سنسألك هل ظهر التطبيق كنافذة عائمة أم فتح كامل الشاشة. النتيجة تُحفظ على هذا الهاتف فقط.",
                13,Color.LTGRAY,false);
        root.addView(intro,Ui.match());

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list,Ui.match());
        render();
        setContentView(Ui.scrollPage(this,root));
    }

    @Override protected void onResume(){
        super.onResume();
        if(pendingPackage!=null){
            final String pkg=pendingPackage;
            final String label=pendingLabel==null?pkg:pendingLabel;
            pendingPackage=null;
            pendingLabel=null;
            new android.app.AlertDialog.Builder(this)
                    .setTitle("نتيجة اختبار "+label)
                    .setMessage("كيف فُتح التطبيق؟")
                    .setPositiveButton("نافذة عائمة ✓",(d,w)->{Prefs.setOppoTest(this,pkg,1);render();})
                    .setNegativeButton("كامل الشاشة",(d,w)->{Prefs.setOppoTest(this,pkg,-1);render();})
                    .setNeutralButton("غير متأكد",(d,w)->{})
                    .show();
        }
    }

    private void render(){
        if(list==null)return;
        list.removeAllViews();
        List<ResolveInfo> apps=selectedApps();
        if(apps.isEmpty()){
            list.addView(Ui.text(this,"لا توجد تطبيقات مختارة. اختر التطبيقات أولًا من الصفحة الرئيسية.",14,Color.LTGRAY,false),Ui.match());
            return;
        }
        for(ResolveInfo r:apps){
            String pkg=r.activityInfo.packageName;
            String label=r.loadLabel(getPackageManager()).toString();
            int state=Prefs.getOppoTest(this,pkg);

            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0,Ui.dp(this,8),0,Ui.dp(this,8));

            TextView title=Ui.text(this,label,15,Color.WHITE,true);
            row.addView(title,Ui.match());
            String stateText=state==1?"النتيجة: يعمل كنافذة عائمة ✓":state==-1?"النتيجة: يفتح Full Screen":"النتيجة: غير مختبر";
            TextView st=Ui.text(this,stateText,13,state==1?Color.rgb(80,220,125):(state==-1?Color.YELLOW:Color.LTGRAY),false);
            row.addView(st,Ui.match());

            Button b=Ui.button(this,"اختبار الآن");
            b.setAllCaps(false);
            b.setOnClickListener(v->testLaunch(pkg,label));
            LinearLayout.LayoutParams bp=Ui.buttonParams(this);
            bp.height=Ui.dp(this,48);
            row.addView(b,bp);
            list.addView(row,Ui.match());
        }
    }

    private void testLaunch(String pkg,String label){
        Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);
        if(launch==null){Toast.makeText(this,"التطبيق غير متوفر",Toast.LENGTH_SHORT).show();return;}
        pendingPackage=pkg;
        pendingLabel=label;
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_MULTIPLE_TASK|Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT);
        try{
            ActivityOptions o=ActivityOptions.makeBasic();
            int sw=getResources().getDisplayMetrics().widthPixels;
            int sh=getResources().getDisplayMetrics().heightPixels;
            int w=(int)(sw*.72f), h=(int)(sh*.66f);
            int l=(sw-w)/2, t=(sh-h)/2;
            o.setLaunchBounds(new Rect(l,t,l+w,t+h));
            startActivity(launch,o.toBundle());
        }catch(Exception e){
            try{startActivity(launch);}catch(Exception ignored){}
        }
    }

    private List<ResolveInfo> selectedApps(){
        Intent q=new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> all=getPackageManager().queryIntentActivities(q,0);
        Map<String,ResolveInfo> map=new HashMap<>();
        for(ResolveInfo r:all) map.put(r.activityInfo.packageName,r);
        ArrayList<ResolveInfo> out=new ArrayList<>();
        for(String pkg:Prefs.getAppOrder(this)){
            ResolveInfo r=map.get(pkg);
            if(r!=null)out.add(r);
        }
        return out;
    }
}
