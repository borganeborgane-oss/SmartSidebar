package com.smartsidebar.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class SidebarSettingsActivity extends Activity {
    private SharedPreferences p;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); p=Prefs.sp(this);
        LinearLayout root=Ui.page(this,"مظهر القائمة");

        Ui.section(this,root,"القائمة العمودية");
        TextView note=Ui.text(this,"القائمة تظهر عموديًا من نفس حافة المقبض، وتدعم تمريرًا رأسيًا حتى 10 تطبيقات.",13,android.graphics.Color.LTGRAY,false);
        root.addView(note,Ui.match());

        slider(root,"عرض القائمة",160,360,p.getInt(Prefs.PANEL_WIDTH,230),v->{p.edit().putInt(Prefs.PANEL_WIDTH,v).apply();refresh();});
        slider(root,"شفافية القائمة",40,100,p.getInt(Prefs.PANEL_OPACITY,92),v->{p.edit().putInt(Prefs.PANEL_OPACITY,v).apply();refresh();});
        slider(root,"استدارة الزوايا",0,40,p.getInt(Prefs.PANEL_RADIUS,24),v->{p.edit().putInt(Prefs.PANEL_RADIUS,v).apply();refresh();});

        spinner(root,"الخلفية",new String[]{"داكنة","فاتحة","شفافة"},p.getInt(Prefs.PANEL_BG,0),
                v->{p.edit().putInt(Prefs.PANEL_BG,v).apply();refresh();});

        Ui.section(this,root,"الأيقونات");
        slider(root,"حجم الأيقونة",32,76,p.getInt(Prefs.ICON_SIZE,48),v->{p.edit().putInt(Prefs.ICON_SIZE,v).apply();refresh();});
        spinner(root,"شكل مربع الأيقونة",new String[]{"Rounded Square","Circle","Squircle","Square"},p.getInt(Prefs.ICON_SHAPE,0),
                v->{p.edit().putInt(Prefs.ICON_SHAPE,v).apply();refresh();});

        Switch names=Ui.toggle(this,"إظهار أسماء التطبيقات",p.getBoolean(Prefs.SHOW_NAMES,true));
        names.setOnCheckedChangeListener((v,c)->{p.edit().putBoolean(Prefs.SHOW_NAMES,c).apply();refresh();});
        root.addView(names,Ui.match());

        slider(root,"حجم اسم التطبيق",10,18,p.getInt(Prefs.FONT_SIZE,13),v->{p.edit().putInt(Prefs.FONT_SIZE,v).apply();refresh();});
        slider(root,"المسافة بين التطبيقات",0,24,p.getInt(Prefs.SPACING,7),v->{p.edit().putInt(Prefs.SPACING,v).apply();refresh();});

        Ui.section(this,root,"الموضع والحركة");
        spinner(root,"موضع القائمة",new String[]{"أعلى","الوسط","أسفل"},p.getInt(Prefs.PANEL_POSITION,1),
                v->{p.edit().putInt(Prefs.PANEL_POSITION,v).apply();refresh();});
        spinner(root,"حركة الفتح",new String[]{"Slide","Fade","Scale","None"},p.getInt(Prefs.ANIMATION,0),
                v->{p.edit().putInt(Prefs.ANIMATION,v).apply();refresh();});
        spinner(root,"سرعة الحركة",new String[]{"Fast","Normal","Slow"},p.getInt(Prefs.ANIMATION_SPEED,1),
                v->{p.edit().putInt(Prefs.ANIMATION_SPEED,v).apply();refresh();});

        setContentView(Ui.scrollPage(this,root));
    }

    private interface Pos{void set(int x);}
    private void spinner(LinearLayout root,String label,String[] vals,int sel,Pos cb){
        Ui.spinner(this,root,label,vals,sel,new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> a,View v,int pos,long id){cb.set(pos);}
            public void onNothingSelected(AdapterView<?> a){}
        });
    }
    private interface Val{void set(int x);}
    private void slider(LinearLayout root,String label,int min,int max,int cur,Val cb){
        TextView t=Ui.value(this,root,label+": "+cur);
        SeekBar s=Ui.seek(this,root,max-min,cur-min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int x,boolean f){int v=x+min;t.setText(label+": "+v);cb.set(v);}
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){}
        });
    }
    private void refresh(){
        if(!p.getBoolean(Prefs.RUNNING,false))return;
        android.content.Intent i=new android.content.Intent(this,FloatingSidebarService.class);i.setAction(FloatingSidebarService.ACTION_REFRESH);
        if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
    }
}
