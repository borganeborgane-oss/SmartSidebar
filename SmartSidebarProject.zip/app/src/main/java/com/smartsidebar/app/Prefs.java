package com.smartsidebar.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class Prefs {
    public static final String FILE = "sidebar_prefs";
    public static final int MAX_APPS = 10;

    public static final String RUNNING = "running";
    public static final String HANDLE_ENABLED = "handle_enabled";
    public static final String SIDE = "side";
    public static final String HANDLE_STYLE = "handle_style";
    public static final String HANDLE_COLOR = "handle_color";
    public static final String HANDLE_ICON = "handle_icon";
    public static final String HANDLE_OPACITY = "handle_opacity";
    public static final String HANDLE_WIDTH = "handle_width";
    public static final String HANDLE_HEIGHT = "handle_height";
    public static final String HANDLE_Y = "handle_y";
    public static final String REMEMBER_POSITION = "remember_position";
    public static final String AUTO_HIDE = "auto_hide";
    public static final String AUTO_HIDE_DELAY = "auto_hide_delay";

    public static final String PANEL_WIDTH = "panel_width";
    public static final String PANEL_OPACITY = "panel_opacity";
    public static final String PANEL_BG = "panel_bg";
    public static final String PANEL_RADIUS = "panel_radius";
    public static final String ICON_SIZE = "icon_size";
    public static final String ICON_SHAPE = "icon_shape";
    public static final String SHOW_NAMES = "show_names";
    public static final String FONT_SIZE = "font_size";
    public static final String SPACING = "spacing";
    public static final String PANEL_POSITION = "panel_position";
    public static final String ANIMATION = "animation";
    public static final String ANIMATION_SPEED = "animation_speed";

    public static final String AUTO_CLOSE = "auto_close";
    public static final String CLOSE_OUTSIDE = "close_outside";
    public static final String HAPTIC = "haptic";
    public static final String SOUND = "sound";
    public static final String START_BOOT = "start_boot";

    public static final String TRY_FLOATING = "try_floating";
    public static final String FLOATING_MODE = "floating_mode"; // 0 Auto, 1 Official Freeform, 2 OEM Assist, 3 Full Screen
    public static final String OEM_ASSIST = "oem_assist";
    public static final String FALLBACK_FULLSCREEN = "fallback_fullscreen";
    public static final String FLOATING_TOAST_SHOWN = "floating_toast_shown";

    public static final String APPS_INITIALIZED = "apps_initialized";
    public static final String APP_ORDER = "app_order";

    private Prefs() {}

    public static SharedPreferences sp(Context c) {
        SharedPreferences p = c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        ensureDefaults(p);
        return p;
    }

    private static void ensureDefaults(SharedPreferences p) {
        if (p.contains(HANDLE_ENABLED)) return;
        p.edit()
                .putBoolean(HANDLE_ENABLED, true)
                .putString(SIDE, "right")
                .putInt(HANDLE_STYLE, 0)
                .putInt(HANDLE_COLOR, 0)
                .putInt(HANDLE_ICON, 0)
                .putInt(HANDLE_OPACITY, 82)
                .putInt(HANDLE_WIDTH, 28)
                .putInt(HANDLE_HEIGHT, 82)
                .putInt(HANDLE_Y, 0)
                .putBoolean(REMEMBER_POSITION, true)
                .putBoolean(AUTO_HIDE, true)
                .putInt(AUTO_HIDE_DELAY, 2)

                .putInt(PANEL_WIDTH, 230)
                .putInt(PANEL_OPACITY, 92)
                .putInt(PANEL_BG, 0)
                .putInt(PANEL_RADIUS, 24)
                .putInt(ICON_SIZE, 48)
                .putInt(ICON_SHAPE, 0)
                .putBoolean(SHOW_NAMES, true)
                .putInt(FONT_SIZE, 13)
                .putInt(SPACING, 7)
                .putInt(PANEL_POSITION, 1)
                .putInt(ANIMATION, 0)
                .putInt(ANIMATION_SPEED, 1)

                .putBoolean(AUTO_CLOSE, true)
                .putBoolean(CLOSE_OUTSIDE, true)
                .putBoolean(HAPTIC, true)
                .putBoolean(SOUND, false)
                .putBoolean(START_BOOT, false)

                .putBoolean(TRY_FLOATING, false)
                .putInt(FLOATING_MODE, 0)
                .putBoolean(OEM_ASSIST, false)
                .putBoolean(FALLBACK_FULLSCREEN, true)
                .apply();
    }

    public static List<String> getAppOrder(Context c) {
        String raw = sp(c).getString(APP_ORDER, "[]");
        ArrayList<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                String pkg = a.optString(i, "");
                if (!pkg.isEmpty()) out.add(pkg);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static void saveAppOrder(Context c, List<String> order) {
        JSONArray a = new JSONArray();
        int limit = Math.min(order.size(), MAX_APPS);
        for (int i = 0; i < limit; i++) a.put(order.get(i));
        sp(c).edit()
                .putString(APP_ORDER, a.toString())
                .putBoolean(APPS_INITIALIZED, true)
                .apply();
    }

    public static String exportJson(Context c) {
        SharedPreferences p = sp(c);
        JSONObject j = new JSONObject();
        try {
            for (String key : p.getAll().keySet()) {
                Object value = p.getAll().get(key);
                if (value instanceof Boolean) j.put(key, value);
                else if (value instanceof Integer) j.put(key, value);
                else if (value instanceof String) j.put(key, value);
            }
        } catch (Exception ignored) {}
        return j.toString();
    }

    public static boolean importJson(Context c, String raw) {
        try {
            JSONObject j = new JSONObject(raw);
            SharedPreferences.Editor e = sp(c).edit();
            java.util.Iterator<String> keys = j.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                Object v = j.get(key);
                if (v instanceof Boolean) e.putBoolean(key, (Boolean) v);
                else if (v instanceof Integer) e.putInt(key, (Integer) v);
                else if (v instanceof Number) e.putInt(key, ((Number) v).intValue());
                else if (v instanceof String) e.putString(key, (String) v);
            }
            e.apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
