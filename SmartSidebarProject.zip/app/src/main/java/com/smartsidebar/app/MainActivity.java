package com.smartsidebar.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private TextView statusText, handleOpacityText, panelOpacityText, handleSizeText, iconSizeText, columnsText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("sidebar_prefs", MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2001);
        }

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(34), dp(20), dp(34));
        root.setBackgroundColor(Color.rgb(18, 18, 18));
        scroll.addView(root);

        TextView title = label("Smart Sidebar", 29, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, fullWrap());

        TextView subtitle = label("Professional Settings", 14, Color.LTGRAY, false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleParams = fullWrap();
        subtitleParams.bottomMargin = dp(18);
        root.addView(subtitle, subtitleParams);

        statusText = label("", 15, Color.WHITE, true);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(8), dp(10), dp(8), dp(10));
        root.addView(statusText, fullWrap());

        Button chooseApps = button("اختيار التطبيقات (حتى 30 تطبيقًا)");
        chooseApps.setOnClickListener(v -> startActivity(new Intent(this, AppSelectionActivity.class)));
        root.addView(chooseApps, buttonParams());

        addSection(root, "المقبض الجانبي");

        addSpinnerRow(root, "شكل المقبض",
                new String[]{"كبسولة", "دائرة", "خط نحيف"},
                prefs.getInt("handle_style", 0),
                pos -> prefs.edit().putInt("handle_style", pos).apply());

        addSpinnerRow(root, "مكان المقبض",
                new String[]{"يمين الشاشة", "يسار الشاشة"},
                prefs.getString("side", "right").equals("right") ? 0 : 1,
                pos -> prefs.edit().putString("side", pos == 0 ? "right" : "left").apply());

        addSpinnerRow(root, "لون المقبض",
                new String[]{"رمادي داكن", "أزرق", "أخضر", "بنفسجي", "أحمر"},
                prefs.getInt("handle_color", 0),
                pos -> prefs.edit().putInt("handle_color", pos).apply());

        handleOpacityText = settingText(root);
        SeekBar handleOpacity = seek(root, 70, prefs.getInt("handle_opacity", 82) - 30);
        updateHandleOpacity(handleOpacity.getProgress());
        handleOpacity.setOnSeekBarChangeListener(listener(v -> {
            prefs.edit().putInt("handle_opacity", v + 30).apply();
            updateHandleOpacity(v);
        }));

        handleSizeText = settingText(root);
        SeekBar handleSize = seek(root, 40, prefs.getInt("handle_size", 34) - 24);
        updateHandleSize(handleSize.getProgress());
        handleSize.setOnSeekBarChangeListener(listener(v -> {
            prefs.edit().putInt("handle_size", v + 24).apply();
            updateHandleSize(v);
        }));

        addSection(root, "لوحة التطبيقات");

        panelOpacityText = settingText(root);
        SeekBar panelOpacity = seek(root, 60, prefs.getInt("panel_opacity", 90) - 40);
        updatePanelOpacity(panelOpacity.getProgress());
        panelOpacity.setOnSeekBarChangeListener(listener(v -> {
            prefs.edit().putInt("panel_opacity", v + 40).apply();
            updatePanelOpacity(v);
        }));

        columnsText = settingText(root);
        SeekBar columns = seek(root, 2, prefs.getInt("columns", 3) - 2);
        updateColumns(columns.getProgress());
        columns.setOnSeekBarChangeListener(listener(v -> {
            prefs.edit().putInt("columns", v + 2).apply();
            updateColumns(v);
        }));

        iconSizeText = settingText(root);
        SeekBar iconSize = seek(root, 36, prefs.getInt("icon_size", 52) - 36);
        updateIconSize(iconSize.getProgress());
        iconSize.setOnSeekBarChangeListener(listener(v -> {
            prefs.edit().putInt("icon_size", v + 36).apply();
            updateIconSize(v);
        }));

        addSpinnerRow(root, "موضع اللوحة",
                new String[]{"أعلى", "الوسط", "أسفل"},
                prefs.getInt("panel_position", 1),
                pos -> prefs.edit().putInt("panel_position", pos).apply());

        Switch showNames = toggle("إظهار أسماء التطبيقات", prefs.getBoolean("show_names", true));
        showNames.setOnCheckedChangeListener((v, checked) ->
                prefs.edit().putBoolean("show_names", checked).apply());
        root.addView(showNames, fullWrap());

        Switch autoClose = toggle("إغلاق اللوحة بعد فتح التطبيق", prefs.getBoolean("auto_close", true));
        autoClose.setOnCheckedChangeListener((v, checked) ->
                prefs.edit().putBoolean("auto_close", checked).apply());
        root.addView(autoClose, fullWrap());

        Switch haptic = toggle("اهتزاز خفيف عند فتح اللوحة", prefs.getBoolean("haptic", true));
        haptic.setOnCheckedChangeListener((v, checked) ->
                prefs.edit().putBoolean("haptic", checked).apply());
        root.addView(haptic, fullWrap());

        addSection(root, "طريقة فتح التطبيقات");

        addSpinnerRow(root, "وضع الفتح",
                new String[]{"عادي", "محاولة نافذة متعددة"},
                prefs.getBoolean("try_floating", false) ? 1 : 0,
                pos -> prefs.edit().putBoolean("try_floating", pos == 1).apply());

        TextView note = label(
                "وضع «محاولة نافذة متعددة» يعتمد على دعم نظام الهاتف. لا يستطيع تطبيق عادي إجبار تطبيق آخر على نافذة عائمة خاصة بالشركة المصنّعة.",
                13, Color.GRAY, false);
        LinearLayout.LayoutParams noteParams = fullWrap();
        noteParams.topMargin = dp(6);
        root.addView(note, noteParams);

        addSection(root, "التحكم");

        Button apply = button("تطبيق الإعدادات الآن");
        apply.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission();
                return;
            }
            Intent i = new Intent(this, FloatingSidebarService.class);
            i.setAction(FloatingSidebarService.ACTION_REFRESH);
            startSidebar(i);
            Toast.makeText(this, "تم تطبيق الإعدادات", Toast.LENGTH_SHORT).show();
        });
        root.addView(apply, buttonParams());

        Button start = button("تشغيل Smart Sidebar");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission();
                return;
            }
            startSidebar(new Intent(this, FloatingSidebarService.class));
            Toast.makeText(this, "تم تشغيل الشريط", Toast.LENGTH_SHORT).show();
            refreshStatus();
        });
        root.addView(start, buttonParams());

        Button stop = button("إيقاف Smart Sidebar");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingSidebarService.class));
            prefs.edit().putBoolean("service_running", false).apply();
            Toast.makeText(this, "تم إيقاف الشريط", Toast.LENGTH_SHORT).show();
            refreshStatus();
        });
        root.addView(stop, buttonParams());

        Button reset = button("استعادة الإعدادات الافتراضية");
        reset.setOnClickListener(v -> {
            boolean initialized = prefs.getBoolean("selection_initialized", false);
            boolean running = prefs.getBoolean("service_running", false);
            java.util.Set<String> selected = new java.util.HashSet<>(
                    prefs.getStringSet("selected_apps", java.util.Collections.emptySet()));
            prefs.edit().clear().apply();
            SharedPreferences.Editor editor = prefs.edit()
                    .putBoolean("service_running", running);
            if (initialized) {
                editor.putBoolean("selection_initialized", true)
                        .putStringSet("selected_apps", selected);
            }
            editor.apply();
            Toast.makeText(this, "تمت استعادة الإعدادات الافتراضية", Toast.LENGTH_SHORT).show();
            recreate();
        });
        root.addView(reset, buttonParams());

        setContentView(scroll);
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        if (statusText == null) return;
        boolean running = prefs.getBoolean("service_running", false);
        statusText.setText(running ? "● الشريط يعمل الآن" : "○ الشريط متوقف");
        statusText.setTextColor(running ? Color.rgb(95, 220, 130) : Color.LTGRAY);
    }

    private void requestOverlayPermission() {
        startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
    }

    private void startSidebar(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
    }

    private void addSection(LinearLayout root, String text) {
        TextView t = label(text, 18, Color.rgb(90, 170, 255), true);
        LinearLayout.LayoutParams p = fullWrap();
        p.topMargin = dp(22);
        p.bottomMargin = dp(8);
        root.addView(t, p);
    }

    private interface PositionListener { void onPosition(int position); }

    private void addSpinnerRow(LinearLayout root, String title, String[] items, int selected, PositionListener callback) {
        root.addView(label(title, 15, Color.WHITE, false), fullWrap());

        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, items);
        spinner.setAdapter(adapter);
        spinner.setSelection(Math.max(0, Math.min(selected, items.length - 1)));
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                callback.onPosition(position);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        LinearLayout.LayoutParams p = fullWrap();
        p.bottomMargin = dp(10);
        root.addView(spinner, p);
    }

    private TextView settingText(LinearLayout root) {
        TextView t = label("", 15, Color.WHITE, false);
        root.addView(t, fullWrap());
        return t;
    }

    private SeekBar seek(LinearLayout root, int max, int progress) {
        SeekBar s = new SeekBar(this);
        s.setMax(max);
        s.setProgress(Math.max(0, Math.min(progress, max)));
        LinearLayout.LayoutParams p = fullWrap();
        p.bottomMargin = dp(8);
        root.addView(s, p);
        return s;
    }

    private Switch toggle(String text, boolean checked) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setTextColor(Color.WHITE);
        s.setTextSize(15);
        s.setChecked(checked);
        s.setPadding(0, dp(6), 0, dp(6));
        return s;
    }

    private void updateHandleOpacity(int p) { handleOpacityText.setText("شفافية المقبض: " + (p + 30) + "%"); }
    private void updatePanelOpacity(int p) { panelOpacityText.setText("شفافية اللوحة: " + (p + 40) + "%"); }
    private void updateHandleSize(int p) { handleSizeText.setText("حجم المقبض: " + (p + 24)); }
    private void updateIconSize(int p) { iconSizeText.setText("حجم أيقونات التطبيقات: " + (p + 36)); }
    private void updateColumns(int p) { columnsText.setText("عدد الأعمدة: " + (p + 2)); }

    private SeekBar.OnSeekBarChangeListener listener(java.util.function.IntConsumer consumer) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { consumer.accept(progress); }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        return b;
    }

    private LinearLayout.LayoutParams fullWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        p.topMargin = dp(9);
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
