package com.smartsidebar.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView status;
    private Switch masterSwitch;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Prefs.sp(this);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 40);
        }

        LinearLayout root = Ui.page(this, "Smart Sidebar");

        TextView subtitle = Ui.text(this, "Universal Android Sidebar", 14, Color.LTGRAY, false);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, Ui.match());

        status = Ui.text(this, "", 15, Color.WHITE, true);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, Ui.dp(this,10), 0, Ui.dp(this,10));
        root.addView(status, Ui.match());

        masterSwitch = Ui.toggle(this, "تشغيل Smart Sidebar", prefs.getBoolean(Prefs.RUNNING, false));
        masterSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (checked) startSidebar();
            else stopSidebar();
        });
        root.addView(masterSwitch, Ui.match());

        addMenu(root, "التطبيقات", "اختيار وترتيب من 1 إلى 10 تطبيقات", AppSelectionActivity.class);
        addMenu(root, "المقبض العائم", "الشكل، اللون، الحجم، المكان، الإخفاء التلقائي", HandleSettingsActivity.class);
        addMenu(root, "مظهر القائمة", "قائمة عمودية، حجم الأيقونات، الخلفية والحركة", SidebarSettingsActivity.class);
        addMenu(root, "السلوك", "الإغلاق، الاهتزاز، الصوت، التشغيل بعد إعادة التشغيل", BehaviorSettingsActivity.class);
        addMenu(root, "النافذة المصغرة", "Auto / OPPO Enhanced / Official Freeform", FloatingWindowSettingsActivity.class);
        addMenu(root, "الصلاحيات", "الظهور فوق التطبيقات والإشعارات والبطارية", PermissionsActivity.class);
        addMenu(root, "توافق الجهاز", "حالة Overlay وFreeform وPiP ومعلومات الهاتف", DeviceCompatibilityActivity.class);
        addMenu(root, "متقدم", "إعادة الضبط، تصدير واستيراد الإعدادات", AdvancedActivity.class);
        addMenu(root, "حول", "الإصدار، الخصوصية والقيود", AboutActivity.class);

        setContentView(Ui.scrollPage(this, root));
        refresh();
    }

    private void addMenu(LinearLayout root, String title, String desc, Class<?> activity) {
        Button b = Ui.button(this, title + "\n" + desc);
        b.setAllCaps(false);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setOnClickListener(v -> startActivity(new Intent(this, activity)));
        LinearLayout.LayoutParams p = Ui.buttonParams(this);
        p.height = Ui.dp(this, 66);
        root.addView(b, p);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        if (prefs == null || status == null) return;
        boolean running = prefs.getBoolean(Prefs.RUNNING, false);
        boolean overlay = Settings.canDrawOverlays(this);
        status.setText((running ? "● يعمل" : "○ متوقف") + "   |   Overlay: " + (overlay ? "مسموح ✓" : "غير مسموح ✕"));
        status.setTextColor(running ? Color.rgb(80,220,125) : Color.LTGRAY);
        if (masterSwitch != null && masterSwitch.isChecked() != running) {
            masterSwitch.setOnCheckedChangeListener(null);
            masterSwitch.setChecked(running);
            masterSwitch.setOnCheckedChangeListener((v, checked) -> {
                if (checked) startSidebar(); else stopSidebar();
            });
        }
    }

    private void startSidebar() {
        if (!Settings.canDrawOverlays(this)) {
            if (masterSwitch != null) masterSwitch.setChecked(false);
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
            Toast.makeText(this, "فعّل «الظهور فوق التطبيقات» ثم شغّل الشريط", Toast.LENGTH_LONG).show();
            return;
        }

        Intent i = new Intent(this, FloatingSidebarService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        prefs.edit().putBoolean(Prefs.RUNNING, true).apply();
        refresh();
    }

    private void stopSidebar() {
        stopService(new Intent(this, FloatingSidebarService.class));
        prefs.edit().putBoolean(Prefs.RUNNING, false).apply();
        refresh();
    }
}
