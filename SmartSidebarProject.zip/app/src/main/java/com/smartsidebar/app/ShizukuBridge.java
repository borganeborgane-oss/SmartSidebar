package com.smartsidebar.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.RemoteException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

public final class ShizukuBridge {
    public interface Callback { void onResult(boolean ok, String message); }

    private static ShizukuBridge instance;
    private final Context app;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private IPrivilegedService remote;
    private boolean binding;
    private final List<Runnable> waiting = new ArrayList<>();

    private ShizukuBridge(Context c) { app = c.getApplicationContext(); }

    public static synchronized ShizukuBridge get(Context c) {
        if (instance == null) instance = new ShizukuBridge(c);
        return instance;
    }

    public boolean binderAlive() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    public boolean hasPermission() {
        try {
            return binderAlive() && !Shizuku.isPreV11() &&
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    public void requestPermission(int requestCode) {
        try {
            if (binderAlive() && !Shizuku.isPreV11()) Shizuku.requestPermission(requestCode);
        } catch (Throwable ignored) {}
    }

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            remote = IPrivilegedService.Stub.asInterface(service);
            binding = false;
            List<Runnable> copy = new ArrayList<>(waiting);
            waiting.clear();
            for (Runnable r : copy) r.run();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            remote = null;
            binding = false;
        }
    };

    private void ensureBound(Runnable onReady, Callback cb) {
        if (!hasPermission()) {
            cb.onResult(false, "Shizuku غير جاهز أو الصلاحية غير ممنوحة");
            return;
        }
        if (remote != null) { onReady.run(); return; }
        waiting.add(onReady);
        if (binding) return;
        binding = true;
        try {
            ComponentName cn = new ComponentName(app.getPackageName(), PrivilegedUserService.class.getName());
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(cn)
                    .processNameSuffix("privileged")
                    .daemon(false)
                    .debuggable(false)
                    .version(2);
            Shizuku.bindUserService(args, connection);
        } catch (Throwable t) {
            binding = false;
            waiting.clear();
            cb.onResult(false, "تعذر ربط خدمة Shizuku: " + t.getMessage());
        }
    }

    public void exec(String command, Callback cb) {
        ensureBound(() -> io.execute(() -> {
            try {
                String result = remote.exec(command);
                cb.onResult(result != null && !result.contains("EXIT=1"), result == null ? "" : result);
            } catch (RemoteException e) {
                remote = null;
                cb.onResult(false, "RemoteException: " + e.getMessage());
            } catch (Throwable t) {
                cb.onResult(false, t.getClass().getSimpleName() + ": " + t.getMessage());
            }
        }), cb);
    }

    public void enableStrongFreeform(Callback cb) {
        String cmd = "settings put global enable_freeform_support 1; " +
                "settings put global force_resizable_activities 1; " +
                "settings put global enable_sizecompat_freeform 1 2>/dev/null || true; " +
                "settings put global enable_non_resizable_multi_window 1 2>/dev/null || true; " +
                "echo enable_freeform_support=$(settings get global enable_freeform_support); " +
                "echo force_resizable_activities=$(settings get global force_resizable_activities)";
        exec(cmd, cb);
    }

    public void readStrongSettings(Callback cb) {
        String cmd = "echo uid=$(id -u); " +
                "echo freeform=$(settings get global enable_freeform_support); " +
                "echo resizable=$(settings get global force_resizable_activities); " +
                "echo sizecompat=$(settings get global enable_sizecompat_freeform 2>/dev/null); " +
                "echo nonresizable_multiwindow=$(settings get global enable_non_resizable_multi_window 2>/dev/null)";
        exec(cmd, cb);
    }

    public void launchFreeform(String component, int l, int t, int r, int b, Callback cb) {
        String safe = component.replace("'", "");
        String bounds = l + "," + t + "," + r + "," + b;
        String cmd = "am start --user current --windowingMode 5 --bounds " + bounds + " -n '" + safe + "' 2>&1; " +
                "echo TRY2; cmd activity start-activity --user current --windowingMode 5 --bounds " + bounds + " -n '" + safe + "' 2>&1 || true";
        exec(cmd, cb);
    }
}
