package com.smartsidebar.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

import java.util.*;

public class AppSelectionActivity extends Activity {

    private static final int MAX_APPS = 30;

    private SharedPreferences prefs;
    private LinearLayout listContainer;
    private TextView countText;
    private EditText search;
    private final List<AppItem> allApps = new ArrayList<>();
    private final LinkedHashSet<String> selected = new LinkedHashSet<>();

    static class AppItem {
        ResolveInfo info;
        String name;
        String packageName;

        AppItem(ResolveInfo info, String name, String packageName) {
            this.info = info;
            this.name = name;
            this.packageName = packageName;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("sidebar_prefs", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(16));
        root.setBackgroundColor(Color.rgb(18, 18, 18));

        TextView title = new TextView(this);
        title.setText("اختيار التطبيقات");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, fullWrap());

        TextView hint = new TextView(this);
        hint.setText("يمكنك إضافة 10 تطبيقات أو أكثر، وبحد أقصى 30 تطبيقًا.");
        hint.setTextColor(Color.LTGRAY);
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = fullWrap();
        hp.bottomMargin = dp(10);
        root.addView(hint, hp);

        countText = new TextView(this);
        countText.setTextColor(Color.rgb(90, 170, 255));
        countText.setTextSize(15);
        countText.setGravity(Gravity.CENTER);
        root.addView(countText, fullWrap());

        search = new EditText(this);
        search.setHint("بحث عن تطبيق...");
        search.setSingleLine(true);
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.GRAY);
        LinearLayout.LayoutParams sp = fullWrap();
        sp.topMargin = dp(8);
        sp.bottomMargin = dp(8);
        root.addView(search, sp);

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);

        Button firstTen = new Button(this);
        firstTen.setText("اختيار 10");
        firstTen.setOnClickListener(v -> selectFirstTenVisible());
        quick.addView(firstTen, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button clear = new Button(this);
        clear.setText("مسح الكل");
        clear.setOnClickListener(v -> {
            selected.clear();
            renderList();
            updateCount();
        });
        quick.addView(clear, new LinearLayout.LayoutParams(0, dp(48), 1));

        root.addView(quick, fullWrap());

        ScrollView scroll = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        Button save = new Button(this);
        save.setText("حفظ التطبيقات");
        save.setTextSize(17);
        save.setOnClickListener(v -> saveSelection());
        root.addView(save, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        loadApps();

        Set<String> saved = prefs.getStringSet("selected_apps", Collections.emptySet());
        selected.addAll(saved);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderList(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        renderList();
        updateCount();
        setContentView(root);
    }

    private void loadApps() {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> apps = getPackageManager().queryIntentActivities(query, 0);

        for (ResolveInfo r : apps) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;

            String name = r.loadLabel(getPackageManager()).toString();
            allApps.add(new AppItem(r, name, pkg));
        }

        allApps.sort(Comparator.comparing(a -> a.name.toLowerCase()));
    }

    private void renderList() {
        if (listContainer == null) return;

        listContainer.removeAllViews();

        String q = search == null ? "" : search.getText().toString().trim().toLowerCase();

        for (AppItem item : allApps) {
            if (!q.isEmpty() && !item.name.toLowerCase().contains(q)) continue;

            CheckBox cb = new CheckBox(this);
            cb.setText(item.name);
            cb.setTextColor(Color.WHITE);
            cb.setTextSize(15);
            cb.setPadding(dp(6), dp(4), dp(6), dp(4));
            cb.setCompoundDrawablesWithIntrinsicBounds(
                    item.info.loadIcon(getPackageManager()), null, null, null);
            cb.setCompoundDrawablePadding(dp(10));
            cb.setChecked(selected.contains(item.packageName));

            cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    if (selected.size() >= MAX_APPS && !selected.contains(item.packageName)) {
                        buttonView.setChecked(false);
                        Toast.makeText(this, "الحد الأقصى 30 تطبيقًا", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    selected.add(item.packageName);
                } else {
                    selected.remove(item.packageName);
                }
                updateCount();
            });

            listContainer.addView(cb, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        }
    }

    private void selectFirstTenVisible() {
        selected.clear();

        String q = search.getText().toString().trim().toLowerCase();
        int added = 0;

        for (AppItem item : allApps) {
            if (!q.isEmpty() && !item.name.toLowerCase().contains(q)) continue;

            selected.add(item.packageName);
            added++;

            if (added == 10) break;
        }

        renderList();
        updateCount();
    }

    private void updateCount() {
        if (countText != null) {
            countText.setText("المحدد: " + selected.size() + " / " + MAX_APPS);
        }
    }

    private void saveSelection() {
        prefs.edit()
                .putStringSet("selected_apps", new HashSet<>(selected))
                .putBoolean("selection_initialized", true)
                .apply();

        Toast.makeText(
                this,
                "تم حفظ " + selected.size() + " تطبيقًا",
                Toast.LENGTH_SHORT).show();

        finish();
    }

    private LinearLayout.LayoutParams fullWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
