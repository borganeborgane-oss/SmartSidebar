package com.smartsidebar.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.*;

public class AppSelectionActivity extends Activity {
    static class AppItem {
        ResolveInfo info;
        String name;
        String pkg;
        AppItem(ResolveInfo r, String n, String p) { info=r; name=n; pkg=p; }
    }

    private final List<AppItem> all = new ArrayList<>();
    private final List<String> selected = new ArrayList<>();
    private LinearLayout selectedBox;
    private LinearLayout allBox;
    private EditText search;
    private TextView counter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = Ui.page(this, "اختيار التطبيقات");

        TextView help = Ui.text(this,
                "اختر من تطبيق واحد إلى 10 كحد أقصى. استخدم ↑ ↓ لترتيبها. الترتيب هنا هو نفسه داخل الشريط.",
                13, Color.LTGRAY, false);
        root.addView(help, Ui.match());

        counter = Ui.text(this, "", 15, Ui.ACCENT, true);
        counter.setGravity(Gravity.CENTER);
        root.addView(counter, Ui.match());

        search = new EditText(this);
        search.setHint("بحث عن تطبيق...");
        search.setSingleLine(true);
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.GRAY);
        root.addView(search, Ui.match());

        Ui.section(this, root, "المختارة وترتيبها");
        selectedBox = new LinearLayout(this);
        selectedBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(selectedBox, Ui.match());

        Ui.section(this, root, "كل التطبيقات");
        allBox = new LinearLayout(this);
        allBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(allBox, Ui.match());

        Button save = Ui.button(this, "حفظ التطبيقات");
        save.setOnClickListener(v -> {
            Prefs.saveAppOrder(this, selected);
            Toast.makeText(this, "تم حفظ " + selected.size() + " تطبيق", Toast.LENGTH_SHORT).show();
            finish();
        });
        root.addView(save, Ui.buttonParams(this));

        loadApps();
        List<String> saved = Prefs.getAppOrder(this);
        if (!saved.isEmpty()) {
            for (String p : saved) if (exists(p)) selected.add(p);
        } else if (!Prefs.sp(this).getBoolean(Prefs.APPS_INITIALIZED, false)) {
            for (int i = 0; i < Math.min(6, all.size()); i++) selected.add(all.get(i).pkg);
        }

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { renderAll(); }
            @Override public void afterTextChanged(Editable e) {}
        });

        render();
        setContentView(Ui.scrollPage(this, root));
    }

    private void loadApps() {
        Intent q = new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = getPackageManager().queryIntentActivities(q, 0);
        for (ResolveInfo r : list) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            all.add(new AppItem(r, r.loadLabel(getPackageManager()).toString(), pkg));
        }
        all.sort(Comparator.comparing(a -> a.name.toLowerCase()));
    }

    private boolean exists(String pkg) {
        for (AppItem a : all) if (a.pkg.equals(pkg)) return true;
        return false;
    }

    private AppItem item(String pkg) {
        for (AppItem a : all) if (a.pkg.equals(pkg)) return a;
        return null;
    }

    private void render() {
        renderSelected();
        renderAll();
        counter.setText("المحدد: " + selected.size() + " / " + Prefs.MAX_APPS);
    }

    private void renderSelected() {
        selectedBox.removeAllViews();
        if (selected.isEmpty()) {
            selectedBox.addView(Ui.text(this, "لا توجد تطبيقات مختارة", 13, Color.GRAY, false));
            return;
        }
        for (int i = 0; i < selected.size(); i++) {
            final int index = i;
            AppItem a = item(selected.get(i));
            if (a == null) continue;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(this,3), 0, Ui.dp(this,3));

            ImageView icon = new ImageView(this);
            icon.setImageDrawable(a.info.loadIcon(getPackageManager()));
            row.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this,38), Ui.dp(this,38)));

            TextView name = Ui.text(this, (i+1) + ". " + a.name, 14, Color.WHITE, false);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, Ui.dp(this,44), 1);
            np.leftMargin = Ui.dp(this,8);
            row.addView(name, np);

            Button up = new Button(this); up.setText("↑");
            up.setEnabled(i > 0);
            up.setOnClickListener(v -> {
                Collections.swap(selected, index, index-1);
                render();
            });
            row.addView(up, new LinearLayout.LayoutParams(Ui.dp(this,50), Ui.dp(this,44)));

            Button down = new Button(this); down.setText("↓");
            down.setEnabled(i < selected.size()-1);
            down.setOnClickListener(v -> {
                Collections.swap(selected, index, index+1);
                render();
            });
            row.addView(down, new LinearLayout.LayoutParams(Ui.dp(this,50), Ui.dp(this,44)));

            Button remove = new Button(this); remove.setText("✕");
            remove.setOnClickListener(v -> {
                selected.remove(a.pkg);
                render();
            });
            row.addView(remove, new LinearLayout.LayoutParams(Ui.dp(this,50), Ui.dp(this,44)));

            selectedBox.addView(row, Ui.match());
        }
    }

    private void renderAll() {
        if (allBox == null) return;
        allBox.removeAllViews();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase();

        for (AppItem a : all) {
            if (!q.isEmpty() && !a.name.toLowerCase().contains(q)) continue;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            ImageView icon = new ImageView(this);
            icon.setImageDrawable(a.info.loadIcon(getPackageManager()));
            row.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this,40), Ui.dp(this,40)));

            TextView name = Ui.text(this, a.name, 14, Color.WHITE, false);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, Ui.dp(this,50), 1);
            np.leftMargin = Ui.dp(this,9);
            row.addView(name, np);

            Button add = new Button(this);
            boolean isSelected = selected.contains(a.pkg);
            add.setText(isSelected ? "مضاف" : "+");
            add.setEnabled(!isSelected);
            add.setOnClickListener(v -> {
                if (selected.size() >= Prefs.MAX_APPS) {
                    Toast.makeText(this, "Maximum 10 apps allowed", Toast.LENGTH_SHORT).show();
                    return;
                }
                selected.add(a.pkg);
                render();
            });
            row.addView(add, new LinearLayout.LayoutParams(Ui.dp(this,72), Ui.dp(this,46)));

            allBox.addView(row, Ui.match());
        }
    }
}
