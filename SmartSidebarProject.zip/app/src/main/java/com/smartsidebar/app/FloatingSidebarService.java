package com.smartsidebar.app;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

import java.util.*;

public class FloatingSidebarService extends Service {
    public static final String ACTION_REFRESH = "com.smartsidebar.app.REFRESH";
    public static final String ACTION_STOP = "com.smartsidebar.app.STOP";
    private static final String CHANNEL = "smart_sidebar_service";

    private WindowManager wm;
    private View handleView;
    private View panelView;
    private WindowManager.LayoutParams handleParams;
    private android.content.SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable autoHideRunnable;

    @Override public void onCreate() {
        super.onCreate();
        prefs = Prefs.sp(this);

        if (!Settings.canDrawOverlays(this)) {
            prefs.edit().putBoolean(Prefs.RUNNING,false).apply();
            stopSelf();
            return;
        }

        createChannel();
        startForeground(1, notification());
        prefs.edit().putBoolean(Prefs.RUNNING,true).apply();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        showHandle();
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            prefs.edit().putBoolean(Prefs.RUNNING,false).apply();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!Settings.canDrawOverlays(this)) {
            prefs.edit().putBoolean(Prefs.RUNNING,false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (intent != null && ACTION_REFRESH.equals(intent.getAction())) {
            removeViews();
            showHandle();
        } else if (handleView == null && panelView == null) {
            showHandle();
        }
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL, "Smart Sidebar", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Keeps Smart Sidebar available above other apps");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 10, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, FloatingSidebarService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 11, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Smart Sidebar")
                .setContentText("الشريط الجانبي يعمل")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPi)
                .setOngoing(true)
                .build();
    }

    private void showHandle() {
        if (handleView != null || !prefs.getBoolean(Prefs.HANDLE_ENABLED,true)) return;
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }

        String side = prefs.getString(Prefs.SIDE,"right");
        int style = prefs.getInt(Prefs.HANDLE_STYLE,0);
        int color = handleColor(prefs.getInt(Prefs.HANDLE_COLOR,0));
        int opacity = prefs.getInt(Prefs.HANDLE_OPACITY,82);
        int width = prefs.getInt(Prefs.HANDLE_WIDTH,28);
        int height = prefs.getInt(Prefs.HANDLE_HEIGHT,82);
        int iconStyle = prefs.getInt(Prefs.HANDLE_ICON,0);

        TextView handle = new TextView(this);
        handle.setGravity(Gravity.CENTER);
        handle.setTextColor(color == Color.WHITE ? Color.DKGRAY : Color.WHITE);
        handle.setText(handleText(iconStyle, side));
        handle.setTextSize(iconStyle == 1 ? 23 : 27);

        int realW = width;
        int realH = height;
        float radius;

        if (style == 1) {
            int d = Math.max(width, Math.min(height, 60));
            realW = d; realH = d; radius = Ui.dp(this,d);
        } else if (style == 2) {
            realW = Math.max(6, Math.min(width,12));
            radius = Ui.dp(this,8);
            handle.setText("");
        } else if (style == 3) {
            radius = Ui.dp(this,10);
        } else {
            radius = Ui.dp(this,18);
        }

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(alpha(color,opacity));
        bg.setCornerRadius(radius);
        handle.setBackground(bg);

        handleParams = new WindowManager.LayoutParams(
                Ui.dp(this,realW), Ui.dp(this,realH), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        handleParams.gravity = (side.equals("right")?Gravity.END:Gravity.START) | Gravity.CENTER_VERTICAL;
        handleParams.x = 0;
        handleParams.y = prefs.getBoolean(Prefs.REMEMBER_POSITION,true) ? prefs.getInt(Prefs.HANDLE_Y,0) : 0;

        final float[] downY={0};
        final int[] startY={0};
        final boolean[] moved={false};
        final long[] downTime={0};

        handle.setOnTouchListener((v,e)->{
            if (e.getAction()==MotionEvent.ACTION_DOWN) {
                cancelAutoHide();
                v.animate().alpha(1f).setDuration(100).start();
                downY[0]=e.getRawY();
                startY[0]=handleParams.y;
                moved[0]=false;
                downTime[0]=System.currentTimeMillis();
                return true;
            }
            if (e.getAction()==MotionEvent.ACTION_MOVE) {
                float dy=e.getRawY()-downY[0];
                if (Math.abs(dy)>Ui.dp(this,5)) moved[0]=true;
                handleParams.y=startY[0]+(int)dy;
                try { wm.updateViewLayout(handleView,handleParams); } catch(Exception ignored){}
                return true;
            }
            if (e.getAction()==MotionEvent.ACTION_UP) {
                if (prefs.getBoolean(Prefs.REMEMBER_POSITION,true)) {
                    prefs.edit().putInt(Prefs.HANDLE_Y,handleParams.y).apply();
                }
                if (!moved[0]) {
                    long held=System.currentTimeMillis()-downTime[0];
                    if (held>=650) openSettings();
                    else showPanel();
                } else scheduleAutoHide();
                return true;
            }
            return false;
        });

        handleView=handle;
        try {
            wm.addView(handleView,handleParams);
            scheduleAutoHide();
        } catch(Exception e) {
            handleView=null;
            prefs.edit().putBoolean(Prefs.RUNNING,false).apply();
            stopSelf();
        }
    }

    private String handleText(int style,String side) {
        if (style==1) return "⋮";
        if (style==2) return "≡";
        if (style==3) return "";
        return side.equals("right") ? "‹" : "›";
    }

    private void scheduleAutoHide() {
        cancelAutoHide();
        if (handleView==null || !prefs.getBoolean(Prefs.AUTO_HIDE,true)) return;
        int delay=prefs.getInt(Prefs.AUTO_HIDE_DELAY,2);
        autoHideRunnable=()->{
            if(handleView!=null) handleView.animate().alpha(0.30f).setDuration(250).start();
        };
        handler.postDelayed(autoHideRunnable,delay*1000L);
    }

    private void cancelAutoHide() {
        if(autoHideRunnable!=null) handler.removeCallbacks(autoHideRunnable);
        autoHideRunnable=null;
    }

    private void showPanel() {
        cancelAutoHide();
        if(panelView!=null) return;
        if(handleView!=null) {
            try{wm.removeView(handleView);}catch(Exception ignored){}
            handleView=null;
        }

        if(prefs.getBoolean(Prefs.HAPTIC,true)) vibrate();
        if(prefs.getBoolean(Prefs.SOUND,false)) sound();

        List<ResolveInfo> apps=selectedApps();
        String side=prefs.getString(Prefs.SIDE,"right");
        int width=prefs.getInt(Prefs.PANEL_WIDTH,230);
        int opacity=prefs.getInt(Prefs.PANEL_OPACITY,92);
        int radius=prefs.getInt(Prefs.PANEL_RADIUS,24);
        int bgMode=prefs.getInt(Prefs.PANEL_BG,0);
        int iconSize=prefs.getInt(Prefs.ICON_SIZE,48);
        int iconShape=prefs.getInt(Prefs.ICON_SHAPE,0);
        boolean names=prefs.getBoolean(Prefs.SHOW_NAMES,true);
        int fontSize=prefs.getInt(Prefs.FONT_SIZE,13);
        int spacing=prefs.getInt(Prefs.SPACING,7);
        boolean closeOutside=prefs.getBoolean(Prefs.CLOSE_OUTSIDE,true);

        int baseColor;
        int textColor;
        if(bgMode==1){ baseColor=Color.rgb(240,242,245); textColor=Color.rgb(20,20,22); }
        else { baseColor=Color.rgb(34,36,41); textColor=Color.WHITE; }
        if(bgMode==2) opacity=Math.min(opacity,55);

        LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this,10),Ui.dp(this,10),Ui.dp(this,10),Ui.dp(this,10));
        GradientDrawable panelBg=new GradientDrawable();
        panelBg.setColor(alpha(baseColor,opacity));
        panelBg.setCornerRadius(Ui.dp(this,radius));
        panel.setBackground(panelBg);

        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title=new TextView(this);
        title.setText("Smart Sidebar");
        title.setTextColor(textColor);
        title.setTextSize(17);
        title.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));

        TextView gear=new TextView(this);
        gear.setText("⚙");
        gear.setTextColor(textColor);gear.setTextSize(21);gear.setGravity(Gravity.CENTER);
        gear.setOnClickListener(v->openSettings());
        header.addView(gear,new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,42)));

        TextView close=new TextView(this);
        close.setText("✕");close.setTextColor(textColor);close.setTextSize(20);close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v->closePanel());
        header.addView(close,new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,42)));

        final float[] hx={0};
        header.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){hx[0]=e.getRawX();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getRawX()-hx[0];
                boolean towardEdge=side.equals("right")?dx>Ui.dp(this,45):dx<-Ui.dp(this,45);
                if(towardEdge) closePanel();
                return true;
            }
            return true;
        });

        panel.addView(header);

        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        if(apps.isEmpty()) {
            TextView empty=new TextView(this);
            empty.setText("لا توجد تطبيقات مختارة\nاضغط ⚙ ثم اختر التطبيقات");
            empty.setGravity(Gravity.CENTER);
            empty.setTextColor(textColor);
            empty.setTextSize(14);
            empty.setPadding(0,Ui.dp(this,25),0,Ui.dp(this,25));
            list.addView(empty,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            for(ResolveInfo info:apps) {
                LinearLayout row=new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(Ui.dp(this,5),Ui.dp(this,spacing),Ui.dp(this,5),Ui.dp(this,spacing));

                FrameLayout box=new FrameLayout(this);
                GradientDrawable iconBg=new GradientDrawable();
                iconBg.setColor(bgMode==1?Color.argb(28,0,0,0):Color.argb(35,255,255,255));
                iconBg.setCornerRadius(iconRadius(iconShape,iconSize));
                box.setBackground(iconBg);

                ImageView icon=new ImageView(this);
                icon.setImageDrawable(info.loadIcon(getPackageManager()));
                icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
                int inset=Ui.dp(this,5);
                FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(Ui.dp(this,iconSize)-2*inset,Ui.dp(this,iconSize)-2*inset,Gravity.CENTER);
                box.addView(icon,ip);
                row.addView(box,new LinearLayout.LayoutParams(Ui.dp(this,iconSize),Ui.dp(this,iconSize)));

                if(names) {
                    TextView name=new TextView(this);
                    name.setText(info.loadLabel(getPackageManager()).toString());
                    name.setTextColor(textColor);
                    name.setTextSize(fontSize);
                    name.setSingleLine(true);
                    LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,Ui.dp(this,Math.max(iconSize,44)),1);
                    np.leftMargin=Ui.dp(this,10);
                    row.addView(name,np);
                } else {
                    Space space=new Space(this);
                    row.addView(space,new LinearLayout.LayoutParams(0,1,1));
                }

                String pkg=info.activityInfo.packageName;
                row.setOnClickListener(v->launchApp(pkg));
                list.addView(row,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
            }
        }

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.addView(list);
        int maxH=(int)(getResources().getDisplayMetrics().heightPixels*0.68f);
        int estimatedRow = Math.max(iconSize + 2 * spacing + 8, 58);
        int naturalH = apps.isEmpty() ? Ui.dp(this,95) : Ui.dp(this,estimatedRow * apps.size());
        int scrollH = Math.min(maxH, Math.max(Ui.dp(this,80), naturalH));
        panel.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,scrollH));

        int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if(closeOutside) flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        WindowManager.LayoutParams pp=new WindowManager.LayoutParams(
                Ui.dp(this,width),WindowManager.LayoutParams.WRAP_CONTENT,overlayType(),flags,PixelFormat.TRANSLUCENT);

        int pos=prefs.getInt(Prefs.PANEL_POSITION,1);
        int horizontal=side.equals("right")?Gravity.END:Gravity.START;
        if(pos==0){pp.gravity=horizontal|Gravity.TOP;pp.y=Ui.dp(this,55);}
        else if(pos==2){pp.gravity=horizontal|Gravity.BOTTOM;pp.y=Ui.dp(this,55);}
        else {pp.gravity=horizontal|Gravity.CENTER_VERTICAL;pp.y=handleParams!=null?handleParams.y:0;}
        pp.x=Ui.dp(this,5);

        if(closeOutside) {
            panel.setOnTouchListener((v,e)->{
                if(e.getAction()==MotionEvent.ACTION_OUTSIDE){closePanel();return true;}
                return false;
            });
        }

        panelView=panel;
        try {
            wm.addView(panelView,pp);
            animatePanel(panelView,side,width);
        } catch(Exception e) {
            panelView=null;
            showHandle();
        }
    }

    private float iconRadius(int shape,int size) {
        if(shape==1) return Ui.dp(this,size);
        if(shape==2) return Ui.dp(this,18);
        if(shape==3) return 0;
        return Ui.dp(this,11);
    }

    private void animatePanel(View v,String side,int width) {
        int mode=prefs.getInt(Prefs.ANIMATION,0);
        int speed=prefs.getInt(Prefs.ANIMATION_SPEED,1);
        long d=speed==0?120:(speed==2?320:210);
        if(mode==3) return;
        if(mode==1) {
            v.setAlpha(0f);v.animate().alpha(1f).setDuration(d).start();
        } else if(mode==2) {
            v.setScaleX(.88f);v.setScaleY(.88f);v.setAlpha(0f);
            v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(d).start();
        } else {
            v.setTranslationX(side.equals("right")?Ui.dp(this,width): -Ui.dp(this,width));
            v.animate().translationX(0).setDuration(d).start();
        }
    }

    private List<ResolveInfo> selectedApps() {
        Intent q=new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> all=getPackageManager().queryIntentActivities(q,0);
        Map<String,ResolveInfo> map=new HashMap<>();
        for(ResolveInfo r:all) {
            if(!r.activityInfo.packageName.equals(getPackageName())) map.put(r.activityInfo.packageName,r);
        }

        List<String> order=Prefs.getAppOrder(this);
        ArrayList<ResolveInfo> out=new ArrayList<>();

        if(!prefs.getBoolean(Prefs.APPS_INITIALIZED,false) && order.isEmpty()) {
            ArrayList<ResolveInfo> sorted=new ArrayList<>(map.values());
            sorted.sort(Comparator.comparing(a->a.loadLabel(getPackageManager()).toString().toLowerCase()));
            for(int i=0;i<Math.min(6,sorted.size());i++) out.add(sorted.get(i));
            return out;
        }

        for(String pkg:order) {
            ResolveInfo r=map.get(pkg);
            if(r!=null) out.add(r);
            if(out.size()>=Prefs.MAX_APPS) break;
        }
        return out;
    }

    private void launchApp(String pkg) {
        Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);
        if(launch==null){Toast.makeText(this,"التطبيق غير متوفر",Toast.LENGTH_SHORT).show();return;}
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        int mode=prefs.getInt(Prefs.FLOATING_MODE,0); // 0 Auto, 1 Official, 3 Full Screen
        boolean fallback=prefs.getBoolean(Prefs.FALLBACK_FULLSCREEN,true);
        boolean freeform=getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT);

        boolean launched=false;

        // Safe build: no Accessibility/OEM automation. Auto uses only public Android Freeform.
        if(mode==0) {
            if(freeform && Build.VERSION.SDK_INT>=24) mode=1;
            else mode=3;
        }
        // Migrate any saved OEM Assist mode from V6 to safe full-screen fallback.
        if(mode==2) mode=3;

        if(mode==1 && Build.VERSION.SDK_INT>=24) {
            try {
                launch.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT);
                ActivityOptions o=ActivityOptions.makeBasic();
                int sw=getResources().getDisplayMetrics().widthPixels;
                int sh=getResources().getDisplayMetrics().heightPixels;
                int w=(int)(sw*.74f),h=(int)(sh*.68f);
                int l=(sw-w)/2,t=(sh-h)/2;
                o.setLaunchBounds(new Rect(l,t,l+w,t+h));
                startActivity(launch,o.toBundle());
                launched=true;
            } catch(Exception ignored) {}
        }


        if(mode==3 || (!launched && fallback)) {
            try { startActivity(launch); launched=true; } catch(Exception ignored){}
        }

        if(!launched) {
            Toast.makeText(this,"تعذر فتح التطبيق بهذه الطريقة",Toast.LENGTH_SHORT).show();
        }
        if(launched && prefs.getBoolean(Prefs.AUTO_CLOSE,true)) closePanel();
    }

    private void openSettings() {
        Intent i=new Intent(this,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        closePanel();
    }

    private void closePanel() {
        if(panelView!=null) {
            try{wm.removeView(panelView);}catch(Exception ignored){}
            panelView=null;
        }
        showHandle();
    }

    private void vibrate() {
        try {
            Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);
            if(v==null)return;
            if(Build.VERSION.SDK_INT>=26) v.vibrate(VibrationEffect.createOneShot(18,VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(18);
        } catch(Exception ignored){}
    }

    private void sound() {
        try {
            ToneGenerator tg=new ToneGenerator(AudioManager.STREAM_SYSTEM,35);
            tg.startTone(ToneGenerator.TONE_PROP_BEEP,45);
            handler.postDelayed(tg::release,90);
        } catch(Exception ignored){}
    }

    private int handleColor(int preset) {
        switch(preset) {
            case 1:return Color.rgb(47,140,245);
            case 2:return Color.rgb(42,180,105);
            case 3:return Color.rgb(130,95,210);
            case 4:return Color.rgb(220,75,75);
            case 5:return Color.WHITE;
            default:return Color.rgb(43,45,50);
        }
    }

    private int alpha(int color,int percent) {
        return Color.argb((int)(255*(percent/100f)),Color.red(color),Color.green(color),Color.blue(color));
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void removeViews() {
        cancelAutoHide();
        if(handleView!=null){try{wm.removeView(handleView);}catch(Exception ignored){}handleView=null;}
        if(panelView!=null){try{wm.removeView(panelView);}catch(Exception ignored){}panelView=null;}
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        removeViews();
        handler.postDelayed(this::showHandle,150);
    }

    @Override public void onDestroy() {
        prefs.edit().putBoolean(Prefs.RUNNING,false).apply();
        removeViews();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
