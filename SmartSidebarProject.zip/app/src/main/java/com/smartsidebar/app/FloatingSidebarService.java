package com.smartsidebar.app;

import android.app.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.*;
import android.widget.*;

import java.util.*;

public class FloatingSidebarService extends Service {

    public static final String ACTION_REFRESH = "com.smartsidebar.app.REFRESH";
    private static final String CHANNEL_ID = "smart_sidebar_service";

    private WindowManager windowManager;
    private View handleView;
    private View panelView;
    private WindowManager.LayoutParams handleParams;
    private SharedPreferences prefs;

    @Override
    public void onCreate() {
        super.onCreate();

        prefs = getSharedPreferences("sidebar_prefs", MODE_PRIVATE);
        prefs.edit().putBoolean("service_running", true).apply();

        createNotificationChannel();
        startForeground(1, createNotification());

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showHandle();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_REFRESH.equals(intent.getAction())) {
            removeViews();
            showHandle();
        }
        return START_STICKY;
    }

    private Notification createNotification() {
        Intent open = new Intent(this, MainActivity.class);

        PendingIntent pi = PendingIntent.getActivity(
                this,
                0,
                open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Smart Sidebar")
                .setContentText("الشريط الجانبي يعمل")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Smart Sidebar",
                    NotificationManager.IMPORTANCE_LOW);

            getSystemService(NotificationManager.class)
                    .createNotificationChannel(channel);
        }
    }

    private void showHandle() {
        if (handleView != null) return;

        String side = prefs.getString("side", "right");
        int style = prefs.getInt("handle_style", 0);
        int baseSize = prefs.getInt("handle_size", 34);
        int opacity = prefs.getInt("handle_opacity", 82);
        int color = handleColor(prefs.getInt("handle_color", 0));

        TextView handle = new TextView(this);
        handle.setGravity(Gravity.CENTER);
        handle.setTextColor(Color.WHITE);

        int width;
        int height;
        float radius;

        if (style == 1) {
            width = dp(baseSize + 12);
            height = dp(baseSize + 12);
            radius = dp(baseSize + 12);
            handle.setText(side.equals("right") ? "‹" : "›");
            handle.setTextSize(28);
        } else if (style == 2) {
            width = dp(9);
            height = dp(Math.max(70, baseSize * 2));
            radius = dp(10);
            handle.setText("");
        } else {
            width = dp(baseSize);
            height = dp(Math.max(72, baseSize * 2));
            radius = dp(18);
            handle.setText(side.equals("right") ? "‹" : "›");
            handle.setTextSize(Math.max(24, baseSize - 2));
        }

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(withAlpha(color, opacity));
        bg.setCornerRadius(radius);
        handle.setBackground(bg);

        handleParams = new WindowManager.LayoutParams(
                width,
                height,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        handleParams.gravity =
                (side.equals("right") ? Gravity.END : Gravity.START)
                        | Gravity.CENTER_VERTICAL;

        handleParams.x = 0;
        handleParams.y = prefs.getInt("handle_y", 0);

        final float[] downY = new float[1];
        final int[] startY = new int[1];
        final boolean[] moved = new boolean[1];
        final long[] downTime = new long[1];

        handle.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downY[0] = event.getRawY();
                    startY[0] = handleParams.y;
                    moved[0] = false;
                    downTime[0] = System.currentTimeMillis();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dy = event.getRawY() - downY[0];

                    if (Math.abs(dy) > dp(5)) {
                        moved[0] = true;
                    }

                    handleParams.y = startY[0] + (int) dy;
                    windowManager.updateViewLayout(handleView, handleParams);
                    return true;

                case MotionEvent.ACTION_UP:
                    prefs.edit()
                            .putInt("handle_y", handleParams.y)
                            .apply();

                    if (!moved[0]) {
                        long pressDuration =
                                System.currentTimeMillis() - downTime[0];

                        if (pressDuration >= 650) {
                            openSettings();
                        } else {
                            showPanel();
                        }
                    }
                    return true;
            }

            return false;
        });

        handleView = handle;
        windowManager.addView(handleView, handleParams);
    }

    private void showPanel() {
        if (panelView != null) return;

        if (prefs.getBoolean("haptic", true)) {
            vibrateLight();
        }

        if (handleView != null) {
            windowManager.removeView(handleView);
            handleView = null;
        }

        List<ResolveInfo> apps = getSelectedApps();

        int columns = prefs.getInt("columns", 3);
        int iconSize = prefs.getInt("icon_size", 52);
        boolean showNames = prefs.getBoolean("show_names", true);
        int panelOpacity = prefs.getInt("panel_opacity", 90);
        String side = prefs.getString("side", "right");

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(10), dp(10), dp(10), dp(10));

        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.argb(
                (int) (255 * (panelOpacity / 100f)),
                38, 38, 42));
        panelBg.setCornerRadius(dp(24));
        outer.setBackground(panelBg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Smart Sidebar  •  " + apps.size());
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setPadding(dp(8), 0, dp(8), 0);

        header.addView(
                title,
                new LinearLayout.LayoutParams(0, dp(46), 1));

        TextView settings = new TextView(this);
        settings.setText("⚙");
        settings.setTextSize(24);
        settings.setTextColor(Color.WHITE);
        settings.setGravity(Gravity.CENTER);
        settings.setOnClickListener(v -> openSettings());

        header.addView(
                settings,
                new LinearLayout.LayoutParams(dp(48), dp(46)));

        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextSize(22);
        close.setTextColor(Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> closePanel());

        header.addView(
                close,
                new LinearLayout.LayoutParams(dp(48), dp(46)));

        outer.addView(header);

        if (apps.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("لا توجد تطبيقات محددة.\nاضغط ⚙ ثم اختر التطبيقات.");
            empty.setTextColor(Color.WHITE);
            empty.setTextSize(15);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(16), dp(28), dp(16), dp(28));

            outer.addView(empty);
        } else {
            GridLayout grid = new GridLayout(this);
            grid.setColumnCount(columns);

            int cellWidth = Math.max(iconSize + 34, 82);
            int cellHeight = showNames
                    ? iconSize + 50
                    : iconSize + 22;

            for (ResolveInfo info : apps) {
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                item.setGravity(Gravity.CENTER);
                item.setPadding(dp(5), dp(5), dp(5), dp(5));

                ImageView icon = new ImageView(this);
                icon.setImageDrawable(
                        info.loadIcon(getPackageManager()));

                item.addView(
                        icon,
                        new LinearLayout.LayoutParams(
                                dp(iconSize),
                                dp(iconSize)));

                if (showNames) {
                    TextView name = new TextView(this);
                    name.setText(
                            info.loadLabel(getPackageManager()).toString());
                    name.setTextColor(Color.WHITE);
                    name.setTextSize(11);
                    name.setGravity(Gravity.CENTER);
                    name.setMaxLines(1);

                    item.addView(
                            name,
                            new LinearLayout.LayoutParams(
                                    dp(cellWidth - 8),
                                    dp(30)));
                }

                String packageName = info.activityInfo.packageName;
                item.setOnClickListener(v -> launchApp(packageName));

                GridLayout.LayoutParams gp =
                        new GridLayout.LayoutParams();

                gp.width = dp(cellWidth);
                gp.height = dp(cellHeight);

                grid.addView(item, gp);
            }

            ScrollView scroll = new ScrollView(this);
            scroll.addView(grid);

            int rows = (int) Math.ceil(
                    apps.size() / (double) columns);

            int naturalHeight = dp(rows * cellHeight);
            int maxHeight = (int) (
                    getResources()
                            .getDisplayMetrics()
                            .heightPixels * 0.62f);

            int scrollHeight =
                    Math.min(naturalHeight, maxHeight);

            outer.addView(
                    scroll,
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            Math.max(dp(90), scrollHeight)));
        }

        int screenWidth =
                getResources().getDisplayMetrics().widthPixels;

        int cellWidth =
                Math.max(iconSize + 34, 82);

        int panelWidth =
                Math.min(
                        dp(columns * cellWidth + 28),
                        screenWidth - dp(18));

        WindowManager.LayoutParams panelParams =
                new WindowManager.LayoutParams(
                        panelWidth,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        overlayType(),
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                        PixelFormat.TRANSLUCENT);

        int position =
                prefs.getInt("panel_position", 1);

        int horizontal =
                side.equals("right")
                        ? Gravity.END
                        : Gravity.START;

        if (position == 0) {
            panelParams.gravity =
                    horizontal | Gravity.TOP;
            panelParams.y = dp(70);
        } else if (position == 2) {
            panelParams.gravity =
                    horizontal | Gravity.BOTTOM;
            panelParams.y = dp(70);
        } else {
            panelParams.gravity =
                    horizontal | Gravity.CENTER_VERTICAL;

            panelParams.y =
                    handleParams != null
                            ? handleParams.y
                            : 0;
        }

        panelParams.x = dp(6);

        panelView = outer;
        windowManager.addView(
                panelView,
                panelParams);
    }

    private List<ResolveInfo> getSelectedApps() {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> all =
                new ArrayList<>(
                        getPackageManager()
                                .queryIntentActivities(query, 0));

        all.sort(
                Comparator.comparing(
                        a -> a.loadLabel(getPackageManager())
                                .toString()
                                .toLowerCase()));

        Set<String> selected =
                prefs.getStringSet(
                        "selected_apps",
                        Collections.emptySet());

        boolean initialized =
                prefs.getBoolean(
                        "selection_initialized",
                        false);

        List<ResolveInfo> result =
                new ArrayList<>();

        for (ResolveInfo info : all) {
            String packageName =
                    info.activityInfo.packageName;

            if (packageName.equals(getPackageName())) {
                continue;
            }

            if (initialized) {
                if (selected.contains(packageName)) {
                    result.add(info);
                }
            } else {
                if (result.size() < 10) {
                    result.add(info);
                }
            }
        }

        return result;
    }

    private void launchApp(String packageName) {
        Intent launch =
                getPackageManager()
                        .getLaunchIntentForPackage(packageName);

        if (launch == null) {
            Toast.makeText(
                    this,
                    "تعذر فتح التطبيق",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        boolean tryFloating =
                prefs.getBoolean("try_floating", false);

        try {
            if (tryFloating) {
                launch.addFlags(
                        Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT);

                ActivityOptions options =
                        ActivityOptions.makeBasic();

                int sw =
                        getResources()
                                .getDisplayMetrics()
                                .widthPixels;

                int sh =
                        getResources()
                                .getDisplayMetrics()
                                .heightPixels;

                int w = (int) (sw * 0.74f);
                int h = (int) (sh * 0.70f);

                int left = (sw - w) / 2;
                int top = (sh - h) / 2;

                options.setLaunchBounds(
                        new Rect(
                                left,
                                top,
                                left + w,
                                top + h));

                startActivity(
                        launch,
                        options.toBundle());
            } else {
                startActivity(launch);
            }
        } catch (Exception ignored) {
            startActivity(launch);
        }

        if (prefs.getBoolean("auto_close", true)) {
            closePanel();
        }
    }

    private void openSettings() {
        Intent i =
                new Intent(
                        this,
                        MainActivity.class);

        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        startActivity(i);
        closePanel();
    }

    private void closePanel() {
        if (panelView != null) {
            windowManager.removeView(panelView);
            panelView = null;
        }

        showHandle();
    }

    private void vibrateLight() {
        try {
            Vibrator vibrator =
                    (Vibrator) getSystemService(VIBRATOR_SERVICE);

            if (vibrator == null) return;

            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(
                        VibrationEffect.createOneShot(
                                18,
                                VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(18);
            }
        } catch (Exception ignored) {}
    }

    private int handleColor(int preset) {
        switch (preset) {
            case 1:
                return Color.rgb(45, 137, 239);
            case 2:
                return Color.rgb(39, 174, 96);
            case 3:
                return Color.rgb(123, 91, 199);
            case 4:
                return Color.rgb(210, 70, 70);
            default:
                return Color.rgb(42, 42, 46);
        }
    }

    private int withAlpha(int color, int percent) {
        return Color.argb(
                (int) (255 * (percent / 100f)),
                Color.red(color),
                Color.green(color),
                Color.blue(color));
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void removeViews() {
        if (handleView != null) {
            windowManager.removeView(handleView);
            handleView = null;
        }

        if (panelView != null) {
            windowManager.removeView(panelView);
            panelView = null;
        }
    }

    @Override
    public void onDestroy() {
        prefs.edit()
                .putBoolean("service_running", false)
                .apply();

        removeViews();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(int value) {
        return (int) (
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density);
    }
}
