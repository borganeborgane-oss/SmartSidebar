package com.smartsidebar.app;

import android.app.*;
import android.content.*;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FloatingSidebarService extends Service {

    private static final String CHANNEL_ID = "smart_sidebar_channel";
    private WindowManager windowManager;
    private View handleView;
    private View panelView;
    private WindowManager.LayoutParams handleParams;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, createNotification());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showHandle();
    }

    private Notification createNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Smart Sidebar")
                .setContentText("الشريط الجانبي يعمل")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Smart Sidebar",
                    NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void showHandle() {
        if (handleView != null) return;

        TextView handle = new TextView(this);
        handle.setText("‹");
        handle.setTextSize(30);
        handle.setTextColor(Color.WHITE);
        handle.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(125, 40, 40, 40));
        bg.setCornerRadius(dp(18));
        handle.setBackground(bg);

        handleParams = new WindowManager.LayoutParams(
                dp(28),
                dp(86),
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        handleParams.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        handleParams.x = 0;
        handleParams.y = 0;

        final float[] downY = new float[1];
        final int[] startY = new int[1];
        final boolean[] moved = new boolean[1];

        handle.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downY[0] = event.getRawY();
                    startY[0] = handleParams.y;
                    moved[0] = false;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dy = event.getRawY() - downY[0];
                    if (Math.abs(dy) > dp(5)) moved[0] = true;
                    handleParams.y = startY[0] + (int) dy;
                    windowManager.updateViewLayout(handleView, handleParams);
                    return true;

                case MotionEvent.ACTION_UP:
                    if (!moved[0]) showPanel();
                    return true;
            }
            return false;
        });

        handleView = handle;
        windowManager.addView(handleView, handleParams);
    }

    private void showPanel() {
        if (panelView != null) return;

        if (handleView != null) {
            windowManager.removeView(handleView);
            handleView = null;
        }

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));

        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.argb(235, 45, 45, 48));
        panelBg.setCornerRadius(dp(28));
        panel.setBackground(panelBg);

        TextView header = new TextView(this);
        header.setText("Smart Sidebar     ✕");
        header.setTextColor(Color.WHITE);
        header.setTextSize(19);
        header.setGravity(Gravity.CENTER);
        header.setPadding(0, 0, 0, dp(10));
        header.setOnClickListener(v -> closePanel());
        panel.addView(header);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        panel.addView(grid);

        List<ResolveInfo> apps = getLaunchableApps();
        int maxApps = Math.min(apps.size(), 12);

        for (int i = 0; i < maxApps; i++) {
            ResolveInfo info = apps.get(i);

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(8), dp(8), dp(8), dp(8));

            ImageView icon = new ImageView(this);
            icon.setImageDrawable(info.loadIcon(getPackageManager()));
            item.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

            TextView name = new TextView(this);
            String label = info.loadLabel(getPackageManager()).toString();
            name.setText(label);
            name.setTextColor(Color.WHITE);
            name.setTextSize(12);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(1);
            item.addView(name, new LinearLayout.LayoutParams(dp(92), dp(30)));

            String packageName = info.activityInfo.packageName;
            item.setOnClickListener(v -> launchApp(packageName));

            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = dp(105);
            gp.height = dp(95);
            grid.addView(item, gp);
        }

        WindowManager.LayoutParams panelParams = new WindowManager.LayoutParams(
                dp(240),
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        panelParams.x = dp(8);
        panelParams.y = handleParams != null ? handleParams.y : 0;

        panelView = panel;
        windowManager.addView(panelView, panelParams);
    }

    private List<ResolveInfo> getLaunchableApps() {
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = new ArrayList<>(
                getPackageManager().queryIntentActivities(intent, 0));

        Collections.sort(list, Comparator.comparing(
                a -> a.loadLabel(getPackageManager()).toString().toLowerCase()));

        List<ResolveInfo> filtered = new ArrayList<>();
        for (ResolveInfo r : list) {
            if (!r.activityInfo.packageName.equals(getPackageName())) {
                filtered.add(r);
            }
        }
        return filtered;
    }

    private void launchApp(String packageName) {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launchIntent);
            closePanel();
        } else {
            Toast.makeText(this, "تعذر فتح التطبيق", Toast.LENGTH_SHORT).show();
        }
    }

    private void closePanel() {
        if (panelView != null) {
            windowManager.removeView(panelView);
            panelView = null;
        }
        showHandle();
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handleView != null) {
            windowManager.removeView(handleView);
            handleView = null;
        }
        if (panelView != null) {
            windowManager.removeView(panelView);
            panelView = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
