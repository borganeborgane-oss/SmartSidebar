package com.smartsidebar.app;

interface IPrivilegedService {
    String exec(String command);
}
