SmartSidebar - First Test Build

Features:
- Requests "display over other apps" permission.
- Shows a semi-transparent floating handle on screen edge.
- Handle can be moved vertically.
- Tap handle to open a floating panel.
- Panel lists launchable apps from the phone.
- Tap an app to launch it.
- Includes Stop button in main app.

This is an early test build for personal testing.
