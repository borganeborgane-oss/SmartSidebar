# Smart Sidebar V7 — OPPO / ColorOS

نسخة تجريبية محسّنة لهواتف OPPO / realme / OnePlus مع الحفاظ على دعم Android العام.

## الجديد
- وضع Auto.
- Official Freeform عبر Android APIs العامة.
- OPPO / ColorOS Enhanced: محاولة آمنة عبر `ActivityOptions.setLaunchBounds` و flags عامة.
- شاشة لاختبار كل تطبيق مختار وتسجيل هل ظهر كنافذة عائمة أو Full Screen.
- في Auto، التطبيقات التي سجّل المستخدم أنها تفتح Full Screen لا يعاد إجبارها على محاولة OPPO.
- لا Accessibility ولا Root ولا Shizuku ولا Private APIs.

## قيد مهم
إذا كان ColorOS يمنع تطبيقات الطرف الثالث من تشغيل تطبيق خارجي داخل نافذة عائمة، لا يمكن لـ Smart Sidebar إجبار النظام على ذلك بواسطة Android public APIs. في هذه الحالة يكون Full Screen هو البديل.
