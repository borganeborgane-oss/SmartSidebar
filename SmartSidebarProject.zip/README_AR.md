# Smart Sidebar V8 Strong

نسخة تجريبية قوية مخصصة لحالة OPPO/ColorOS التي تفتح التطبيقات Full Screen رغم محاولات Freeform العامة.

## المحركات الموجودة في نسخة واحدة
- Auto Strong
- Shizuku / ADB shell
- تفعيل `enable_freeform_support`
- تفعيل `force_resizable_activities`
- محاولة Windowing Mode 5 مع Bounds
- Android Official Freeform API
- OPPO / ColorOS Enhanced public API
- Full Screen fallback

## الإعداد مرة واحدة
1. ثبّت وشغّل Shizuku.
2. افتح Smart Sidebar > V8 Strong.
3. امنح Smart Sidebar صلاحية Shizuku.
4. اضغط «تفعيل Freeform القوي».
5. أعد تشغيل الهاتف مرة واحدة.
6. اختر Auto Strong ثم جرّب WhatsApp / Facebook / Chrome / Calculator.

لا Root ولا Accessibility.

ملاحظة: ColorOS قد يرفض Freeform حتى لصلاحية shell. عندها يكون المنع من النظام نفسه وليس من Smart Sidebar.
