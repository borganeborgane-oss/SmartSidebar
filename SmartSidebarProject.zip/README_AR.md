# Smart Sidebar V6.1 Safe

نسخة آمنة للتثبيت التجريبي خارج Google Play.

- Overlay للشريط العائم.
- اختيار وترتيب حتى 10 تطبيقات.
- Official Freeform عندما يعلن Android دعمه.
- Full Screen fallback على الأجهزة التي تمنع Freeform لتطبيقات الطرف الثالث.
- تمت إزالة Accessibility/OEM automation لتقليل الصلاحيات الحساسة التي قد تؤدي إلى حظر Play Protect للـ APK غير الموثق.

ملاحظة: OPPO/ColorOS قد يحتفظ بميزة Floating Window لتطبيقات النظام/الواجهات الخاصة به، ولا توجد API عامة مضمونة لإجبار أي تطبيق خارجي على الفتح كنافذة صغيرة.
