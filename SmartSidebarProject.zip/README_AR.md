# SmartSidebar Universal V6

إصدار V6 يضيف نظام فتح متعدد الطرق للتطبيقات:

- **Auto**: يختار Official Freeform إذا أعلن Android دعمه، وإلا يستخدم OEM Assist إذا فعّله المستخدم.
- **Official Freeform**: يستخدم `ActivityOptions.setLaunchBounds()` و `FLAG_ACTIVITY_LAUNCH_ADJACENT`.
- **OEM Assist**: اختياري. بعد موافقة المستخدم على خدمة Accessibility يفتح Recent Apps ويحاول الضغط على أمر النظام المرئي مثل Floating Window / Pop-up View / Mini Window.
- **Full Screen**: فتح عادي دائمًا.

## الأجهزة المستهدفة

OPPO / realme / OnePlus / Samsung / Xiaomi / Redmi / POCO / vivo / iQOO وغيرها.

OEM Assist يحتوي أسماء أوامر شائعة بالإنجليزية والفرنسية والعربية، لكنه **تجريبي** لأن الشركات تغيّر واجهة Recent Apps وأسماء الأوامر بين الإصدارات. إذا لم يجد الأمر، يرجع للتطبيق المفتوح بدل ترك المستخدم في Recent Apps.

## الخصوصية

OEM Assist لا يرسل البيانات إلى الإنترنت ولا يحتاج Root أو Shizuku أو ADB. Accessibility لا يتم تشغيلها تلقائيًا؛ يجب على المستخدم تفعيلها صراحة من إعدادات الهاتف.

## الشريط الجانبي

- اختيار وترتيب من 1 إلى 10 تطبيقات.
- قائمة عمودية من حافة الشاشة.
- Rounded Square / Circle / Squircle / Square.
- تغيير حجم وشفافية ولون وشكل المقبض.
- يمين/يسار، حفظ الموضع، إخفاء بصري تلقائي.
- خلفية وشفافية وعرض القائمة، وحركات Slide/Fade/Scale.
- إغلاق تلقائي، اهتزاز، صوت، تشغيل بعد إعادة التشغيل.
- صفحة للصلاحيات وصفحة لتوافق الجهاز.

## أول تشغيل لـ OEM Assist

1. افتح Smart Sidebar.
2. ادخل إلى **النافذة المصغرة**.
3. اختر **Auto**.
4. فعّل **OEM Floating Window Assist**.
5. اضغط **فتح إعدادات إمكانية الوصول**.
6. اختر **Smart Sidebar** وفعّل الخدمة.
7. ارجع إلى التطبيق. يجب أن تظهر الحالة `Enabled ✓`.
8. جرّب فتح تطبيق من الشريط.

## البناء

المشروع يستخدم نفس Development Keystore الثابت الموجود في `app/dev-keystore.jks` لتسهيل تحديث النسخ التجريبية فوق بعضها.

GitHub Actions ينتج Artifact باسم:

`SmartSidebar-APK`

ويحتوي:

`app-debug.apk`
