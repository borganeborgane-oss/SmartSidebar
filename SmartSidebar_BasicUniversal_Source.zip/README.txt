Smart Sidebar — Basic Universal Source

Purpose:
- Floating edge handle over other apps
- Tap to open a sidebar containing user-selected installed apps
- Launch selected apps normally in full screen
- No Shizuku, no ADB, no Accessibility, no Root, no OEM/private APIs

Compatibility:
- Android 8.0+ (minSdk 26)
- Requires the user to grant “Display over other apps” permission
- Some manufacturers may also require allowing background activity / disabling battery optimization for persistent operation

Main source files:
- MainActivity.java
- AppSelectionActivity.java
- FloatingSidebarService.java
- AndroidManifest.xml

This is the clean/basic implementation to use as a base on another development platform.
