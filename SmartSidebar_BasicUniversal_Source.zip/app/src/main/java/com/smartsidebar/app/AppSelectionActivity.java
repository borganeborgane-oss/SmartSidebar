package com.smartsidebar.app;

import android.app.Activity;
import android.content.*;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class AppSelectionActivity extends Activity {
  SharedPreferences p; List<CheckBox> boxes=new ArrayList<>();
  public void onCreate(Bundle b){
    super.onCreate(b); p=getSharedPreferences("sidebar_prefs",MODE_PRIVATE);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(24),dp(16),dp(16));root.setBackgroundColor(Color.rgb(18,18,18));
    TextView title=new TextView(this);title.setText("اختيار التطبيقات");title.setTextColor(Color.WHITE);title.setTextSize(24);root.addView(title);

    ScrollView sc=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);
    root.addView(sc,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));

    Set<String> selected=p.getStringSet("selected_apps",Collections.emptySet()); boolean init=p.getBoolean("selection_initialized",false);
    Intent q=new Intent(Intent.ACTION_MAIN);q.addCategory(Intent.CATEGORY_LAUNCHER);
    List<ResolveInfo> apps=getPackageManager().queryIntentActivities(q,0);
    apps.sort(Comparator.comparing(a->a.loadLabel(getPackageManager()).toString().toLowerCase()));
    for(ResolveInfo a:apps){
      String pkg=a.activityInfo.packageName;if(pkg.equals(getPackageName()))continue;
      CheckBox c=new CheckBox(this);c.setText(a.loadLabel(getPackageManager()));c.setTextColor(Color.WHITE);c.setTextSize(16);c.setTag(pkg);
      c.setChecked(init&&selected.contains(pkg));c.setCompoundDrawablesWithIntrinsicBounds(a.loadIcon(getPackageManager()),null,null,null);c.setCompoundDrawablePadding(dp(10));
      boxes.add(c);list.addView(c,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58)));
    }
    Button save=new Button(this);save.setText("حفظ الاختيارات");save.setOnClickListener(v->{Set<String>s=new HashSet<>();for(CheckBox c:boxes)if(c.isChecked())s.add((String)c.getTag());p.edit().putStringSet("selected_apps",s).putBoolean("selection_initialized",true).apply();finish();});
    root.addView(save,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58)));
    setContentView(root);
  }
  int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
}
