package com.smartsidebar.app;

import android.app.*;
import android.content.*;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.*;
import java.util.*;

public class FloatingSidebarService extends Service {
  public static final String ACTION_REFRESH="com.smartsidebar.app.REFRESH";
  WindowManager wm; View handle,panel; WindowManager.LayoutParams hp; SharedPreferences p;

  public void onCreate(){super.onCreate();p=getSharedPreferences("sidebar_prefs",MODE_PRIVATE);channel();startForeground(1,notif());wm=(WindowManager)getSystemService(WINDOW_SERVICE);showHandle();}
  public int onStartCommand(Intent i,int f,int id){if(i!=null&&ACTION_REFRESH.equals(i.getAction())){remove();showHandle();}return START_STICKY;}
  Notification notif(){PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,"sidebar").setContentTitle("Smart Sidebar").setContentText("الشريط يعمل").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).setContentIntent(pi).build();}
  void channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("sidebar","Smart Sidebar",NotificationManager.IMPORTANCE_LOW));}

  void showHandle(){
    if(handle!=null)return; String side=p.getString("side","right");int sz=p.getInt("handle_size",32),op=p.getInt("opacity",85);
    TextView h=new TextView(this);h.setText(side.equals("right")?"‹":"›");h.setTextSize(Math.max(24,sz));h.setTextColor(Color.WHITE);h.setGravity(Gravity.CENTER);
    GradientDrawable g=new GradientDrawable();g.setColor(Color.argb((int)(255*op/100f),38,38,42));g.setCornerRadius(dp(18));h.setBackground(g);
    hp=new WindowManager.LayoutParams(dp(sz),dp(Math.max(70,sz*2)),type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
    hp.gravity=(side.equals("right")?Gravity.END:Gravity.START)|Gravity.CENTER_VERTICAL;hp.y=p.getInt("handle_y",0);
    final float[] y={0};final int[] sy={0};final boolean[] moved={false};
    h.setOnTouchListener((v,e)->{if(e.getAction()==0){y[0]=e.getRawY();sy[0]=hp.y;moved[0]=false;return true;}if(e.getAction()==2){float d=e.getRawY()-y[0];if(Math.abs(d)>dp(5))moved[0]=true;hp.y=sy[0]+(int)d;wm.updateViewLayout(handle,hp);return true;}if(e.getAction()==1){p.edit().putInt("handle_y",hp.y).apply();if(!moved[0])showPanel();return true;}return false;});
    handle=h;wm.addView(handle,hp);
  }

  void showPanel(){
    if(panel!=null)return;if(handle!=null){wm.removeView(handle);handle=null;}
    int op=p.getInt("opacity",85),cols=p.getInt("columns",2);boolean names=p.getBoolean("show_names",true);String side=p.getString("side","right");
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(12),dp(12),dp(12));
    GradientDrawable g=new GradientDrawable();g.setColor(Color.argb((int)(255*op/100f),44,44,48));g.setCornerRadius(dp(28));box.setBackground(g);
    TextView head=new TextView(this);head.setText("Smart Sidebar   ✕");head.setTextColor(Color.WHITE);head.setTextSize(19);head.setGravity(Gravity.CENTER);head.setOnClickListener(v->close());box.addView(head);
    List<ResolveInfo> apps=chosen();
    if(apps.isEmpty()){TextView e=new TextView(this);e.setText("لم يتم اختيار تطبيقات");e.setTextColor(Color.WHITE);e.setPadding(dp(15),dp(30),dp(15),dp(30));box.addView(e);}
    else{
      GridLayout grid=new GridLayout(this);grid.setColumnCount(cols);box.addView(grid);
      for(ResolveInfo a:apps){
        LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);
        ImageView iv=new ImageView(this);iv.setImageDrawable(a.loadIcon(getPackageManager()));item.addView(iv,new LinearLayout.LayoutParams(dp(46),dp(46)));
        if(names){TextView n=new TextView(this);n.setText(a.loadLabel(getPackageManager()));n.setTextColor(Color.WHITE);n.setTextSize(11);n.setGravity(Gravity.CENTER);n.setMaxLines(1);item.addView(n,new LinearLayout.LayoutParams(dp(82),dp(28)));}
        String pkg=a.activityInfo.packageName;item.setOnClickListener(v->launch(pkg));
        GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(92);gp.height=dp(names?92:68);grid.addView(item,gp);
      }
    }
    int sw=getResources().getDisplayMetrics().widthPixels,w=Math.min(dp(cols*92+30),sw-dp(24));
    WindowManager.LayoutParams q=new WindowManager.LayoutParams(w,WindowManager.LayoutParams.WRAP_CONTENT,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
    q.gravity=(side.equals("right")?Gravity.END:Gravity.START)|Gravity.CENTER_VERTICAL;q.x=dp(8);q.y=hp!=null?hp.y:0;
    panel=box;wm.addView(panel,q);
  }

  List<ResolveInfo> chosen(){
    Intent q=new Intent(Intent.ACTION_MAIN);q.addCategory(Intent.CATEGORY_LAUNCHER);
    List<ResolveInfo> all=new ArrayList<>(getPackageManager().queryIntentActivities(q,0));all.sort(Comparator.comparing(a->a.loadLabel(getPackageManager()).toString().toLowerCase()));
    boolean init=p.getBoolean("selection_initialized",false);Set<String>s=p.getStringSet("selected_apps",Collections.emptySet());List<ResolveInfo> out=new ArrayList<>();
    for(ResolveInfo a:all){String pkg=a.activityInfo.packageName;if(pkg.equals(getPackageName()))continue;if(!init){if(out.size()<12)out.add(a);}else if(s.contains(pkg))out.add(a);}return out;
  }

  void launch(String pkg){
    Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
    if(i==null)return;
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    try{ startActivity(i); } catch(Exception ignored){}
    close();
  }

  void close(){if(panel!=null){wm.removeView(panel);panel=null;}showHandle();}
  int type(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}
  void remove(){if(handle!=null){wm.removeView(handle);handle=null;}if(panel!=null){wm.removeView(panel);panel=null;}}
  public void onDestroy(){remove();super.onDestroy();}
  public IBinder onBind(Intent i){return null;}
  int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
}
