package com.smartsidebar.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
  SharedPreferences p;
  TextView opText, colText, sizeText;
  Button sideBtn;

  public void onCreate(Bundle b) {
    super.onCreate(b);
    p=getSharedPreferences("sidebar_prefs",MODE_PRIVATE);
    if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);

    ScrollView sc=new ScrollView(this);
    LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL);
    r.setPadding(dp(20),dp(36),dp(20),dp(30)); r.setBackgroundColor(Color.rgb(18,18,18)); sc.addView(r);

    TextView t=txt("Smart Sidebar",28,Color.WHITE,true); t.setGravity(Gravity.CENTER); r.addView(t,mp());
    TextView s=txt("الإعدادات",15,Color.LTGRAY,false); s.setGravity(Gravity.CENTER); r.addView(s,mp());

    Button choose=new Button(this); choose.setText("اختيار التطبيقات");
    choose.setOnClickListener(v->startActivity(new Intent(this,AppSelectionActivity.class))); r.addView(choose,bp());

    section(r,"المظهر");
    opText=txt("",15,Color.WHITE,false); r.addView(opText,mp());
    SeekBar op=new SeekBar(this); op.setMax(80); op.setProgress(p.getInt("opacity",85)-20); setOp(op.getProgress());
    op.setOnSeekBarChangeListener(listener(x->{p.edit().putInt("opacity",x+20).apply();setOp(x);})); r.addView(op,mp());

    sizeText=txt("",15,Color.WHITE,false); r.addView(sizeText,mp());
    SeekBar sz=new SeekBar(this); sz.setMax(40); sz.setProgress(p.getInt("handle_size",32)-20); setSize(sz.getProgress());
    sz.setOnSeekBarChangeListener(listener(x->{p.edit().putInt("handle_size",x+20).apply();setSize(x);})); r.addView(sz,mp());

    Switch names=new Switch(this); names.setText("إظهار أسماء التطبيقات"); names.setTextColor(Color.WHITE);
    names.setChecked(p.getBoolean("show_names",true));
    names.setOnCheckedChangeListener((v,c)->p.edit().putBoolean("show_names",c).apply()); r.addView(names,mp());

    section(r,"التخطيط");
    colText=txt("",15,Color.WHITE,false); r.addView(colText,mp());
    SeekBar cols=new SeekBar(this); cols.setMax(2); cols.setProgress(p.getInt("columns",2)-2); setCols(cols.getProgress());
    cols.setOnSeekBarChangeListener(listener(x->{p.edit().putInt("columns",x+2).apply();setCols(x);})); r.addView(cols,mp());

    sideBtn=new Button(this); refreshSide();
    sideBtn.setOnClickListener(v->{String a=p.getString("side","right");p.edit().putString("side",a.equals("right")?"left":"right").apply();refreshSide();});
    r.addView(sideBtn,bp());

    section(r,"التشغيل");
    Button apply=new Button(this); apply.setText("تطبيق الإعدادات");
    apply.setOnClickListener(v->{Intent i=new Intent(this,FloatingSidebarService.class);i.setAction(FloatingSidebarService.ACTION_REFRESH);start(i);});
    r.addView(apply,bp());

    Button start=new Button(this); start.setText("تشغيل الشريط"); start.setOnClickListener(v->enable()); r.addView(start,bp());
    Button stop=new Button(this); stop.setText("إيقاف الشريط"); stop.setOnClickListener(v->stopService(new Intent(this,FloatingSidebarService.class))); r.addView(stop,bp());
    setContentView(sc);
  }

  void enable(){
    if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));return;}
    start(new Intent(this,FloatingSidebarService.class));
  }
  void start(Intent i){ if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }
  void section(LinearLayout r,String s){TextView t=txt(s,18,Color.rgb(120,190,255),true);LinearLayout.LayoutParams q=mp();q.topMargin=dp(18);r.addView(t,q);}
  void setOp(int x){opText.setText("الشفافية: "+(x+20)+"%");}
  void setCols(int x){colText.setText("عدد الأعمدة: "+(x+2));}
  void setSize(int x){sizeText.setText("حجم المقبض: "+(x+20));}
  void refreshSide(){sideBtn.setText(p.getString("side","right").equals("right")?"مكان الشريط: اليمين":"مكان الشريط: اليسار");}
  SeekBar.OnSeekBarChangeListener listener(java.util.function.IntConsumer c){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int x,boolean f){c.accept(x);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}};}
  TextView txt(String s,int z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT_BOLD);return t;}
  LinearLayout.LayoutParams mp(){return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);}
  LinearLayout.LayoutParams bp(){LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(54));q.topMargin=dp(9);return q;}
  int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
}
