# SmartSidebar

Native Android floating sidebar launcher written in Kotlin with Jetpack Compose. Package: `com.smartsidebar.app`.

## Current technical baseline

- Min SDK: Android 8.0 / API 26
- Compile/Target SDK: Android 17 / API 37
- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0 (installed by GitHub Actions)
- JDK: 17
- Compose BOM: 2026.09.00
- DataStore Preferences: 1.2.1
- Local-only: no INTERNET permission, Firebase, analytics, ads, account, server, root, ADB, Shizuku, or Accessibility automation.

AGP 9 uses built-in Kotlin support, so this project intentionally does not apply `org.jetbrains.kotlin.android`. The Compose compiler plugin is pinned to Kotlin 2.4.10.

## Features

- User-controlled `TYPE_APPLICATION_OVERLAY` floating edge handle.
- Drag handle vertically and move it between left/right edges.
- Tap to open a narrow vertical list; long-press opens settings; horizontal swipe toward the edge closes the list.
- Choose 1–10 launchable apps, search them, and reorder selected apps by long-press drag.
- Handle style, size, side, vertical position, opacity, color, icon, and auto-hide delay.
- Sidebar width, opacity, background, corner radius, icon size/shape, labels, spacing, position, and animation.
- Close-after-launch, outside-tap close, haptics, sound, reboot option, position persistence.
- Settings stored with Jetpack DataStore Preferences.
- Foreground service with a persistent notification while the sidebar is active.
- Android 13+ notification permission request.
- Android 14+ `specialUse` foreground-service type declaration.
- Conservative device compatibility page.
- JSON settings export/import.
- Full-screen fallback when freeform/floating launch is unavailable.

## Important limitation: floating external app windows

Android does not provide a universal public API that can force arbitrary third-party apps into OEM floating-window mode. `ActivityOptions.setLaunchBounds()` and `FLAG_ACTIVITY_LAUNCH_ADJACENT` are best-effort and can be ignored by the OS/OEM. SmartSidebar only attempts a bounded/adjacent launch when the device advertises the official freeform-window-management system feature. Otherwise it launches the selected app normally. No private API or vendor automation is used.

Picture-in-Picture is informational only: PiP is controlled by the launched app and is not a replacement for arbitrary freeform windows.

## Permissions

### Display over other apps
Required to render the handle/sidebar above Chrome, WhatsApp, YouTube, Instagram, etc. The app opens the official `ACTION_MANAGE_OVERLAY_PERMISSION` screen and checks `Settings.canDrawOverlays()` when returning.

### Notifications
On Android 13+, the app can request `POST_NOTIFICATIONS`. The sidebar itself uses a foreground service and creates a low-importance notification channel.

### Boot completed
`RECEIVE_BOOT_COMPLETED` is used only if the user enables **Start after device reboot**. OEM battery/background policies can still delay or block restart.

## Package visibility

The manifest declares a `<queries>` launcher intent (`ACTION_MAIN` + `CATEGORY_LAUNCHER`) so the app can query launchable applications without requesting broad `QUERY_ALL_PACKAGES` access.

## Build locally

Use a recent Android Studio with JDK 17 and Android SDK 37 installed. Open the folder and sync Gradle. The repository intentionally relies on the IDE's Gradle integration or the GitHub workflow's pinned Gradle 9.6 installation rather than committing a binary Gradle wrapper JAR.

Command-line equivalent when Gradle 9.6 is installed:

```bash
gradle :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Upload to GitHub (very simple)

1. Create a new empty GitHub repository named `SmartSidebar`.
2. Unzip this project.
3. Upload **all files and folders**, including the hidden `.github` folder.
4. Commit to `main`.
5. Open **Actions** → **Build SmartSidebar APK**.
6. Open the completed run.
7. Download the artifact named **SmartSidebar-APK**.
8. Extract it to get `app-debug.apk`.

The workflow installs Android API 37 / Build Tools 36.0.0, accepts SDK licenses, uses JDK 17 and Gradle 9.6, builds `:app:assembleDebug`, and uploads the APK.

## Install APK

Copy `app-debug.apk` to the Android phone, allow installation from the browser/file-manager source if Android asks, install it, open Smart Sidebar, grant **Display over other apps**, choose apps, then press **Start Sidebar**.

## Updating the app later with the same signing identity

Android updates require the same application ID and signing certificate. Keep `applicationId = "com.smartsidebar.app"`, increase `versionCode`, and normally update `versionName`.

For release builds, create a keystore **outside the repository**. Store the keystore as a protected GitHub Secret (commonly Base64-encoded), and store alias/password values as separate GitHub Secrets. In a release workflow, reconstruct the keystore temporarily on the runner and pass credentials to Gradle through environment variables or a generated non-committed `keystore.properties`. Never commit `.jks`, `.keystore`, or passwords.

Debug APKs produced by different machines/runners may use different debug keys. For reliable in-place upgrades distributed to users, use one fixed release key from the beginning and protect it carefully.

## Device/OEM notes

The core overlay behavior is based on public Android APIs and is designed for OPPO/ColorOS, realme UI, OnePlus/OxygenOS, Samsung One UI, Xiaomi/Redmi/POCO MIUI/HyperOS, vivo/Funtouch OS, Motorola, Pixel, Honor, and other Android devices. OEMs can impose extra battery/background restrictions or change where overlay/autostart controls appear. SmartSidebar does not automate those vendor settings.

## Project structure

```text
SmartSidebar/
├── .github/workflows/build.yml
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/smartsidebar/app/
│       │   ├── MainActivity.kt
│       │   ├── SmartSidebarApp.kt
│       │   ├── data/AppRepository.kt
│       │   ├── data/SettingsStore.kt
│       │   ├── model/Models.kt
│       │   ├── service/BootReceiver.kt
│       │   ├── service/FloatingSidebarService.kt
│       │   ├── ui/SmartSidebarRoot.kt
│       │   ├── ui/theme/Theme.kt
│       │   └── util/DeviceCapabilityManager.kt
│       └── res/...
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts
└── README.md
```
