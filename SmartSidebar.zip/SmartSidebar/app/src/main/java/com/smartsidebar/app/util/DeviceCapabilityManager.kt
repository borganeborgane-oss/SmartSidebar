package com.smartsidebar.app.util

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.os.PowerManager

data class DeviceCompatibility(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val overlaySupport: Boolean,
    val multiWindow: String,
    val freeformAttempt: String,
    val pip: Boolean,
    val batteryRestrictions: String,
    val floatingAppWindowSupport: String
)

class DeviceCapabilityManager(private val context: Context) {
    private val pm = context.packageManager

    fun snapshot(): DeviceCompatibility {
        val freeform = pm.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
        val pip = pm.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        val lowRam = (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).isLowRamDevice
        val overlay = Settings.canDrawOverlays(context)
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryNormal = power.isIgnoringBatteryOptimizations(context.packageName)
        val multi = when {
            Build.VERSION.SDK_INT < 24 -> "Not available"
            freeform -> "Supported"
            else -> "Unknown"
        }
        val freeformAttempt = if (freeform) "Available" else "Not available"
        val floating = if (freeform) "Supported" else if (Build.VERSION.SDK_INT >= 24 && !lowRam) "Experimental" else "Not detected"
        return DeviceCompatibility(
            manufacturer = Build.MANUFACTURER.ifBlank { "Unknown" },
            model = Build.MODEL.ifBlank { "Unknown" },
            androidVersion = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            overlaySupport = overlay,
            multiWindow = multi,
            freeformAttempt = freeformAttempt,
            pip = pip,
            batteryRestrictions = if (batteryNormal) "Normal" else "Possible",
            floatingAppWindowSupport = floating
        )
    }

    fun shouldAttemptFloatingWindow(): Boolean =
        Build.VERSION.SDK_INT >= 24 && pm.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
}
