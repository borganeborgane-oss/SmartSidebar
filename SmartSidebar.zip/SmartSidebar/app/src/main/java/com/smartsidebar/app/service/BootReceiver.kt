package com.smartsidebar.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.smartsidebar.app.SmartSidebarApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val app = context.applicationContext as SmartSidebarApp
                val s = app.settingsStore.settings.first()
                if (s.enabled && s.startAfterReboot && s.showHandle && Settings.canDrawOverlays(context)) {
                    runCatching {
                        ContextCompat.startForegroundService(context, Intent(context, FloatingSidebarService::class.java))
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}
