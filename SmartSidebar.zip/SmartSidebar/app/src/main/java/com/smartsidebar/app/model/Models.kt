package com.smartsidebar.app.model

data class LaunchableApp(
    val packageName: String,
    val label: String
)

enum class HandleSide { LEFT, RIGHT }
enum class HandleStyle { PILL, CIRCLE, THIN_LINE, ROUNDED_RECTANGLE }
enum class HandleIcon { ARROW, DOTS, LINES, CUSTOM, NONE }
enum class SidebarBackground { DARK, LIGHT, TRANSPARENT }
enum class IconShape { SQUARE, ROUNDED_SQUARE, CIRCLE, SQUIRCLE }
enum class SidebarPosition { TOP, CENTER, BOTTOM }
enum class OpeningAnimation { SLIDE, FADE, SCALE, NONE }
enum class AnimationSpeed { FAST, NORMAL, SLOW }

data class SidebarSettings(
    val enabled: Boolean = false,
    val showHandle: Boolean = true,
    val selectedApps: List<String> = emptyList(),
    val appsInitialized: Boolean = false,
    val handleSide: HandleSide = HandleSide.RIGHT,
    val handleYFraction: Float = 0.45f,
    val rememberHandlePosition: Boolean = true,
    val handleStyle: HandleStyle = HandleStyle.PILL,
    val handleWidthDp: Int = 18,
    val handleHeightDp: Int = 92,
    val handleOpacity: Float = 0.72f,
    val handleColorArgb: Long = 0xFF5F6368,
    val handleIcon: HandleIcon = HandleIcon.ARROW,
    val autoHideHandle: Boolean = true,
    val autoHideDelaySec: Int = 3,
    val sidebarWidthDp: Int = 170,
    val sidebarOpacity: Float = 0.94f,
    val sidebarBackground: SidebarBackground = SidebarBackground.DARK,
    val cornerRadiusDp: Int = 22,
    val iconSizeDp: Int = 42,
    val iconShape: IconShape = IconShape.ROUNDED_SQUARE,
    val showAppNames: Boolean = true,
    val appNameFontSizeSp: Int = 13,
    val verticalSpacingDp: Int = 8,
    val sidebarPosition: SidebarPosition = SidebarPosition.CENTER,
    val openingAnimation: OpeningAnimation = OpeningAnimation.SLIDE,
    val animationSpeed: AnimationSpeed = AnimationSpeed.NORMAL,
    val closeAfterLaunch: Boolean = true,
    val closeOnOutsideTap: Boolean = true,
    val hapticFeedback: Boolean = true,
    val sound: Boolean = false,
    val keepAfterRotation: Boolean = true,
    val startAfterReboot: Boolean = false,
    val floatingWindowEnabled: Boolean = false,
    val shownFloatingUnsupportedToast: Boolean = false
)
