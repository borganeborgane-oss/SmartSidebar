package com.smartsidebar.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.smartsidebar.app.model.LaunchableApp

class AppRepository(private val context: Context) {
    fun getLaunchableApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val flags = if (android.os.Build.VERSION.SDK_INT >= 33) PackageManager.ResolveInfoFlags.of(0) else null
        @Suppress("DEPRECATION")
        val activities = if (flags != null) {
            context.packageManager.queryIntentActivities(intent, flags)
        } else {
            context.packageManager.queryIntentActivities(intent, 0)
        }
        return activities
            .asSequence()
            .map { LaunchableApp(it.activityInfo.packageName, it.loadLabel(context.packageManager).toString()) }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
            .toList()
    }
}
