package com.smartsidebar.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartsidebar.app.data.AppRepository
import com.smartsidebar.app.model.SidebarSettings
import com.smartsidebar.app.service.FloatingSidebarService
import com.smartsidebar.app.ui.SmartSidebarRoot
import com.smartsidebar.app.ui.theme.SmartSidebarTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as SmartSidebarApp
        val repo = AppRepository(this)
        setContent {
            val settings by app.settingsStore.settings.collectAsStateWithLifecycle(initialValue = SidebarSettings())
            val scope = rememberCoroutineScope()
            var overlayGranted by remember { mutableStateOf(Settings.canDrawOverlays(this)) }

            DisposableEffect(Unit) {
                val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                    if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) overlayGranted = Settings.canDrawOverlays(this@MainActivity)
                }
                lifecycle.addObserver(observer)
                onDispose { lifecycle.removeObserver(observer) }
            }

            LaunchedEffect(Unit) {
                val s = app.settingsStore.settings.first()
                if (!s.appsInitialized) {
                    app.settingsStore.setSelectedApps(repo.getLaunchableApps().take(6).map { it.packageName })
                }
            }

            SmartSidebarTheme {
                SmartSidebarRoot(
                    settings = settings,
                    overlayGranted = overlayGranted,
                    appRepository = repo,
                    store = app.settingsStore,
                    onGrantOverlay = {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    },
                    onRequestNotification = {
                        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    },
                    onStartService = {
                        scope.launch {
                            app.settingsStore.setEnabled(true)
                            if (Settings.canDrawOverlays(this@MainActivity)) {
                                ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, FloatingSidebarService::class.java))
                            }
                        }
                    },
                    onStopService = {
                        scope.launch { app.settingsStore.setEnabled(false) }
                        stopService(Intent(this, FloatingSidebarService::class.java))
                    }
                )
            }
        }
    }
}
