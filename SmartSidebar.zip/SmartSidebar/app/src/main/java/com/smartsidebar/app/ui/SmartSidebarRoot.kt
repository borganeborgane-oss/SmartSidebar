package com.smartsidebar.app.ui

import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartsidebar.app.data.AppRepository
import com.smartsidebar.app.data.SettingsStore
import com.smartsidebar.app.model.*
import com.smartsidebar.app.util.DeviceCapabilityManager
import kotlinx.coroutines.launch
import java.nio.charset.StandardCharsets
import kotlin.math.abs

enum class Screen { HOME, APPS, HANDLE, APPEARANCE, BEHAVIOR, FLOATING, PERMISSIONS, COMPATIBILITY, ADVANCED, ABOUT }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartSidebarRoot(
    settings: SidebarSettings,
    overlayGranted: Boolean,
    appRepository: AppRepository,
    store: SettingsStore,
    onGrantOverlay: () -> Unit,
    onRequestNotification: () -> Unit,
    onStartService: () -> Unit,
    onStopService: () -> Unit
) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    val title = when (screen) {
        Screen.HOME -> "Smart Sidebar"; Screen.APPS -> "Choose Apps"; Screen.HANDLE -> "Floating Handle"
        Screen.APPEARANCE -> "Sidebar Appearance"; Screen.BEHAVIOR -> "Behavior"; Screen.FLOATING -> "Floating Window"
        Screen.PERMISSIONS -> "Permissions"; Screen.COMPATIBILITY -> "Device Compatibility"; Screen.ADVANCED -> "Advanced"; Screen.ABOUT -> "About"
    }
    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = {
            if (screen != Screen.HOME) IconButton(onClick = { screen = Screen.HOME }) { Icon(Icons.Default.ArrowBack, null) }
        })
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(settings, overlayGranted, onStartService, onStopService) { screen = it }
                Screen.APPS -> AppSelectionScreen(settings, appRepository, store)
                Screen.HANDLE -> HandleScreen(settings, store)
                Screen.APPEARANCE -> AppearanceScreen(settings, store)
                Screen.BEHAVIOR -> BehaviorScreen(settings, store)
                Screen.FLOATING -> FloatingScreen(settings, store)
                Screen.PERMISSIONS -> PermissionsScreen(overlayGranted, onGrantOverlay, onRequestNotification)
                Screen.COMPATIBILITY -> CompatibilityScreen()
                Screen.ADVANCED -> AdvancedScreen(settings, store)
                Screen.ABOUT -> AboutScreen()
            }
        }
    }
}

@Composable
private fun HomeScreen(s: SidebarSettings, overlay: Boolean, start: () -> Unit, stop: () -> Unit, nav: (Screen) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text(if (s.enabled) "● Running" else "○ Stopped", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(if (overlay) "Overlay permission granted" else "Overlay permission required")
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = start, enabled = overlay) { Text("Start Sidebar") }
                        OutlinedButton(onClick = stop) { Text("Stop Sidebar") }
                    }
                }
            }
        }
        val entries = listOf(
            Triple(Screen.APPS, Icons.Default.Apps, "Apps · ${s.selectedApps.size}/10"),
            Triple(Screen.HANDLE, Icons.Default.TouchApp, "Floating Handle"),
            Triple(Screen.APPEARANCE, Icons.Default.Palette, "Sidebar Appearance"),
            Triple(Screen.BEHAVIOR, Icons.Default.Tune, "Behavior"),
            Triple(Screen.FLOATING, Icons.Default.PictureInPictureAlt, "Floating Window"),
            Triple(Screen.PERMISSIONS, Icons.Default.AdminPanelSettings, "Permissions"),
            Triple(Screen.COMPATIBILITY, Icons.Default.PhoneAndroid, "Device Compatibility"),
            Triple(Screen.ADVANCED, Icons.Default.Settings, "Advanced"),
            Triple(Screen.ABOUT, Icons.Default.Info, "About")
        )
        items(entries.size) { i ->
            val e = entries[i]
            ListItem(headlineContent = { Text(e.third) }, leadingContent = { Icon(e.second, null) }, trailingContent = { Icon(Icons.Default.ChevronRight, null) }, modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp)).clickable { nav(e.first) })
        }
    }
    // Transparent navigation overlay built separately to keep ListItem visuals simple.
    Column(Modifier.padding(horizontal = 16.dp, vertical = 150.dp)) { }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppSelectionScreen(s: SidebarSettings, repo: AppRepository, store: SettingsStore) {
    val scope = rememberCoroutineScope(); val context = LocalContext.current
    val apps = remember { repo.getLaunchableApps() }
    var query by remember { mutableStateOf("") }
    val selected = s.selectedApps
    val filtered = remember(query, apps) { apps.filter { it.label.contains(query, true) || it.packageName.contains(query, true) } }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Search") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(8.dp)); Text("Selected: ${selected.size} / 10", fontWeight = FontWeight.Bold)
        if (selected.isNotEmpty()) {
            Text("Long-press and drag selected rows to reorder.", style = MaterialTheme.typography.bodySmall)
            selected.forEachIndexed { idx, pkg ->
                val app = apps.firstOrNull { it.packageName == pkg } ?: return@forEachIndexed
                var drag by remember(pkg) { mutableFloatStateOf(0f) }
                ListItem(
                    headlineContent = { Text("${idx + 1}. ${app.label}") },
                    leadingContent = { Icon(Icons.Default.DragHandle, null) },
                    trailingContent = { IconButton(onClick = { scope.launch { store.setSelectedApps(selected - pkg) } }) { Icon(Icons.Default.Close, null) } },
                    modifier = Modifier.fillMaxWidth().pointerInput(selected, pkg) {
                        detectDragGesturesAfterLongPress(
                            onDragEnd = { drag = 0f }, onDragCancel = { drag = 0f },
                            onDrag = { change, amount ->
                                change.consume(); drag += amount.y
                                if (abs(drag) > 56.dp.toPx()) {
                                    val target = if (drag > 0) idx + 1 else idx - 1
                                    if (target in selected.indices) {
                                        val m = selected.toMutableList(); val item = m.removeAt(idx); m.add(target, item)
                                        scope.launch { store.setSelectedApps(m) }
                                    }
                                    drag = 0f
                                }
                            }
                        )
                    }
                )
            }
            HorizontalDivider()
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(filtered.size) { i ->
                val app = filtered[i]; val checked = app.packageName in selected
                ListItem(headlineContent = { Text(app.label) }, supportingContent = { Text(app.packageName) }, trailingContent = {
                    Checkbox(checked = checked, onCheckedChange = { want ->
                        if (want && selected.size >= 10) Toast.makeText(context, "Maximum 10 apps allowed", Toast.LENGTH_SHORT).show()
                        else scope.launch { store.setSelectedApps(if (want) selected + app.packageName else selected - app.packageName) }
                    })
                })
            }
        }
    }
}

@Composable private fun HandleScreen(s: SidebarSettings, store: SettingsStore) {
    val scope = rememberCoroutineScope()
    SettingsColumn {
        SwitchRow("Show floating handle", s.showHandle) { scope.launch { store.setShowHandle(it) } }
        EnumRow("Side", s.handleSide) { scope.launch { store.setHandleSide(it) } }
        EnumRow("Handle style", s.handleStyle) { scope.launch { store.setHandleStyle(it) } }
        EnumRow("Handle icon", s.handleIcon) { scope.launch { store.setHandleIcon(it) } }
        ChoiceRow("Handle color", when (s.handleColorArgb) { 0xFF4285F4 -> "Blue"; 0xFF34A853 -> "Green"; 0xFFEA4335 -> "Red"; 0xFF9C27B0 -> "Purple"; else -> "Gray" }, listOf("Gray","Blue","Green","Red","Purple")) { name -> scope.launch { store.setHandleColor(when(name) { "Blue" -> 0xFF4285F4; "Green" -> 0xFF34A853; "Red" -> 0xFFEA4335; "Purple" -> 0xFF9C27B0; else -> 0xFF5F6368 }) } }
        SliderRow("Vertical position", s.handleYFraction, 0f..1f, "${(s.handleYFraction*100).toInt()}%") { scope.launch { store.setHandleY(it) } }
        SliderRow("Handle width", s.handleWidthDp.toFloat(), 6f..40f, "${s.handleWidthDp} dp") { scope.launch { store.setHandleWidth(it.toInt()) } }
        SliderRow("Handle height", s.handleHeightDp.toFloat(), 32f..160f, "${s.handleHeightDp} dp") { scope.launch { store.setHandleHeight(it.toInt()) } }
        SliderRow("Handle opacity", s.handleOpacity, .2f..1f, "${(s.handleOpacity*100).toInt()}%") { scope.launch { store.setHandleOpacity(it) } }
        SwitchRow("Auto-hide handle", s.autoHideHandle) { scope.launch { store.setAutoHide(it) } }
        ChoiceRow("Auto-hide delay", "${s.autoHideDelaySec}s", listOf("1s","2s","3s","5s")) { scope.launch { store.setAutoHideDelay(it.removeSuffix("s").toInt()) } }
        SwitchRow("Remember handle position", s.rememberHandlePosition) { scope.launch { store.setRememberPosition(it) } }
    }
}

@Composable private fun AppearanceScreen(s: SidebarSettings, store: SettingsStore) {
    val scope = rememberCoroutineScope()
    SettingsColumn {
        SliderRow("Sidebar width", s.sidebarWidthDp.toFloat(), 110f..280f, "${s.sidebarWidthDp} dp") { scope.launch { store.setSidebarWidth(it.toInt()) } }
        SliderRow("Sidebar opacity", s.sidebarOpacity, .2f..1f, "${(s.sidebarOpacity*100).toInt()}%") { scope.launch { store.setSidebarOpacity(it) } }
        EnumRow("Background", s.sidebarBackground) { scope.launch { store.setSidebarBackground(it) } }
        SliderRow("Corner radius", s.cornerRadiusDp.toFloat(), 0f..40f, "${s.cornerRadiusDp} dp") { scope.launch { store.setCornerRadius(it.toInt()) } }
        SliderRow("Icon size", s.iconSizeDp.toFloat(), 28f..72f, "${s.iconSizeDp} dp") { scope.launch { store.setIconSize(it.toInt()) } }
        EnumRow("Icon shape", s.iconShape) { scope.launch { store.setIconShape(it) } }
        SwitchRow("Show app names", s.showAppNames) { scope.launch { store.setShowAppNames(it) } }
        SliderRow("App name font size", s.appNameFontSizeSp.toFloat(), 10f..20f, "${s.appNameFontSizeSp} sp") { scope.launch { store.setFontSize(it.toInt()) } }
        SliderRow("Vertical spacing", s.verticalSpacingDp.toFloat(), 0f..24f, "${s.verticalSpacingDp} dp") { scope.launch { store.setVerticalSpacing(it.toInt()) } }
        EnumRow("Position", s.sidebarPosition) { scope.launch { store.setSidebarPosition(it) } }
        EnumRow("Opening animation", s.openingAnimation) { scope.launch { store.setOpeningAnimation(it) } }
        EnumRow("Animation speed", s.animationSpeed) { scope.launch { store.setAnimationSpeed(it) } }
    }
}

@Composable private fun BehaviorScreen(s: SidebarSettings, store: SettingsStore) {
    val scope = rememberCoroutineScope(); SettingsColumn {
        SwitchRow("Close Sidebar after launching app", s.closeAfterLaunch) { scope.launch { store.setCloseAfterLaunch(it) } }
        SwitchRow("Close when tapping outside", s.closeOnOutsideTap) { scope.launch { store.setCloseOutside(it) } }
        SwitchRow("Haptic feedback", s.hapticFeedback) { scope.launch { store.setHaptic(it) } }
        SwitchRow("Sound", s.sound) { scope.launch { store.setSound(it) } }
        SwitchRow("Keep Sidebar after screen rotation", s.keepAfterRotation) { scope.launch { store.setKeepRotation(it) } }
        SwitchRow("Start after device reboot", s.startAfterReboot) { scope.launch { store.setStartAfterReboot(it) } }
    }
}

@Composable private fun FloatingScreen(s: SidebarSettings, store: SettingsStore) {
    val scope = rememberCoroutineScope(); val c = DeviceCapabilityManager(LocalContext.current).snapshot()
    SettingsColumn {
        SwitchRow("Open apps in floating window when supported", s.floatingWindowEnabled) { scope.launch { store.setFloatingWindow(it) } }
        Text("Detected support: ${c.floatingAppWindowSupport}", fontWeight = FontWeight.Bold)
        Text("Android launch bounds and adjacent-launch flags are best-effort. Some OEMs ignore them; SmartSidebar falls back to normal full-screen launch.")
    }
}

@Composable private fun PermissionsScreen(overlay: Boolean, grant: () -> Unit, requestNotification: () -> Unit) {
    SettingsColumn {
        Text("Display over other apps", fontWeight = FontWeight.Bold)
        Text(if (overlay) "Granted ✅" else "Not granted ❌")
        Button(onClick = grant) { Text("Grant permission") }
        if (Build.VERSION.SDK_INT >= 33) {
            HorizontalDivider(); Text("Notifications", fontWeight = FontWeight.Bold)
            Text("Android 13+ may require notification permission so the foreground-service notification is visible.")
            OutlinedButton(onClick = requestNotification) { Text("Request notification permission") }
        }
    }
}

@Composable private fun CompatibilityScreen() {
    val c = DeviceCapabilityManager(LocalContext.current).snapshot()
    SettingsColumn {
        InfoRow("Manufacturer", c.manufacturer); InfoRow("Model", c.model); InfoRow("Android", c.androidVersion)
        InfoRow("Overlay support", if (c.overlaySupport) "Supported ✅" else "Permission not granted")
        InfoRow("Multi-window", c.multiWindow); InfoRow("Freeform attempt", c.freeformAttempt)
        InfoRow("Picture-in-Picture", if (c.pip) "Supported" else "Not detected")
        InfoRow("Battery restrictions", c.batteryRestrictions); InfoRow("Floating App Window Support", c.floatingAppWindowSupport)
        Text("Compatibility is reported conservatively; OEM behavior can differ even when platform APIs exist.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun AdvancedScreen(s: SidebarSettings, store: SettingsStore) {
    val scope = rememberCoroutineScope(); val context = LocalContext.current
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch { runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(store.exportJson(s).toByteArray(StandardCharsets.UTF_8)) } }.onSuccess { Toast.makeText(context,"Settings exported",Toast.LENGTH_SHORT).show() } }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Empty file") }.onSuccess { runCatching { store.importJson(it) }.onSuccess { Toast.makeText(context,"Settings imported",Toast.LENGTH_SHORT).show() }.onFailure { Toast.makeText(context,"Invalid settings file",Toast.LENGTH_SHORT).show() } } }
    }
    SettingsColumn {
        Button(onClick = { scope.launch { store.resetHandlePosition() } }) { Text("Reset handle position") }
        Button(onClick = { scope.launch { store.clearSelectedApps() } }) { Text("Clear selected apps") }
        OutlinedButton(onClick = { exportLauncher.launch("smartsidebar-settings.json") }) { Text("Export settings") }
        OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json","text/plain")) }) { Text("Import settings") }
        OutlinedButton(onClick = { scope.launch { store.resetAll() } }) { Text("Reset settings") }
        HorizontalDivider(); Text("Debug information", fontWeight = FontWeight.Bold)
        Text("SDK ${Build.VERSION.SDK_INT} · ${Build.MANUFACTURER} ${Build.MODEL}\nPackage: com.smartsidebar.app\nNo account, analytics, ads, or Internet permission.")
    }
}

@Composable private fun AboutScreen() = SettingsColumn {
    Text("Smart Sidebar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Text("Version 1.0.0")
    Text("Local-only Android sidebar launcher. Uses the official overlay permission and a user-visible foreground service. No root, ADB, Shizuku, accessibility automation, analytics, ads, server, account, or Internet permission.")
}

@Composable private fun SettingsColumn(content: @Composable ColumnScope.() -> Unit) = Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
@Composable private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) }
@Composable private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, onChange: (Float) -> Unit) { Text("$label · $shown"); Slider(value, onChange, valueRange = range) }
@Composable private fun InfoRow(k: String, v: String) = Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(k); Text(v, fontWeight = FontWeight.Medium) }

@Composable
private fun ChoiceRow(label: String, current: String, values: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box { OutlinedButton(onClick = { open = true }) { Text("$label: $current") }; DropdownMenu(open, { open = false }) { values.forEach { DropdownMenuItem({ Text(it) }, onClick = { open = false; onPick(it) }) } } }
}

@Composable
private inline fun <reified T : Enum<T>> EnumRow(label: String, current: T, crossinline onPick: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box { OutlinedButton(onClick = { open = true }) { Text("$label: ${current.name.replace('_',' ')}") }; DropdownMenu(open, { open = false }) { enumValues<T>().forEach { v -> DropdownMenuItem({ Text(v.name.replace('_',' ')) }, onClick = { open = false; onPick(v) }) } } }
}
