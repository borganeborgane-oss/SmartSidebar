package com.smartsidebar.app

import android.app.Application
import com.smartsidebar.app.data.SettingsStore

class SmartSidebarApp : Application() {
    val settingsStore by lazy { SettingsStore(this) }
}
