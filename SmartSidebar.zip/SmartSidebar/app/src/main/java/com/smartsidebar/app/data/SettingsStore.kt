package com.smartsidebar.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.smartsidebar.app.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore("smart_sidebar_settings")

class SettingsStore(private val context: Context) {
    private object K {
        val ENABLED = booleanPreferencesKey("enabled")
        val SHOW_HANDLE = booleanPreferencesKey("show_handle")
        val SELECTED_APPS = stringPreferencesKey("selected_apps")
        val APPS_INITIALIZED = booleanPreferencesKey("apps_initialized")
        val HANDLE_SIDE = stringPreferencesKey("handle_side")
        val HANDLE_Y = floatPreferencesKey("handle_y")
        val REMEMBER_POSITION = booleanPreferencesKey("remember_position")
        val HANDLE_STYLE = stringPreferencesKey("handle_style")
        val HANDLE_WIDTH = intPreferencesKey("handle_width")
        val HANDLE_HEIGHT = intPreferencesKey("handle_height")
        val HANDLE_OPACITY = floatPreferencesKey("handle_opacity")
        val HANDLE_COLOR = longPreferencesKey("handle_color")
        val HANDLE_ICON = stringPreferencesKey("handle_icon")
        val AUTO_HIDE = booleanPreferencesKey("auto_hide")
        val AUTO_HIDE_DELAY = intPreferencesKey("auto_hide_delay")
        val SIDEBAR_WIDTH = intPreferencesKey("sidebar_width")
        val SIDEBAR_OPACITY = floatPreferencesKey("sidebar_opacity")
        val SIDEBAR_BG = stringPreferencesKey("sidebar_bg")
        val CORNER_RADIUS = intPreferencesKey("corner_radius")
        val ICON_SIZE = intPreferencesKey("icon_size")
        val ICON_SHAPE = stringPreferencesKey("icon_shape")
        val SHOW_NAMES = booleanPreferencesKey("show_names")
        val FONT_SIZE = intPreferencesKey("font_size")
        val VERTICAL_SPACING = intPreferencesKey("vertical_spacing")
        val SIDEBAR_POSITION = stringPreferencesKey("sidebar_position")
        val OPENING_ANIMATION = stringPreferencesKey("opening_animation")
        val ANIMATION_SPEED = stringPreferencesKey("animation_speed")
        val CLOSE_AFTER_LAUNCH = booleanPreferencesKey("close_after_launch")
        val CLOSE_OUTSIDE = booleanPreferencesKey("close_outside")
        val HAPTIC = booleanPreferencesKey("haptic")
        val SOUND = booleanPreferencesKey("sound")
        val KEEP_ROTATION = booleanPreferencesKey("keep_rotation")
        val START_REBOOT = booleanPreferencesKey("start_reboot")
        val FLOATING_WINDOW = booleanPreferencesKey("floating_window")
        val FLOATING_TOAST_SHOWN = booleanPreferencesKey("floating_toast_shown")
    }

    val settings: Flow<SidebarSettings> = context.dataStore.data.map { p ->
        SidebarSettings(
            enabled = p[K.ENABLED] ?: false,
            showHandle = p[K.SHOW_HANDLE] ?: true,
            selectedApps = decodeList(p[K.SELECTED_APPS]),
            appsInitialized = p[K.APPS_INITIALIZED] ?: false,
            handleSide = enumValue(p[K.HANDLE_SIDE], HandleSide.RIGHT),
            handleYFraction = p[K.HANDLE_Y] ?: 0.45f,
            rememberHandlePosition = p[K.REMEMBER_POSITION] ?: true,
            handleStyle = enumValue(p[K.HANDLE_STYLE], HandleStyle.PILL),
            handleWidthDp = p[K.HANDLE_WIDTH] ?: 18,
            handleHeightDp = p[K.HANDLE_HEIGHT] ?: 92,
            handleOpacity = p[K.HANDLE_OPACITY] ?: 0.72f,
            handleColorArgb = p[K.HANDLE_COLOR] ?: 0xFF5F6368,
            handleIcon = enumValue(p[K.HANDLE_ICON], HandleIcon.ARROW),
            autoHideHandle = p[K.AUTO_HIDE] ?: true,
            autoHideDelaySec = p[K.AUTO_HIDE_DELAY] ?: 3,
            sidebarWidthDp = p[K.SIDEBAR_WIDTH] ?: 170,
            sidebarOpacity = p[K.SIDEBAR_OPACITY] ?: 0.94f,
            sidebarBackground = enumValue(p[K.SIDEBAR_BG], SidebarBackground.DARK),
            cornerRadiusDp = p[K.CORNER_RADIUS] ?: 22,
            iconSizeDp = p[K.ICON_SIZE] ?: 42,
            iconShape = enumValue(p[K.ICON_SHAPE], IconShape.ROUNDED_SQUARE),
            showAppNames = p[K.SHOW_NAMES] ?: true,
            appNameFontSizeSp = p[K.FONT_SIZE] ?: 13,
            verticalSpacingDp = p[K.VERTICAL_SPACING] ?: 8,
            sidebarPosition = enumValue(p[K.SIDEBAR_POSITION], SidebarPosition.CENTER),
            openingAnimation = enumValue(p[K.OPENING_ANIMATION], OpeningAnimation.SLIDE),
            animationSpeed = enumValue(p[K.ANIMATION_SPEED], AnimationSpeed.NORMAL),
            closeAfterLaunch = p[K.CLOSE_AFTER_LAUNCH] ?: true,
            closeOnOutsideTap = p[K.CLOSE_OUTSIDE] ?: true,
            hapticFeedback = p[K.HAPTIC] ?: true,
            sound = p[K.SOUND] ?: false,
            keepAfterRotation = p[K.KEEP_ROTATION] ?: true,
            startAfterReboot = p[K.START_REBOOT] ?: false,
            floatingWindowEnabled = p[K.FLOATING_WINDOW] ?: false,
            shownFloatingUnsupportedToast = p[K.FLOATING_TOAST_SHOWN] ?: false
        )
    }

    suspend fun setEnabled(v: Boolean) = edit(K.ENABLED, v)
    suspend fun setShowHandle(v: Boolean) = edit(K.SHOW_HANDLE, v)
    suspend fun setSelectedApps(v: List<String>) { context.dataStore.edit { it[K.SELECTED_APPS] = encodeList(v.take(10)); it[K.APPS_INITIALIZED] = true } }
    suspend fun setHandleSide(v: HandleSide) = edit(K.HANDLE_SIDE, v.name)
    suspend fun setHandleY(v: Float) = edit(K.HANDLE_Y, v.coerceIn(0f, 1f))
    suspend fun setRememberPosition(v: Boolean) = edit(K.REMEMBER_POSITION, v)
    suspend fun setHandleStyle(v: HandleStyle) = edit(K.HANDLE_STYLE, v.name)
    suspend fun setHandleWidth(v: Int) = edit(K.HANDLE_WIDTH, v)
    suspend fun setHandleHeight(v: Int) = edit(K.HANDLE_HEIGHT, v)
    suspend fun setHandleOpacity(v: Float) = edit(K.HANDLE_OPACITY, v)
    suspend fun setHandleColor(v: Long) = edit(K.HANDLE_COLOR, v)
    suspend fun setHandleIcon(v: HandleIcon) = edit(K.HANDLE_ICON, v.name)
    suspend fun setAutoHide(v: Boolean) = edit(K.AUTO_HIDE, v)
    suspend fun setAutoHideDelay(v: Int) = edit(K.AUTO_HIDE_DELAY, v)
    suspend fun setSidebarWidth(v: Int) = edit(K.SIDEBAR_WIDTH, v)
    suspend fun setSidebarOpacity(v: Float) = edit(K.SIDEBAR_OPACITY, v)
    suspend fun setSidebarBackground(v: SidebarBackground) = edit(K.SIDEBAR_BG, v.name)
    suspend fun setCornerRadius(v: Int) = edit(K.CORNER_RADIUS, v)
    suspend fun setIconSize(v: Int) = edit(K.ICON_SIZE, v)
    suspend fun setIconShape(v: IconShape) = edit(K.ICON_SHAPE, v.name)
    suspend fun setShowAppNames(v: Boolean) = edit(K.SHOW_NAMES, v)
    suspend fun setFontSize(v: Int) = edit(K.FONT_SIZE, v)
    suspend fun setVerticalSpacing(v: Int) = edit(K.VERTICAL_SPACING, v)
    suspend fun setSidebarPosition(v: SidebarPosition) = edit(K.SIDEBAR_POSITION, v.name)
    suspend fun setOpeningAnimation(v: OpeningAnimation) = edit(K.OPENING_ANIMATION, v.name)
    suspend fun setAnimationSpeed(v: AnimationSpeed) = edit(K.ANIMATION_SPEED, v.name)
    suspend fun setCloseAfterLaunch(v: Boolean) = edit(K.CLOSE_AFTER_LAUNCH, v)
    suspend fun setCloseOutside(v: Boolean) = edit(K.CLOSE_OUTSIDE, v)
    suspend fun setHaptic(v: Boolean) = edit(K.HAPTIC, v)
    suspend fun setSound(v: Boolean) = edit(K.SOUND, v)
    suspend fun setKeepRotation(v: Boolean) = edit(K.KEEP_ROTATION, v)
    suspend fun setStartAfterReboot(v: Boolean) = edit(K.START_REBOOT, v)
    suspend fun setFloatingWindow(v: Boolean) = edit(K.FLOATING_WINDOW, v)
    suspend fun markFloatingToastShown() = edit(K.FLOATING_TOAST_SHOWN, true)

    suspend fun resetHandlePosition() = setHandleY(0.45f)
    suspend fun clearSelectedApps() = setSelectedApps(emptyList())
    suspend fun resetAll() { context.dataStore.edit { it.clear() } }

    suspend fun exportJson(current: SidebarSettings): String = JSONObject().apply {
        put("format", 1)
        put("enabled", current.enabled)
        put("showHandle", current.showHandle)
        put("selectedApps", JSONArray(current.selectedApps))
        put("handleSide", current.handleSide.name)
        put("handleYFraction", current.handleYFraction)
        put("rememberHandlePosition", current.rememberHandlePosition)
        put("handleStyle", current.handleStyle.name)
        put("handleWidthDp", current.handleWidthDp)
        put("handleHeightDp", current.handleHeightDp)
        put("handleOpacity", current.handleOpacity)
        put("handleColorArgb", current.handleColorArgb)
        put("handleIcon", current.handleIcon.name)
        put("autoHideHandle", current.autoHideHandle)
        put("autoHideDelaySec", current.autoHideDelaySec)
        put("sidebarWidthDp", current.sidebarWidthDp)
        put("sidebarOpacity", current.sidebarOpacity)
        put("sidebarBackground", current.sidebarBackground.name)
        put("cornerRadiusDp", current.cornerRadiusDp)
        put("iconSizeDp", current.iconSizeDp)
        put("iconShape", current.iconShape.name)
        put("showAppNames", current.showAppNames)
        put("appNameFontSizeSp", current.appNameFontSizeSp)
        put("verticalSpacingDp", current.verticalSpacingDp)
        put("sidebarPosition", current.sidebarPosition.name)
        put("openingAnimation", current.openingAnimation.name)
        put("animationSpeed", current.animationSpeed.name)
        put("closeAfterLaunch", current.closeAfterLaunch)
        put("closeOnOutsideTap", current.closeOnOutsideTap)
        put("hapticFeedback", current.hapticFeedback)
        put("sound", current.sound)
        put("keepAfterRotation", current.keepAfterRotation)
        put("startAfterReboot", current.startAfterReboot)
        put("floatingWindowEnabled", current.floatingWindowEnabled)
    }.toString(2)

    suspend fun importJson(text: String) {
        val j = JSONObject(text)
        context.dataStore.edit { p ->
            fun bool(name: String, key: Preferences.Key<Boolean>, fallback: Boolean) { p[key] = j.optBoolean(name, fallback) }
            bool("enabled", K.ENABLED, false); bool("showHandle", K.SHOW_HANDLE, true)
            val a = j.optJSONArray("selectedApps")
            if (a != null) p[K.SELECTED_APPS] = encodeList((0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }.take(10))
            p[K.APPS_INITIALIZED] = true
            p[K.HANDLE_SIDE] = j.optString("handleSide", HandleSide.RIGHT.name)
            p[K.HANDLE_Y] = j.optDouble("handleYFraction", .45).toFloat().coerceIn(0f, 1f)
            bool("rememberHandlePosition", K.REMEMBER_POSITION, true)
            p[K.HANDLE_STYLE] = j.optString("handleStyle", HandleStyle.PILL.name)
            p[K.HANDLE_WIDTH] = j.optInt("handleWidthDp", 18); p[K.HANDLE_HEIGHT] = j.optInt("handleHeightDp", 92)
            p[K.HANDLE_OPACITY] = j.optDouble("handleOpacity", .72).toFloat(); p[K.HANDLE_COLOR] = j.optLong("handleColorArgb", 0xFF5F6368)
            p[K.HANDLE_ICON] = j.optString("handleIcon", HandleIcon.ARROW.name)
            bool("autoHideHandle", K.AUTO_HIDE, true); p[K.AUTO_HIDE_DELAY] = j.optInt("autoHideDelaySec", 3)
            p[K.SIDEBAR_WIDTH] = j.optInt("sidebarWidthDp", 170); p[K.SIDEBAR_OPACITY] = j.optDouble("sidebarOpacity", .94).toFloat()
            p[K.SIDEBAR_BG] = j.optString("sidebarBackground", SidebarBackground.DARK.name); p[K.CORNER_RADIUS] = j.optInt("cornerRadiusDp", 22)
            p[K.ICON_SIZE] = j.optInt("iconSizeDp", 42); p[K.ICON_SHAPE] = j.optString("iconShape", IconShape.ROUNDED_SQUARE.name)
            bool("showAppNames", K.SHOW_NAMES, true); p[K.FONT_SIZE] = j.optInt("appNameFontSizeSp", 13); p[K.VERTICAL_SPACING] = j.optInt("verticalSpacingDp", 8)
            p[K.SIDEBAR_POSITION] = j.optString("sidebarPosition", SidebarPosition.CENTER.name); p[K.OPENING_ANIMATION] = j.optString("openingAnimation", OpeningAnimation.SLIDE.name); p[K.ANIMATION_SPEED] = j.optString("animationSpeed", AnimationSpeed.NORMAL.name)
            bool("closeAfterLaunch", K.CLOSE_AFTER_LAUNCH, true); bool("closeOnOutsideTap", K.CLOSE_OUTSIDE, true); bool("hapticFeedback", K.HAPTIC, true); bool("sound", K.SOUND, false); bool("keepAfterRotation", K.KEEP_ROTATION, true); bool("startAfterReboot", K.START_REBOOT, false); bool("floatingWindowEnabled", K.FLOATING_WINDOW, false)
        }
    }

    private suspend fun <T> edit(key: Preferences.Key<T>, value: T) { context.dataStore.edit { it[key] = value } }
    private fun encodeList(v: List<String>) = JSONArray(v).toString()
    private fun decodeList(raw: String?): List<String> = runCatching {
        if (raw.isNullOrBlank()) emptyList() else JSONArray(raw).let { a -> (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) } }
    }.getOrDefault(emptyList())
    private inline fun <reified T : Enum<T>> enumValue(raw: String?, fallback: T): T = runCatching { enumValueOf<T>(raw ?: fallback.name) }.getOrDefault(fallback)
}
