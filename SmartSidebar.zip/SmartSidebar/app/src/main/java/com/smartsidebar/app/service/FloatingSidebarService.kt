package com.smartsidebar.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.smartsidebar.app.MainActivity
import com.smartsidebar.app.R
import com.smartsidebar.app.SmartSidebarApp
import com.smartsidebar.app.model.*
import com.smartsidebar.app.util.DeviceCapabilityManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class FloatingSidebarService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var wm: WindowManager
    private lateinit var store: com.smartsidebar.app.data.SettingsStore
    private lateinit var capability: DeviceCapabilityManager
    private var handleView: View? = null
    private var sidebarRoot: View? = null
    private var settings = SidebarSettings()
    private var autoHideJob: Job? = null
    private var lastTapAt = 0L

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = (application as SmartSidebarApp).settingsStore
        capability = DeviceCapabilityManager(this)
        createNotificationChannel()
        startAsForeground()
        scope.launch {
            store.settings.collectLatest { s ->
                settings = s
                if (!s.enabled || !s.showHandle || !Settings.canDrawOverlays(this@FloatingSidebarService)) {
                    removeAllOverlays()
                    if (!s.enabled) stopSelf()
                } else {
                    showOrRefreshHandle()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        autoHideJob?.cancel()
        removeAllOverlays()
        scope.cancel()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val openSettings = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(openSettings)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.notification_channel_description)
                setShowBadge(false)
            }
        )
    }

    private fun showOrRefreshHandle() {
        if (!Settings.canDrawOverlays(this)) return
        val current = handleView
        if (current == null) {
            val view = buildHandle()
            handleView = view
            runCatching { wm.addView(view, handleLayoutParams()) }.onFailure { handleView = null }
        } else {
            applyHandleAppearance(current)
            runCatching { wm.updateViewLayout(current, handleLayoutParams(current)) }
        }
        scheduleAutoHide()
    }

    private fun buildHandle(): TextView = TextView(this).apply {
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        textSize = 18f
        setPadding(0, 0, 0, 0)
        applyHandleAppearance(this)
        var downX = 0f
        var downY = 0f
        var startY = 0
        var dragging = false
        val slop = ViewConfiguration.get(this@FloatingSidebarService).scaledTouchSlop
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    autoHideJob?.cancel(); v.animate().alpha(settings.handleOpacity).setDuration(120).start()
                    downX = e.rawX; downY = e.rawY
                    startY = (v.layoutParams as WindowManager.LayoutParams).y
                    dragging = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(e.rawY - downY) > slop || kotlin.math.abs(e.rawX - downX) > slop) dragging = true
                    if (dragging) {
                        val p = v.layoutParams as WindowManager.LayoutParams
                        p.y = (startY + (e.rawY - downY).toInt()).coerceIn(-usableHalfHeight(), usableHalfHeight())
                        val center = resources.displayMetrics.widthPixels / 2f
                        val side = if (e.rawX < center) HandleSide.LEFT else HandleSide.RIGHT
                        p.gravity = Gravity.CENTER_VERTICAL or if (side == HandleSide.LEFT) Gravity.START else Gravity.END
                        runCatching { wm.updateViewLayout(v, p) }
                        true
                    } else false
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        val p = v.layoutParams as WindowManager.LayoutParams
                        val side = if ((p.gravity and Gravity.START) == Gravity.START) HandleSide.LEFT else HandleSide.RIGHT
                        val frac = ((p.y + usableHalfHeight()).toFloat() / (usableHalfHeight() * 2f)).coerceIn(0f, 1f)
                        scope.launch {
                            store.setHandleSide(side)
                            if (settings.rememberHandlePosition) store.setHandleY(frac)
                        }
                        scheduleAutoHide()
                        true
                    } else false
                }
                else -> false
            }
        }
        setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastTapAt > 250) toggleSidebar()
            lastTapAt = now
        }
        setOnLongClickListener {
            startActivity(Intent(this@FloatingSidebarService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        }
    }

    private fun applyHandleAppearance(v: View) {
        if (v is TextView) {
            v.text = when (settings.handleIcon) {
                HandleIcon.ARROW -> if (settings.handleSide == HandleSide.RIGHT) "‹" else "›"
                HandleIcon.DOTS -> "⋮"
                HandleIcon.LINES -> "≡"
                HandleIcon.CUSTOM -> "◆"
                HandleIcon.NONE -> ""
            }
        }
        v.alpha = settings.handleOpacity
        val radius = when (settings.handleStyle) {
            HandleStyle.CIRCLE -> dp(999).toFloat()
            HandleStyle.THIN_LINE -> dp(4).toFloat()
            HandleStyle.PILL -> dp(999).toFloat()
            HandleStyle.ROUNDED_RECTANGLE -> dp(10).toFloat()
        }
        v.background = GradientDrawable().apply {
            setColor(settings.handleColorArgb.toInt())
            cornerRadius = radius
        }
    }

    private fun handleLayoutParams(existing: View? = null): WindowManager.LayoutParams {
        val width = when (settings.handleStyle) {
            HandleStyle.THIN_LINE -> dp(6)
            HandleStyle.CIRCLE -> dp(settings.handleHeightDp.coerceIn(28, 64))
            else -> dp(settings.handleWidthDp)
        }
        val height = when (settings.handleStyle) {
            HandleStyle.CIRCLE -> width
            else -> dp(settings.handleHeightDp)
        }
        val y = if (existing != null && !settings.rememberHandlePosition) 0 else {
            ((settings.handleYFraction * 2f - 1f) * usableHalfHeight()).toInt()
        }
        return WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER_VERTICAL or if (settings.handleSide == HandleSide.LEFT) Gravity.START else Gravity.END
            this.y = y
        }
    }

    private fun toggleSidebar() {
        if (sidebarRoot != null) hideSidebar() else showSidebar()
    }

    private fun showSidebar() {
        if (sidebarRoot != null || !Settings.canDrawOverlays(this)) return
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
        }
        val panel = buildSidebarPanel()
        val lp = FrameLayout.LayoutParams(dp(settings.sidebarWidthDp), FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = when (settings.sidebarPosition) {
                SidebarPosition.TOP -> Gravity.TOP
                SidebarPosition.CENTER -> Gravity.CENTER_VERTICAL
                SidebarPosition.BOTTOM -> Gravity.BOTTOM
            } or if (settings.handleSide == HandleSide.LEFT) Gravity.START else Gravity.END
            val edge = dp(8)
            setMargins(if (settings.handleSide == HandleSide.LEFT) edge else 0, dp(24), if (settings.handleSide == HandleSide.RIGHT) edge else 0, dp(24))
        }
        root.addView(panel, lp)
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN && settings.closeOnOutsideTap) {
                val panelRect = Rect(); panel.getGlobalVisibleRect(panelRect)
                if (!panelRect.contains(e.rawX.toInt(), e.rawY.toInt())) {
                    hideSidebar(); true
                } else false
            } else false
        }
        sidebarRoot = root
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        runCatching { wm.addView(root, params) }.onFailure { sidebarRoot = null; return }
        animatePanelIn(panel)
    }

    private fun buildSidebarPanel(): View {
        val scroller = ScrollView(this).apply { isFillViewport = false }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = GradientDrawable().apply {
                val base = when (settings.sidebarBackground) {
                    SidebarBackground.DARK -> Color.rgb(24, 26, 30)
                    SidebarBackground.LIGHT -> Color.rgb(245, 247, 250)
                    SidebarBackground.TRANSPARENT -> Color.TRANSPARENT
                }
                val alpha = (settings.sidebarOpacity.coerceIn(0f,1f) * 255).toInt()
                setColor((base and 0x00FFFFFF) or (alpha shl 24))
                cornerRadius = dp(settings.cornerRadiusDp).toFloat()
            }
        }
        val pm = packageManager
        settings.selectedApps.forEach { pkg ->
            val launchIntent = pm.getLaunchIntentForPackage(pkg) ?: return@forEach
            @Suppress("DEPRECATION") val info = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull() ?: return@forEach
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                setPadding(dp(6), dp(5), dp(6), dp(5))
                background = GradientDrawable().apply { setColor(Color.TRANSPARENT); cornerRadius = dp(12).toFloat() }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(pm.getApplicationIcon(info))
                scaleType = ImageView.ScaleType.CENTER_CROP
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: android.graphics.Outline) {
                        val r = when (settings.iconShape) {
                            IconShape.SQUARE -> 0f
                            IconShape.ROUNDED_SQUARE -> dp(10).toFloat()
                            IconShape.CIRCLE -> view.width.coerceAtLeast(view.height) / 2f
                            IconShape.SQUIRCLE -> dp(14).toFloat()
                        }
                        outline.setRoundRect(0, 0, view.width, view.height, r)
                    }
                }
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(settings.iconSizeDp), dp(settings.iconSizeDp)))
            if (settings.showAppNames) {
                row.addView(TextView(this).apply {
                    text = pm.getApplicationLabel(info).toString()
                    textSize = settings.appNameFontSizeSp.toFloat()
                    setTextColor(if (settings.sidebarBackground == SidebarBackground.LIGHT) Color.BLACK else Color.WHITE)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setPadding(dp(9), 0, 0, 0)
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            row.setOnClickListener {
                if (settings.hapticFeedback) row.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                if (settings.sound) row.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                launchApp(launchIntent)
                if (settings.closeAfterLaunch) hideSidebar()
            }
            val rp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            rp.bottomMargin = dp(settings.verticalSpacingDp)
            list.addView(row, rp)
        }
        if (list.childCount == 0) {
            list.addView(TextView(this).apply {
                text = "Choose apps in Smart Sidebar settings"
                setTextColor(if (settings.sidebarBackground == SidebarBackground.LIGHT) Color.BLACK else Color.WHITE)
                setPadding(dp(8), dp(12), dp(8), dp(12))
            })
        }
        scroller.addView(list)
        var swipeDownX = 0f
        var swipeDownY = 0f
        scroller.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { swipeDownX = e.rawX; swipeDownY = e.rawY }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - swipeDownX; val dy = e.rawY - swipeDownY
                    val towardEdge = if (settings.handleSide == HandleSide.RIGHT) dx > dp(55) else dx < -dp(55)
                    if (towardEdge && kotlin.math.abs(dx) > kotlin.math.abs(dy)) hideSidebar()
                }
            }
            false
        }
        return scroller
    }

    private fun launchApp(intent: Intent) {
        val base = Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (settings.floatingWindowEnabled && capability.shouldAttemptFloatingWindow()) {
            runCatching {
                val w = resources.displayMetrics.widthPixels
                val h = resources.displayMetrics.heightPixels
                val opts = ActivityOptions.makeBasic().apply {
                    launchBounds = Rect((w * .12).toInt(), (h * .12).toInt(), (w * .88).toInt(), (h * .82).toInt())
                }
                base.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                startActivity(base, opts.toBundle())
            }.onSuccess { return }
        }
        if (settings.floatingWindowEnabled && !settings.shownFloatingUnsupportedToast) {
            Toast.makeText(this, "Floating window is not supported for this app/device. Opening normally.", Toast.LENGTH_LONG).show()
            scope.launch { store.markFloatingToastShown() }
        }
        runCatching { startActivity(base) }.onFailure {
            Toast.makeText(this, "Unable to launch this app.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun animatePanelIn(panel: View) {
        val duration = when (settings.animationSpeed) { AnimationSpeed.FAST -> 120L; AnimationSpeed.NORMAL -> 220L; AnimationSpeed.SLOW -> 360L }
        when (settings.openingAnimation) {
            OpeningAnimation.SLIDE -> {
                panel.translationX = if (settings.handleSide == HandleSide.RIGHT) dp(190).toFloat() else -dp(190).toFloat()
                panel.animate().translationX(0f).setDuration(duration).start()
            }
            OpeningAnimation.FADE -> { panel.alpha = 0f; panel.animate().alpha(1f).setDuration(duration).start() }
            OpeningAnimation.SCALE -> { panel.scaleX = .8f; panel.scaleY = .8f; panel.alpha = 0f; panel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(duration).start() }
            OpeningAnimation.NONE -> Unit
        }
    }

    private fun hideSidebar() {
        sidebarRoot?.let { runCatching { wm.removeView(it) } }
        sidebarRoot = null
        scheduleAutoHide()
    }

    private fun scheduleAutoHide() {
        autoHideJob?.cancel()
        val v = handleView ?: return
        if (!settings.autoHideHandle) { v.animate().alpha(settings.handleOpacity).setDuration(120).start(); return }
        autoHideJob = scope.launch {
            delay(settings.autoHideDelaySec * 1000L)
            v.animate().alpha((settings.handleOpacity * .35f).coerceAtLeast(.12f)).setDuration(250).start()
        }
    }

    private fun removeAllOverlays() {
        sidebarRoot?.let { runCatching { wm.removeView(it) } }; sidebarRoot = null
        handleView?.let { runCatching { wm.removeView(it) } }; handleView = null
    }

    private fun usableHalfHeight(): Int = (resources.displayMetrics.heightPixels - dp(160)).coerceAtLeast(dp(200)) / 2
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val CHANNEL_ID = "smart_sidebar_service"
        private const val NOTIFICATION_ID = 2027
    }
}
