# Intentionally minimal. R8 can be enabled later without app-specific keep rules.
