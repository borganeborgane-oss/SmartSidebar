package com.smartsidebar.app;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.widget.Toast;

/** Experimental Android 12 launcher. No privileged permissions are granted here. */
public final class OppoFloatingLauncher {
    static final String RESULT = "oppo_probe_result";
    static final String VERIFIED = "oppo_probe_verified";
    static final String ENVIRONMENT = "oppo_probe_environment";

    private OppoFloatingLauncher() {}

    static boolean matchesDevice() {
        return Build.VERSION.SDK_INT == 31
                && "oppo".equalsIgnoreCase(Build.MANUFACTURER)
                && "CPH2127".equalsIgnoreCase(Build.MODEL);
    }

    static String environment(Context c) {
        return Build.FINGERPRINT + ":" + Settings.Global.getInt(
                c.getContentResolver(), Settings.Global.BOOT_COUNT, -1);
    }

    static boolean verified(Context c) {
        return matchesDevice() && Prefs.sp(c).getBoolean(VERIFIED, false)
                && environment(c).equals(Prefs.sp(c).getString(ENVIRONMENT, ""));
    }

    static void result(Context c, boolean ok, String message) {
        Prefs.sp(c).edit().putBoolean(VERIFIED, ok)
                .putString(ENVIRONMENT, environment(c)).putString(RESULT, message).apply();
    }

    static Bundle options(Context c) {
        DisplayMetrics m = c.getResources().getDisplayMetrics();
        int w = Math.round(m.widthPixels * 0.76f);
        int h = Math.round(m.heightPixels * 0.64f);
        int left = (m.widthPixels - w) / 2;
        int top = (m.heightPixels - h) / 2;
        ActivityOptions options = ActivityOptions.makeBasic();
        options.setLaunchBounds(new Rect(left, top, left + w, top + h));
        Bundle bundle = options.toBundle();
        // Android 12 ActivityOptions' internal freeform request. ColorOS may reject/ignore it.
        // This is NOT a public compatibility guarantee and does NOT confer system privileges.
        bundle.putInt("android.activity.windowingMode", 5);
        return bundle;
    }

    static void test(Context c) {
        result(c, false, "الاختبار لم يكتمل بعد");
        if (!matchesDevice()) {
            result(c, false, "هذه النسخة التجريبية مخصصة لـ OPPO CPH2127 بنظام Android 12");
            return;
        }
        Intent i = new Intent(c, FloatingProbeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            c.startActivity(i, options(c));
        } catch (RuntimeException e) {
            result(c, false, "رفض النظام فتح نافذة الاختبار: " + e.getClass().getSimpleName());
            Toast.makeText(c, "رفض النظام طلب النافذة العائمة", Toast.LENGTH_LONG).show();
        }
    }

    static boolean launch(Context c, String pkg) {
        if (!verified(c)) {
            Toast.makeText(c, "افتح إعدادات النافذة المصغرة وشغّل اختبار التوافق أولاً",
                    Toast.LENGTH_LONG).show();
            return false;
        }
        Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            Toast.makeText(c, "التطبيق غير متوفر", Toast.LENGTH_SHORT).show();
            return false;
        }
        // Avoid the old adjacent/split-screen request and reuse of an existing fullscreen task.
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            c.startActivity(i, options(c));
            // This means a request was submitted, NOT that the external app is floating.
            return true;
        } catch (RuntimeException e) {
            result(c, false, "رفض النظام فتح التطبيق: " + e.getClass().getSimpleName());
            Toast.makeText(c, "رفض النظام الفتح المصغر؛ لم تتم محاولة فتح عادي",
                    Toast.LENGTH_LONG).show();
            return false;
        }
    }
}
