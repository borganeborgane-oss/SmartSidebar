package com.smartsidebar.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;

public class AboutActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=Ui.page(this,"حول Smart Sidebar");

        String version="?";
        try{version=getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception ignored){}

        root.addView(Ui.text(this,"Version "+version,16,Ui.ACCENT,true),Ui.match());
        root.addView(Ui.text(this,
                "\nSmart Sidebar هو مشغّل تطبيقات محلي يظهر فوق التطبيقات بعد منح صلاحية Overlay.\n\n"+
                "الخصوصية: لا حساب، لا خادم، لا Analytics، لا إعلانات، ولا يتم إرسال قائمة تطبيقاتك إلى الإنترنت.\n\n"+
                "نسخة OPPO CPH2127 / Android 12 التجريبية: تختبر نافذة التطبيق أولاً ثم تطلب وضع Freeform داخلياً. لا توجد محاولة فتح عادي بديلة. نجاح الاختبار لا يضمن تصغير WhatsApp أو غيره؛ النظام قد يتجاهل الطلب. لم تختبر هذه النسخة على الهاتف الفعلي.\n\n"+
                "التوقيع: هذه النسخة تستخدم Development Keystore ثابتًا داخل المشروع لتسهيل تحديث APK التجريبي. لا تستخدم هذا المفتاح للنشر النهائي على متجر Play.",
                14,Color.LTGRAY,false),Ui.match());

        setContentView(Ui.scrollPage(this,root));
    }
}
