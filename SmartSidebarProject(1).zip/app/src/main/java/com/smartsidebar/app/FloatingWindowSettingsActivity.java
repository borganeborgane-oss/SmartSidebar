package com.smartsidebar.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.*;

public class FloatingWindowSettingsActivity extends Activity {
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = Ui.page(this, "اختبار النافذة المصغرة");
        root.addView(Ui.text(this, Build.MANUFACTURER + " / " + Build.MODEL
                + " / Android " + Build.VERSION.RELEASE, 15, Color.WHITE, true), Ui.match());
        status = Ui.text(this, "", 15, Ui.ACCENT, true);
        root.addView(status, Ui.match());
        root.addView(Ui.text(this,
                "نسخة تجريبية مخصصة لـ OPPO A53 (CPH2127)، Android 12، ColorOS 12.1.\n\n"
                + "ابدأ باختبار نافذة تابعة لهذا التطبيق. إذا فتحها النظام كاملة، ستغلق تلقائياً ولن نفتح التطبيقات الخارجية.\n\n"
                + "إذا نجح الاختبار يمكنك تجربة WhatsApp من الشريط. نجاح الاختبار لا يضمن تصغيره؛ ColorOS قد يفتح التطبيق الخارجي كاملاً رغم الطلب. لا توجد محاولة فتح كامل بديلة في الكود.\n\n"
                + "لا تحتاج إلى Root أو Shizuku. هذا لا يمنح التطبيق صلاحيات شريط OPPO الأصلي.",
                14, Color.LTGRAY, false), Ui.match());
        Button test = Ui.button(this, "اختبار نافذة التطبيق");
        test.setEnabled(OppoFloatingLauncher.matchesDevice());
        test.setOnClickListener(v -> OppoFloatingLauncher.test(this));
        root.addView(test, Ui.buttonParams(this));
        root.addView(Ui.text(this,
                "إذا فشل الاختبار، لا حاجة لتجربة WhatsApp. أرسل صورة النتيجة. أعد الاختبار بعد إعادة تشغيل الهاتف أو تحديث النظام.",
                14, Color.LTGRAY, false), Ui.match());
        setContentView(Ui.scrollPage(this, root));
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) status.setText(Prefs.sp(this).getString(
                OppoFloatingLauncher.RESULT, "لم يجر الاختبار بعد"));
    }
}
