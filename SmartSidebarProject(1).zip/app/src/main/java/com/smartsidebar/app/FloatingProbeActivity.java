package com.smartsidebar.app;

import android.app.Activity;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

/** Tests only our own resizable activity; never launches a third-party app. */
public class FloatingProbeActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean scheduled;
    private final Runnable check = () -> {
        Rect actual = getWindowManager().getCurrentWindowMetrics().getBounds();
        Rect screen = getWindowManager().getMaximumWindowMetrics().getBounds();
        boolean compact = isInMultiWindowMode()
                && actual.width() < screen.width() * 0.95f
                && actual.height() < screen.height() * 0.95f;
        String message = compact
                ? "نجح تصغير نافذة الاختبار. تصغير التطبيقات الخارجية يحتاج تجربة منفصلة."
                : "لم يصغّر النظام نافذة الاختبار. تم منع فتح التطبيقات الخارجية.";
        OppoFloatingLauncher.result(this, compact, message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        finishAndRemoveTask();
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        TextView view = new TextView(this);
        view.setText("اختبار النافذة المصغرة…");
        view.setGravity(android.view.Gravity.CENTER);
        view.setTextSize(20);
        setContentView(view);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!scheduled) {
            scheduled = true;
            handler.postDelayed(check, 600);
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
